---
name: cloud-tier-requirements
description: Provides the Defra CCoE service-tier technical standards (NFR objectives) and reference architectures for a given cloud (AWS or Azure) and service tier (1a, 1b, 2, 3, 4). Use this to look up the availability, resiliency, RTO/RPO, backup, patching, connectivity, and monitoring requirements a service must meet.
user-invocable: true
argument-hint: "[cloud] [tier] — e.g. Azure 1b, or AWS 2"
---

You provide the authoritative Defra service-tier requirements for a given cloud platform and service tier. This skill bundles the tier data derived from the Defra CCoE Azure Service Tier Reference Architecture (v1.0, OFFICIAL).

## Input

You will be given a **cloud platform** (`AWS` or `Azure`) and a **service tier** (`1a`, `1b`, `2`, `3`, or `4`). If the tier is unknown, note that it is normally determined by the Business Impact Assessment (BIA), and that Tier 1a is reserved for applications scoring 5 across all BIA ratings.

## Steps

1. **Read the reference data** at [reference/service-tiers.md](reference/service-tiers.md).
2. **Select the requested tier's column** from the Technical Standards (Section A) table, plus the "requirements applicable to all tiers" section.
3. **Select the cloud-specific resiliency row** (AWS or Azure) and the matching reference-architecture summary. If the cloud is AWS, use the AWS mapping guidance and clearly flag that the source document has no AWS reference architecture — the AWS mappings are derived.
4. **Return the requirements** for that cloud and tier as a structured list covering: availability, resiliency model, RTO, RPO, permitted unavailability, service continuity testing, security patching, SOC connection, security event log retention, connectivity, plus the all-tiers monitoring/WAF/IaC requirements.

## Rules

- Do not invent or relax any objective. A service must meet **all** objectives for its tier.
- Preserve the OFFICIAL classification note in any derived artefact.
- Always state explicitly when a value is a derived AWS mapping rather than a documented objective.
