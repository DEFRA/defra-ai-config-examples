# Defra Service Tier — Technical Standards and Reference Architecture

> Derived from **Cloud Guidance — Azure Service Tier Reference Architecture**, Defra CCoE, Version 1.0 (26-02-2026). Classification: **OFFICIAL**.
>
> Scope note: The **Technical Standards (Section A NFR objectives)** below apply to **both AWS and Azure** (see the AWS and Azure resiliency rows). The **detailed reference architectures** in the source document are **Azure only**. For AWS targets, apply the tier objectives and map them to AWS-equivalent patterns, and flag that no AWS reference architecture exists in the source.

## Service tiers

| Tier | Name | Typical use |
|------|------|-------------|
| **1a** | Mission-Critical | Applications scoring 5 across all ratings on the Business Impact Assessment (BIA). Cross-region, active-active. |
| **1b** | Enhanced Support | Business-critical services that must survive a full Availability Zone failure without manual intervention, but do not need cross-region redundancy. |
| **2** | Standard Support | Non-business-critical services that can survive a zone failure without intervention; no cross-region redundancy. |
| **3** | Standard Support | Services needing robust availability and controlled recovery within a single region; PaaS/container-based. |
| **4** | Standard Support | Low-criticality, non-production/dev/test/internal services optimised for cost; single zone, backup-dependent. |

The tier is normally determined by the **Business Impact Assessment**. Tier 1a is reserved for applications that score 5 across all BIA ratings.

## Technical Standards — Section A (Non-Functional Requirements)

A service must meet **all** of the objectives for its respective tier.

| Category | Tier 1a | Tier 1b | Tier 2 | Tier 3 | Tier 4 |
|----------|---------|---------|--------|--------|--------|
| **Availability** | 99.95% | 99.9% | 99% | 95–98% | 90–95% |
| **Resiliency — cloud (AWS)** | Regional Redundancy | Zonal Redundancy | Zonal Redundancy | Backups dependent on service needs | Backups dependent on service needs |
| **Resiliency — cloud (Azure)** | Regional Redundancy | Zonal Redundancy | Zonal Redundancy | Backups dependent on service needs | Backups dependent on service needs |
| **Resiliency — on-premises** | Active-Active across 2 data centres in separate geographical regions | Active-Passive across 2 data centres | 2 data centres — cold standby in second DC, weekly data refresh | 2 data centres — cold standby in second DC, monthly data refresh | Single data centre reliant on backups |
| **Recovery Time Objective (RTO)** | 5 mins – 2 hours | 2 – 4 hours | 4 – 8 hours | 8 – 48 hours | 2 – 30 days |
| **Recovery Point Objective (RPO)** | 0 mins – 2 hours | 0 mins – 2 hours | 2 – 8 hours | 8 – 48 hours | 8 – 48 hours |
| **Permitted unavailability (28-day period)** | 21 minutes | 40.32 minutes | 6 hours 43 minutes | 13h 26m – 33h 36m | 33h 36m – 67h 12m |
| **Service Continuity Testing** | Annually and/or after major upgrade | Annually and/or after major upgrade | Annually and/or after major upgrade | Every 3 years and/or after major upgrade | Annually and/or after major upgrade |
| **Security** | Patching managed by supplier | Patching managed by supplier | Where not supplier-managed: monthly security patching, quarterly feature patching | Where not supplier-managed: monthly security patching, quarterly feature patching | Patching managed by supplier |
| **SOC** | Connection to SOC determined by Security BIA | Same | Same | Same | Same |
| **Security event logs** | Retained for a minimum of 2 years | Same | Same | Same | Same |
| **Connectivity** | Symmetric redundant routes to the internet | Symmetric redundant routes to the internet | Asymmetric redundant routes to the internet | Asymmetric redundant routes to the internet | Standard connectivity offer |

## Requirements applicable to all tiers

- **Connectivity (Fortigate resiliency):** Fortigate NVAs in UK South and North Europe are deployed with High Availability across multiple Availability Zones; in UK West and West Europe they are single-zone. Internet egress uses a load balancer whose backend pool is a highly available pair of Fortigate NVAs.
- **Security monitoring:** Log categories required by the BIA are forwarded to the Defra SOC's Sentinel workspace via diagnostic settings, configured with the SOC onboarding manager. Analytic rules are configured by the SOC. All resources are protected by appropriate **Microsoft Defender for Cloud** plans (for example Defender for Storage, Defender for SQL).
- **Service/resource health monitoring:** Integrate with Azure Monitor / Application Insights for transactional monitoring; **LogicMonitor** monitors resource health and raises incidents in **MyIT (Defra ServiceNow)**. Configure Azure Service Health alerts for platform-level incidents.
- **Public web applications:** A centrally managed **Azure Front Door with WAF** is mandatory for all public-facing web applications regardless of tier (Tier 3 uses a private-ingress Azure Application Gateway with WAF instead).
- **Infrastructure as Code:** All resource configuration is applied through IaC so any resource can be redeployed after accidental deletion. Stateless resources are redeployed from source rather than restored from backup.
- **Assumptions (Azure):** Deployment targets the `defra.onmicrosoft.com` Azure tenant; multi-cloud/hybrid is not assumed; sufficient subscription quota is secured (UK South may require a service request).

## Azure reference architecture summary per tier

### Tier 1a (Mission-Critical) — 99.95%
Active-active across **UK South and UK West**, multi-AZ within each region. Azure Front Door (WAF) provides symmetric redundant ingress and regional failover. App tier on **Premium App Service Plans** across AZs, with an active plan in UK West. **Azure SQL failover groups** combine synchronous zonal replication with asynchronous cross-region replication (RPO 0m–2h, automatic regional failover). Storage uses **RA-GZRS**. Key Vault globally resilient with private endpoints in both regions. VMs across 2 AZs in primary plus an availability set in UK West. Backup vaults in both regions (GRS). Patching supplier/PaaS-managed; VMs via Azure Update Manager.

### Tier 1b (Enhanced Support) — 99.9%
Single region (**UK South**), zone-redundant across 3 AZs, no manual intervention for a zone failure; no cross-region redundancy. Azure Front Door (WAF) + Private Link to a Premium App Service Plan (VNet integrated). **Azure SQL zone-redundant** synchronous replication with automated failover. Storage **ZRS**; Backup/Recovery Services Vault GRS (production recommendation). Symmetric redundant internet routes. RTO 2–4h, RPO 0m–2h.

### Tier 2 (Standard Support) — 99%
Single region across **two AZs**. Azure Front Door (WAF) + Private Link to a Premium App Service Plan with **instance count ≥ 2**. **Azure SQL zone-redundant** with automatic AZ failover. Storage/Key Vault/Backup/Recovery Services Vault zone-redundant. Asymmetric redundant internet routes. RTO 4–8h, RPO 2–8h.

### Tier 3 (Standard Support) — 95–98%
Private internal ingress via a centrally managed **Azure Application Gateway (WAF, private IP)**. Built on **Azure Container Apps** across AZs with a minimum of two instances per service and platform-managed autoscaling. **Azure SQL zone-redundant HA**. Storage **ZRS**. Backup-dependent but uses zone-redundant PaaS to reduce recovery risk. RTO/RPO 8–48h. Asymmetric redundant internet routes.

### Tier 4 (Standard Support) — 90–95%
Single region, **single Availability Zone**, cost-optimised. Single App Service instance; **single SQL database** protected by scheduled backups (GRS by default; PITR up to 35 days plus LTR). Storage **LRS** for primary data, **ZRS** for backups. Single VM with daily backup to a Recovery Services Vault. Azure Front Door still used but origin is single-zone. RTO 2–30 days, RPO 8–48h. Intended for non-production/dev/test/internal services.

## AWS mapping guidance (no AWS reference architecture in source)

For AWS targets, apply the Section A objectives and map the resiliency model as follows, flagging that these mappings are derived (not from the source document):

- **Regional Redundancy (Tier 1a):** multi-Region, active-active (for example Route 53 + CloudFront/global accelerator, multi-Region compute, Aurora Global Database or cross-Region read replicas, S3 Cross-Region Replication, cross-Region backups).
- **Zonal Redundancy (Tiers 1b, 2):** multi-AZ within a single Region (for example ALB across AZs, Auto Scaling/ECS/EKS across AZs with ≥2 tasks, Multi-AZ RDS/Aurora, S3 (multi-AZ by default), backups via AWS Backup).
- **Backups dependent on service needs (Tiers 3, 4):** single-Region, right-sized redundancy; rely on AWS Backup / snapshots and IaC redeployability to meet the tier's RTO/RPO.
- Meet the same availability %, RTO/RPO, permitted-unavailability, patching, SOC/log-retention, and monitoring objectives as the equivalent Azure tier. Public web apps front-ended by a WAF (AWS WAF on CloudFront/ALB).
