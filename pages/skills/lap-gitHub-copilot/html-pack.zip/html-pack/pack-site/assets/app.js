/* ====================================================== LAP pack app
   Single-file interactive viewer. No dependencies, works from file://.
   All explorer data is injected at build time as PACK_META / PACK_FEATURES /
   PACK_COVERAGE / PACK_QUESTIONS, so this file is entirely project-agnostic.
   ==================================================================== */

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

/* --------------------------------------------------------------- routing */

const VIEWS = ['dashboard', 'questions', 'coverage', 'features'];

function route() {
  const hash = decodeURIComponent(location.hash.replace(/^#/, '')) || 'dashboard';
  const [target] = hash.split('--');

  $$('.view').forEach((v) => (v.hidden = true));
  $$('.doc').forEach((d) => (d.hidden = true));

  let activeKey = null;

  if (VIEWS.includes(target)) {
    const v = $('#view-' + target);
    if (v) v.hidden = false;
    activeKey = target;
    $('#toc').style.display = 'none';
  } else {
    const doc = $(`.doc[data-doc="${CSS.escape(target)}"]`);
    if (doc) {
      doc.hidden = false;
      activeKey = target;
      $('#toc').style.display = '';
      buildToc(target);
    } else {
      $('#view-dashboard').hidden = false;
      activeKey = 'dashboard';
      $('#toc').style.display = 'none';
    }
  }

  $$('.nav-link').forEach((a) => {
    const key = a.dataset.doc || a.dataset.view;
    a.classList.toggle('active', key === activeKey);
  });

  // Scroll to the sub-heading if one was requested, otherwise to the top.
  if (hash.includes('--')) {
    const el = document.getElementById(hash);
    if (el) {
      requestAnimationFrame(() => {
        el.scrollIntoView({ block: 'start' });
        el.classList.remove('hl');
        void el.offsetWidth;
        el.classList.add('hl');
      });
      return;
    }
  }
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', route);

/* ------------------------------------------------------- table of contents */

function buildToc(docId) {
  const data = TOC_DATA.find((d) => d.id === docId);
  const list = $('#tocList');
  if (!data || !data.headings.length) {
    list.innerHTML = '<span class="muted">No sections</span>';
    return;
  }
  list.innerHTML = data.headings
    .filter((h) => h.level >= 2)
    .map((h) => `<a class="lvl${h.level}" href="#${h.id}">${escapeHtml(h.text)}</a>`)
    .join('');
}

// Highlight the section currently in view.
const tocObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      const link = $(`#tocList a[href="#${CSS.escape(e.target.id)}"]`);
      if (!link) return;
      $$('#tocList a').forEach((a) => a.classList.remove('active'));
      link.classList.add('active');
    });
  },
  { rootMargin: '-70px 0px -75% 0px' }
);

/* ---------------------------------------------------------------- helpers */

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function downloadCsv(filename, rows) {
  const csv = rows
    .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""').replace(/\s+/g, ' ').trim()}"`).join(','))
    .join('\r\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

function makeSortable(table, getRows, render) {
  $$('th[data-sort]', table).forEach((th) => {
    th.addEventListener('click', () => {
      const col = +th.dataset.sort;
      const dir = th.classList.contains('asc') ? -1 : 1;
      $$('th', table).forEach((o) => o.classList.remove('asc', 'desc'));
      th.classList.add(dir === 1 ? 'asc' : 'desc');
      getRows().sort((a, b) => dir * String(a.cells[col]).localeCompare(String(b.cells[col]), 'en', { numeric: true }));
      render();
    });
  });
}

const slug = (s) => String(PACK_META && PACK_META.slug || 'documentation') + '-' + s;

/* ============================================================= Figure cards */

function initFigures() {
  const figures = (PACK_META && PACK_META.figures) || [];
  const el = $('#figureCards');
  if (!el) return;
  el.innerHTML = figures
    .map((f) => `<div class="card ${f.warn ? 'warn' : ''}"><div class="num">${escapeHtml(f.value)}</div><div class="lab">${escapeHtml(f.label)}</div></div>`)
    .join('');
}

/* ============================================== Open questions explorer */

let QUESTIONS = [];

function initQuestions() {
  QUESTIONS = (PACK_QUESTIONS || []).map((q) => ({
    cells: [q.id || '', q.text || '', q.assumption || '', q.warn ? '⚠' : '', q.source || ''],
    link: q.link || null,
  }));
  $('#navQCount').textContent = QUESTIONS.length || '';
  if (!QUESTIONS.length) {
    $('#qEmpty').hidden = false;
    $('#qFilters').hidden = true;
    return;
  }

  const owners = [...new Set(QUESTIONS.map((q) => q.cells[4]).filter(Boolean))].sort();
  $('#qOwner').insertAdjacentHTML('beforeend', owners.map((o) => `<option>${escapeHtml(o)}</option>`).join(''));

  const tbody = $('#qTable tbody');

  function render() {
    const q = $('#qSearch').value.toLowerCase();
    const owner = $('#qOwner').value;
    const warnOnly = $('#qWarn').checked;

    const shown = QUESTIONS.filter((r) => {
      if (owner && r.cells[4] !== owner) return false;
      if (warnOnly && r.cells[3] !== '⚠') return false;
      if (q && !r.cells.join(' ').toLowerCase().includes(q)) return false;
      return true;
    });

    tbody.innerHTML = shown
      .map(
        (r) => `<tr>
        <td>${r.link ? `<a href="${r.link}"><code>${escapeHtml(r.cells[0])}</code></a>` : `<code>${escapeHtml(r.cells[0])}</code>`}</td>
        <td>${escapeHtml(r.cells[1])}</td>
        <td>${escapeHtml(r.cells[2])}</td>
        <td class="c">${r.cells[3] ? '<span class="warn-mark">⚠</span>' : ''}</td>
        <td>${escapeHtml(r.cells[4])}</td>
      </tr>`
      )
      .join('');

    const warn = shown.filter((r) => r.cells[3]).length;
    $('#qCount').textContent = `${shown.length} of ${QUESTIONS.length} shown · ${warn} must confirm`;
  }

  ['#qSearch', '#qOwner', '#qWarn'].forEach((sel) => $(sel).addEventListener('input', render));
  $('#qCsv').addEventListener('click', () =>
    downloadCsv(slug('open-questions.csv'), [
      ['ID', 'Decision or confirmation needed', 'Assumption / context', 'Must confirm', 'Source', 'Answer', 'By whom', 'Date'],
      ...QUESTIONS.map((r) => [...r.cells, '', '', '']),
    ])
  );
  makeSortable($('#qTable'), () => QUESTIONS, render);
  render();
}

/* ============================================ Functionality coverage explorer */

const STATUS_LABEL = {
  implemented: 'Implemented', 'in-progress': 'In progress', 'not-started': 'Not started', deferred: 'Deferred',
};
const statusKind = (s) => {
  const k = String(s || '').toLowerCase().replace(/\s+/g, '-');
  return STATUS_LABEL[k] ? k : 'not-started';
};

function initCoverage() {
  const cov = PACK_COVERAGE || {};
  const feats = cov.features || [];
  const descoped = cov.descoped || [];
  $('#navCCount').textContent = feats.length || '';

  // Stat cards derived from the acceptance-criteria roll-up.
  const s = cov.stats || {};
  $('#coverageStats').innerHTML = `
    <div class="card"><div class="num">${feats.length}</div><div class="lab">Features</div></div>
    <div class="card"><div class="num">${s.stories || 0}</div><div class="lab">User stories</div></div>
    <div class="card"><div class="num">${s.criteria || 0}</div><div class="lab">Acceptance criteria</div></div>
    <div class="card ok"><div class="num">${s.implemented || 0}</div><div class="lab">Implemented</div></div>
    <div class="card"><div class="num">${(s.notStarted || 0) + (s.inProgress || 0)}</div><div class="lab">Outstanding</div></div>
    <div class="card warn"><div class="num">${s.deferred || 0}</div><div class="lab">Deferred (recorded)</div></div>`;

  // Feature table.
  const statuses = [...new Set(feats.map((f) => statusKind(f.status)))];
  $('#cStatus').insertAdjacentHTML('beforeend',
    statuses.map((k) => `<option value="${k}">${STATUS_LABEL[k]}</option>`).join(''));

  const ROWS = feats.map((f) => ({
    cells: [f.id || '', f.title || '', f.priority || '', f.stories || 0, f.criteria || 0, STATUS_LABEL[statusKind(f.status)]],
    id: f.docId,
    kind: statusKind(f.status),
  }));
  const tbody = $('#cTable tbody');

  function render() {
    const q = $('#cSearch').value.toLowerCase();
    const st = $('#cStatus').value;
    const shown = ROWS.filter((r) => {
      if (st && r.kind !== st) return false;
      if (q && !r.cells.join(' ').toLowerCase().includes(q)) return false;
      return true;
    });
    tbody.innerHTML = shown
      .map((r) => `<tr>
        <td>${r.id ? `<a href="#${r.id}"><code>${escapeHtml(r.cells[0])}</code></a>` : `<code>${escapeHtml(r.cells[0])}</code>`}</td>
        <td>${escapeHtml(r.cells[1])}</td>
        <td>${escapeHtml(r.cells[2])}</td>
        <td class="c">${r.cells[3]}</td>
        <td class="c">${r.cells[4]}</td>
        <td><span class="tag tag-${r.kind}">${escapeHtml(r.cells[5])}</span></td>
      </tr>`)
      .join('');
    $('#cCount').textContent = `${shown.length} of ${ROWS.length} shown`;
  }

  ['#cSearch', '#cStatus'].forEach((sel) => $(sel).addEventListener('input', render));
  $('#cCsv').addEventListener('click', () =>
    downloadCsv(slug('coverage.csv'), [
      ['Feature', 'Title', 'Priority', 'Stories', 'Criteria', 'Status'],
      ...ROWS.map((r) => r.cells),
    ])
  );
  makeSortable($('#cTable'), () => ROWS, render);
  render();

  // Descoped table.
  const dbody = $('#dTable tbody');
  if (descoped.length) {
    dbody.innerHTML = descoped
      .map((d) => `<tr>
        <td>${escapeHtml((d.ids || []).join(', '))}</td>
        <td>${escapeHtml(d.feature || '')}</td>
        <td>${escapeHtml(d.rationale || '')}</td>
        <td>${escapeHtml(d.owner || '')}</td>
      </tr>`)
      .join('');
  } else {
    dbody.innerHTML = '<tr><td colspan="4" class="muted">Nothing has been deferred.</td></tr>';
  }
  if (cov.source) $('#cSource').innerHTML = `Source: <a href="${cov.source}">traceability manifest</a>.`;
}

/* ==================================================== Feature index cards */

function initFeatures() {
  const feats = PACK_FEATURES || [];
  $('#navFCount').textContent = feats.length || '';
  const cards = feats.map((f) => ({
    html: `<a class="feature-card" href="#${f.docId || ''}">
      <div class="fid">${escapeHtml(f.id || '')}</div>
      <div class="ftitle">${escapeHtml(f.title || '')}</div>
      <div class="fmeta">${f.stories || 0} user stories · ${f.criteria || 0} criteria${f.deferred ? ' · <span class="warn-mark">contains a deferral</span>' : ''}</div>
    </a>`,
    search: `${f.id} ${f.title}`.toLowerCase(),
  }));
  const grid = $('#featureGrid');
  function render() {
    const q = $('#fSearch').value.toLowerCase();
    const shown = cards.filter((c) => !q || c.search.includes(q));
    grid.innerHTML = shown.map((c) => c.html).join('');
    $('#fCount').textContent = `${shown.length} of ${cards.length} shown`;
  }
  $('#fSearch').addEventListener('input', render);
  render();
}

/* =========================================================== Dashboard */

function initDashboard() {
  // Open questions summary.
  const qs = PACK_QUESTIONS || [];
  const warn = qs.filter((q) => q.warn).length;
  const dq = $('#dashQuestions');
  if (dq) {
    if (qs.length) {
      const top = qs.filter((q) => q.warn).slice(0, 5);
      dq.innerHTML = `
        <div class="cards">
          <div class="card warn"><div class="num">${qs.length}</div><div class="lab">Open questions</div></div>
          <div class="card warn"><div class="num">${warn}</div><div class="lab">Must confirm ⚠</div></div>
        </div>
        ${top.length ? `<div class="table-wrap"><table class="grid">
          <thead><tr><th>ID</th><th>Decision needed</th></tr></thead>
          <tbody>${top.map((q) => `<tr><td>${q.link ? `<a href="${q.link}"><code>${escapeHtml(q.id)}</code></a>` : `<code>${escapeHtml(q.id)}</code>`}</td><td>${escapeHtml(q.text)}</td></tr>`).join('')}</tbody>
        </table></div>` : ''}`;
    } else {
      dq.innerHTML = '<p class="muted">No open questions recorded.</p>';
    }
  }

  // Coverage summary cards.
  const cov = PACK_COVERAGE || {};
  const s = cov.stats || {};
  const dc = $('#dashCoverageCards');
  if (dc) {
    dc.innerHTML = `
      <div class="card"><div class="num">${(cov.features || []).length}</div><div class="lab">Features</div></div>
      <div class="card"><div class="num">${s.criteria || 0}</div><div class="lab">Acceptance criteria</div></div>
      <div class="card ok"><div class="num">${s.implemented || 0}</div><div class="lab">Implemented</div></div>
      <div class="card warn"><div class="num">${s.deferred || 0}</div><div class="lab">Deferred</div></div>`;
  }

  // Deferred table.
  const dd = $('#dashDeferred');
  if (dd) {
    const descoped = cov.descoped || [];
    if (descoped.length) {
      dd.innerHTML = `<div class="table-wrap"><table class="grid">
        <thead><tr><th>Requirement ID(s)</th><th>Feature / Story</th><th>Rationale</th></tr></thead>
        <tbody>${descoped.map((d) => `<tr><td>${escapeHtml((d.ids || []).join(', '))}</td><td>${escapeHtml(d.feature || '')}</td><td>${escapeHtml(d.rationale || '')}</td></tr>`).join('')}</tbody>
      </table></div>`;
    } else {
      dd.innerHTML = '<p class="muted">Nothing has been deferred — every capability is tracked to a build status.</p>';
    }
  }
}

/* ================================================================= Search */

function initSearch() {
  const box = $('#search');
  const panel = $('#searchResults');
  let sel = -1;
  let results = [];

  function run() {
    const q = box.value.trim().toLowerCase();
    if (q.length < 2) {
      panel.hidden = true;
      return;
    }
    results = [];

    for (const doc of SEARCH_INDEX) {
      if (doc.title.toLowerCase().includes(q)) {
        results.push({ href: '#' + doc.id, title: doc.title, meta: doc.group, snippet: '' });
      }
      for (const h of doc.headings) {
        if (h.text.toLowerCase().includes(q)) {
          results.push({ href: '#' + h.id, title: h.text, meta: doc.title, snippet: '' });
        }
      }
      const i = doc.body.toLowerCase().indexOf(q);
      if (i > -1) {
        const from = Math.max(0, i - 70);
        results.push({
          href: '#' + doc.id,
          title: doc.title,
          meta: doc.group,
          snippet: doc.body.slice(from, i + 130),
        });
      }
      if (results.length > 120) break;
    }

    // De-duplicate by destination, headings first.
    const seen = new Set();
    results = results.filter((r) => (seen.has(r.href + r.title) ? false : seen.add(r.href + r.title)));
    results = results.slice(0, 40);

    const rx = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
    panel.innerHTML = results.length
      ? results
          .map(
            (r, i) => `<a href="${r.href}" data-i="${i}">
        <div class="sr-title">${escapeHtml(r.title).replace(rx, '<mark>$1</mark>')}</div>
        <div class="sr-meta">${escapeHtml(r.meta)}</div>
        ${r.snippet ? `<div class="sr-snippet">…${escapeHtml(r.snippet).replace(rx, '<mark>$1</mark>')}…</div>` : ''}
      </a>`
          )
          .join('')
      : '<div class="sr-empty">No matches.</div>';
    panel.hidden = false;
    sel = -1;
  }

  box.addEventListener('input', run);
  box.addEventListener('focus', () => { if (box.value.trim().length >= 2) panel.hidden = false; });

  box.addEventListener('keydown', (e) => {
    const items = $$('a', panel);
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      sel = e.key === 'ArrowDown' ? Math.min(sel + 1, items.length - 1) : Math.max(sel - 1, 0);
      items.forEach((a, i) => a.classList.toggle('sel', i === sel));
      if (items[sel]) items[sel].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter' && items[sel]) {
      e.preventDefault();
      location.hash = items[sel].getAttribute('href');
      panel.hidden = true;
      box.blur();
    } else if (e.key === 'Escape') {
      panel.hidden = true;
      box.blur();
    }
  });

  panel.addEventListener('click', () => { panel.hidden = true; box.value = ''; });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-wrap')) panel.hidden = true;
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement !== box && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
      e.preventDefault();
      box.focus();
    }
  });
}

/* ====================================================== Diagram lightbox */

function initDiagrams() {
  const box = $('#lightbox');
  const stage = $('#lbStage');
  const zoomLabel = $('#lbZoom');
  if (!box) return;

  let scale = 1, tx = 0, ty = 0;
  let dragging = false, startX = 0, startY = 0;

  const MIN = 0.2, MAX = 12;

  function apply() {
    const svg = stage.firstElementChild;
    if (svg) svg.style.transform = `translate(${tx}px, ${ty}px) scale(${scale})`;
    zoomLabel.textContent = Math.round(scale * 100) + '%';
  }

  function reset() {
    scale = 1; tx = 0; ty = 0;
    apply();
  }

  function open(svg) {
    stage.innerHTML = '';
    const clone = svg.cloneNode(true);
    clone.removeAttribute('class');
    clone.style.maxHeight = 'none';
    stage.appendChild(clone);
    reset();
    box.hidden = false;
    document.body.style.overflow = 'hidden';
    $('#lbClose').focus();
  }

  function close() {
    box.hidden = true;
    stage.innerHTML = '';
    document.body.style.overflow = '';
  }

  // Any rendered diagram becomes clickable.
  $$('.diagram-wrap').forEach((wrap) => {
    const svg = wrap.querySelector('svg.diagram');
    if (!svg) return;
    if (!wrap.querySelector('.diagram-hint')) {
      const hint = document.createElement('span');
      hint.className = 'diagram-hint';
      hint.textContent = 'Click to zoom';
      wrap.appendChild(hint);
    }
    svg.addEventListener('click', () => open(svg));
  });

  $('#lbIn').addEventListener('click', () => { scale = Math.min(MAX, scale * 1.3); apply(); });
  $('#lbOut').addEventListener('click', () => { scale = Math.max(MIN, scale / 1.3); apply(); });
  $('#lbReset').addEventListener('click', reset);
  $('#lbClose').addEventListener('click', close);

  // Zoom towards the pointer.
  stage.addEventListener(
    'wheel',
    (e) => {
      e.preventDefault();
      const rect = stage.getBoundingClientRect();
      const cx = e.clientX - rect.left - rect.width / 2;
      const cy = e.clientY - rect.top - rect.height / 2;
      const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
      const next = Math.min(MAX, Math.max(MIN, scale * factor));
      const ratio = next / scale;
      tx = cx - (cx - tx) * ratio;
      ty = cy - (cy - ty) * ratio;
      scale = next;
      apply();
    },
    { passive: false }
  );

  stage.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.lightbox-bar')) return;
    dragging = true;
    startX = e.clientX - tx;
    startY = e.clientY - ty;
    stage.classList.add('dragging');
    stage.setPointerCapture(e.pointerId);
  });
  stage.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    tx = e.clientX - startX;
    ty = e.clientY - startY;
    apply();
  });
  const endDrag = () => { dragging = false; stage.classList.remove('dragging'); };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);

  stage.addEventListener('dblclick', reset);

  // Click the backdrop (not the diagram) to close.
  box.addEventListener('click', (e) => {
    if (e.target === box || e.target === stage) close();
  });

  document.addEventListener('keydown', (e) => {
    if (box.hidden) return;
    if (e.key === 'Escape') close();
    else if (e.key === '+' || e.key === '=') { scale = Math.min(MAX, scale * 1.3); apply(); }
    else if (e.key === '-') { scale = Math.max(MIN, scale / 1.3); apply(); }
    else if (e.key === '0') reset();
  });
}

/* ================================================================ Chrome */

function initChrome() {
  const key = (PACK_META && PACK_META.slug ? PACK_META.slug : 'lap') + '-pack-theme';
  const saved = localStorage.getItem(key);
  if (saved) document.documentElement.dataset.theme = saved;
  $('#themeToggle').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    localStorage.setItem(key, next);
  });

  $('#navToggle').addEventListener('click', () => {
    const collapsed = document.body.classList.toggle('nav-collapsed');
    $('#navToggle').setAttribute('aria-expanded', String(!collapsed));
  });
}

/* ================================================================== Boot */

initChrome();
initFigures();
initDashboard();
initQuestions();
initCoverage();
initFeatures();
initDiagrams();
initSearch();
route();

// Observe headings for the on-this-page highlight.
$$('.doc h2[id], .doc h3[id]').forEach((h) => tocObserver.observe(h));
