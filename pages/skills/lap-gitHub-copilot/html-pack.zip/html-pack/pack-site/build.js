/**
 * Builds a single, self-contained, offline interactive documentation pack from the
 * markdown artefacts a LAP run produces in `output/`.
 *
 * Design notes:
 *  - Markdown is rendered at build time (no runtime markdown library).
 *  - Mermaid diagrams are rendered to inline SVG at build time via @mermaid-js/mermaid-cli,
 *    cached by content hash, so the output needs no internet access and no JavaScript to draw.
 *  - Cross-document links (foo.md, foo.md#anchor) are rewritten to in-page routes.
 *  - The Overview, Open-questions, Functionality-coverage and Feature-index views are
 *    populated from data DERIVED here (manifest.json, the descope register and the PRD's
 *    Open Questions), then injected as JSON — so the viewer is entirely project-agnostic.
 *
 * Usage:  node build.js [outputDir]
 *   outputDir defaults to ./output (relative to the current working directory).
 *
 * Optional config: <outputDir>/pack.config.json may override branding and overview text
 * (title, brand, subtitle, lede, slug, statusPill, overviewCallout, figures, groups).
 */

import {
  readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync,
} from 'node:fs';
import { createHash } from 'node:crypto';
import { execSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { marked } from 'marked';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT_DIR = path.resolve(process.argv[2] || path.join(process.cwd(), 'output'));
const CACHE = path.join(__dirname, '.mermaid-cache');
const ASSETS = path.join(__dirname, 'assets');

if (!existsSync(OUT_DIR)) {
  console.error(`No output directory at ${OUT_DIR}. Run the LAP pipeline first, or pass the path as an argument.`);
  process.exit(1);
}
if (!existsSync(CACHE)) mkdirSync(CACHE, { recursive: true });

/* ------------------------------------------------------------------- config */

const config = existsSync(path.join(OUT_DIR, 'pack.config.json'))
  ? JSON.parse(readFileSync(path.join(OUT_DIR, 'pack.config.json'), 'utf8'))
  : {};

/* ------------------------------------------------------------------ documents */

/** Default ordered document groups for a LAP run. `file` is relative to output/. */
const DEFAULT_GROUPS = [
  {
    group: 'Start here',
    docs: [
      { file: 'README.md', title: 'Read me first', kind: 'derived' },
      { file: 'open-questions.md', title: 'Open questions', kind: 'provisional' },
    ],
  },
  {
    group: 'What to build',
    docs: [
      { file: 'PRD.md', title: 'Product requirements (PRD)', kind: 'derived' },
      { file: 'architecture-requirements.md', title: 'Architecture requirements', kind: 'derived' },
      { file: 'traceability.md', title: 'Traceability matrix', kind: 'derived' },
      { file: 'descope-register.md', title: 'Descope register', kind: 'derived' },
    ],
  },
  { group: 'Feature specifications', dir: 'features', kind: 'derived' },
  {
    group: 'Supporting analysis',
    docs: [
      { file: 'domain-analysis.md', title: 'Domain analysis', kind: 'derived' },
      { file: 'interaction-analysis.md', title: 'Interaction analysis', kind: 'derived' },
      { file: 'application-analysis.md', title: 'Application analysis', kind: 'derived' },
      { file: 'database-analysis.md', title: 'Database analysis', kind: 'derived' },
      { file: 'completeness-report.md', title: 'Completeness report', kind: 'derived' },
    ],
  },
  { group: 'Code-derived specifications', dir: 'specs', kind: 'machine', only: /\.md$/ },
  { group: 'Reference data', dir: 'reference-data', kind: 'machine', only: /\.md$/ },
];

const GROUPS = config.groups || DEFAULT_GROUPS;

/** Expand directory-based groups into explicit document lists, dropping missing files. */
function expandGroups() {
  const out = [];
  const claimed = new Set();
  for (const g of GROUPS) {
    if (g.docs) {
      const docs = g.docs.filter((d) => existsSync(path.join(OUT_DIR, d.file)));
      docs.forEach((d) => claimed.add(d.file.replace(/\\/g, '/')));
      if (docs.length) out.push({ group: g.group, docs });
      continue;
    }
    const dir = path.join(OUT_DIR, g.dir);
    if (!existsSync(dir)) continue;
    const files = readdirSync(dir)
      .filter((f) => f.endsWith('.md') && (!g.only || g.only.test(f)))
      .sort((a, b) => (a.toLowerCase() === 'readme.md' ? -1 : b.toLowerCase() === 'readme.md' ? 1 : a.localeCompare(b, 'en', { numeric: true })));
    const docs = files.map((f) => {
      const rel = `${g.dir}/${f}`;
      claimed.add(rel);
      return { file: rel, title: titleFromFile(path.join(dir, f), f), kind: g.kind };
    });
    if (docs.length) out.push({ group: g.group, docs });
  }

  // Catch-all: any remaining top-level markdown in output/ so nothing is dropped silently.
  const extra = readdirSync(OUT_DIR)
    .filter((f) => f.endsWith('.md') && !claimed.has(f))
    .sort((a, b) => a.localeCompare(b, 'en', { numeric: true }));
  if (extra.length) {
    out.push({
      group: 'Other documents',
      docs: extra.map((f) => ({ file: f, title: titleFromFile(path.join(OUT_DIR, f), f), kind: 'derived' })),
    });
  }
  return out;
}

function titleFromFile(fullPath, fallbackName) {
  const first = readFileSync(fullPath, 'utf8').split(/\r?\n/).find((l) => /^#\s+/.test(l));
  if (first) return first.replace(/^#\s+/, '').trim();
  return fallbackName.replace(/\.md$/, '');
}

const docIdFor = (rel) => rel.replace(/\.md$/, '').replace(/[^A-Za-z0-9]+/g, '-').toLowerCase();

/* ------------------------------------------------------------------- mermaid */

let mermaidRendered = 0;
let mermaidCached = 0;
let mermaidFailed = 0;
let mermaidCliBroken = false;

function renderMermaid(code) {
  const hash = createHash('sha1').update(code).digest('hex').slice(0, 16);
  const svgPath = path.join(CACHE, `${hash}.svg`);
  if (existsSync(svgPath)) {
    mermaidCached++;
    return cleanSvg(readFileSync(svgPath, 'utf8'), hash);
  }
  if (mermaidCliBroken) {
    mermaidFailed++;
    return `<pre class="mermaid-failed">${escapeHtml(code)}</pre>`;
  }
  const mmdPath = path.join(CACHE, `${hash}.mmd`);
  writeFileSync(mmdPath, code, 'utf8');
  try {
    // A shell is required on Windows: Node refuses to spawn .cmd shims directly
    // (CVE-2024-27980 mitigation), which is how npx is installed there. Paths are
    // build-generated (a content hash inside our own cache directory), never user input.
    execSync(
      `npx -y @mermaid-js/mermaid-cli@11 -i "${mmdPath}" -o "${svgPath}" -b transparent`,
      { stdio: 'pipe', cwd: CACHE }
    );
    if (!existsSync(svgPath)) throw new Error('no SVG produced');
    mermaidRendered++;
    return cleanSvg(readFileSync(svgPath, 'utf8'), hash);
  } catch (err) {
    mermaidFailed++;
    const detail = (err.stderr || err.stdout || err.message || '').toString().trim().split('\n').slice(-3).join(' ');
    if (/not recognized|command not found|ENOENT|could not determine executable/i.test(detail)) {
      mermaidCliBroken = true;
      console.warn('  ! mermaid-cli unavailable (offline or not installed) — diagrams fall back to source text.');
    } else {
      console.warn(`  ! mermaid block failed to render (${hash}): ${detail}`);
    }
    return `<pre class="mermaid-failed">${escapeHtml(code)}</pre>`;
  }
}

/**
 * Prepare a Mermaid SVG for embedding alongside others in one page:
 *  - drop the XML prolog,
 *  - give it a unique id (every Mermaid SVG is `my-svg`, and its internal
 *    <style> block is scoped to that id, so duplicates bleed across diagrams),
 *  - mark it as a diagram without emitting a second `class` attribute,
 *  - drop the intrinsic width/height so CSS can scale it to the page.
 */
function cleanSvg(svg, hash) {
  const uid = `mmd-${hash}`;
  let out = svg
    .replace(/<\?xml[^>]*\?>/g, '')
    .replace(/<!DOCTYPE[^>]*>/g, '')
    .replace(/\sstyle="max-width:[^"]*"/g, '');
  out = out.replace(/\bid="my-svg"/g, `id="${uid}"`).replace(/#my-svg\b/g, `#${uid}`);
  out = out.replace(/<svg\b[^>]*>/, (tag) => {
    let t = tag.replace(/\swidth="[^"]*"/, '').replace(/\sheight="[^"]*"/, '');
    t = /\sclass="/.test(t)
      ? t.replace(/\sclass="([^"]*)"/, ' class="$1 diagram"')
      : t.replace(/<svg\b/, '<svg class="diagram"');
    return t;
  });
  return out.trim();
}

const escapeHtml = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** Turn rendered HTML back into plain text: strip tags, then decode entities. */
const htmlToText = (html) =>
  html
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();

/* -------------------------------------------------------------- slugs & links */

function slugify(text) {
  return text
    .toLowerCase()
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '')
    .replace(/&[a-z]+;/g, '')
    .replace(/[`*_]/g, '')
    .replace(/[^\p{L}\p{Nd} _-]/gu, '')
    .trim()
    .replace(/\s/g, '-');
}

/* ------------------------------------------------- open-questions extraction */

/** Split a GitHub-flavoured markdown table row into trimmed cells. */
const splitRow = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
const stripMd = (s) => s.replace(/\*\*/g, '').replace(/`/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').trim();
const isWarn = (s) => /⚠|must confirm|must-confirm/i.test(s);

/**
 * Pull open questions out of a document's markdown. Looks for headings that mention
 * open questions/decisions and reads the markdown table (or numbered list) beneath.
 */
function extractQuestions(md, docId, title) {
  const lines = md.split(/\r?\n/);
  const out = [];
  let capturing = false;
  let sectionSlug = '';
  let auto = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const h = line.match(/^#{1,6}\s+(.*)$/);
    if (h) {
      const heading = h[1].trim();
      capturing = /open\s+(questions?|decisions?|items)|decisions?\s+needed|unresolved/i.test(heading);
      if (capturing) sectionSlug = slugify(heading);
      continue;
    }
    if (!capturing) continue;

    // Markdown table: header, separator, then rows.
    if (/^\s*\|/.test(line) && /^\s*\|[\s:|-]+\|?\s*$/.test(lines[i + 1] || '')) {
      i += 2;
      while (i < lines.length && /^\s*\|/.test(lines[i])) {
        const cells = splitRow(lines[i]).map(stripMd);
        if (cells[0] && !/^-+$/.test(cells[0])) {
          out.push({
            id: cells[0],
            text: cells[1] || '',
            assumption: cells[2] || '',
            warn: cells.some(isWarn) || isWarn(lines[i]),
            source: title,
            link: `#${docId}--${sectionSlug}`,
          });
        }
        i++;
      }
      i--;
      continue;
    }

    // Numbered / bulleted list item.
    const li = line.match(/^\s*(?:\d+\.|[-*])\s+(.*)$/);
    if (li && li[1].trim()) {
      auto++;
      out.push({
        id: `OQ-${String(auto).padStart(2, '0')}`,
        text: stripMd(li[1]).slice(0, 400),
        assumption: '',
        warn: isWarn(line),
        source: title,
        link: `#${docId}--${sectionSlug}`,
      });
    }
  }
  return out;
}

/* --------------------------------------------- coverage from the manifest */

function rollUpFeatureStatus(f) {
  if (f.status && f.status !== 'not-started') return f.status;
  const acs = (f.userStories || []).flatMap((s) => s.acceptanceCriteria || []);
  if (!acs.length) return f.status || 'not-started';
  const kinds = new Set(acs.map((a) => a.status || 'not-started'));
  if (kinds.size === 1) return [...kinds][0];
  if ([...kinds].every((k) => k === 'implemented' || k === 'deferred')) return 'implemented';
  return 'in-progress';
}

function buildCoverage(manifest) {
  if (!manifest) return { features: [], stats: {}, descoped: [], source: '' };
  const stats = { stories: 0, criteria: 0, implemented: 0, inProgress: 0, notStarted: 0, deferred: 0 };
  const features = (manifest.features || []).map((f) => {
    const stories = (f.userStories || []).length;
    const acs = (f.userStories || []).flatMap((s) => s.acceptanceCriteria || []);
    stats.stories += stories;
    stats.criteria += acs.length;
    for (const a of acs) {
      const k = (a.status || 'not-started').toLowerCase();
      if (k === 'implemented') stats.implemented++;
      else if (k === 'in-progress') stats.inProgress++;
      else if (k === 'deferred') stats.deferred++;
      else stats.notStarted++;
    }
    const rel = (f.file || '').replace(/^output[\\/]/, '');
    return {
      id: f.id,
      title: f.title || '',
      docId: rel ? docIdFor(rel) : '',
      priority: f.priority || '',
      stories,
      criteria: acs.length,
      status: rollUpFeatureStatus(f),
    };
  });
  const descoped = (manifest.descoped || []).map((d) => ({
    ids: d.prdRequirements || d.ids || (d.id ? [d.id] : []),
    feature: d.feature || d.story || '',
    rationale: d.rationale || d.reason || '',
    owner: d.owner || '',
  }));
  return { features, stats, descoped, source: '#traceability' };
}

/* ---------------------------------------------------------------------- build */

const groups = expandGroups();
const allDocs = groups.flatMap((g) => g.docs.map((d) => ({ ...d, group: g.group })));
const knownDocs = new Map(allDocs.map((d) => [d.file.replace(/\\/g, '/'), docIdFor(d.file)]));

console.log(`Building documentation pack from ${allDocs.length} documents in ${path.relative(process.cwd(), OUT_DIR) || '.'}…`);

const searchIndex = [];
const rendered = [];
let questions = [];

for (const doc of allDocs) {
  const abs = path.join(OUT_DIR, doc.file);
  const docId = docIdFor(doc.file);
  const docDir = path.posix.dirname(doc.file.replace(/\\/g, '/'));
  let md = readFileSync(abs, 'utf8');

  questions = questions.concat(extractQuestions(md, docId, doc.title));

  // Pull mermaid blocks out before markdown conversion, render them, put placeholders back.
  const diagrams = [];
  md = md.replace(/```mermaid\r?\n([\s\S]*?)```/g, (_m, code) => {
    diagrams.push(renderMermaid(code.trim()));
    return `\n@@DIAGRAM${diagrams.length - 1}@@\n`;
  });

  let html = marked.parse(md, { mangle: false, headerIds: false, gfm: true, breaks: false });

  // Heading ids, namespaced per document so anchors stay unique across the bundle.
  const headings = [];
  html = html.replace(/<h([1-6])(?![^>]*\bid=)([^>]*)>([\s\S]*?)<\/h\1>/g, (_m, lvl, attrs, inner) => {
    const t = htmlToText(inner);
    const id = `${docId}--${slugify(t)}`;
    if (+lvl <= 3 && t) headings.push({ id, text: t, level: +lvl });
    return `<h${lvl}${attrs} id="${id}"><a class="anchor" href="#${id}">#</a>${inner}</h${lvl}>`;
  });

  // Rewrite links.
  html = html.replace(/<a href="([^"]+)"/g, (m, href) => {
    if (/^(https?:|mailto:)/i.test(href)) return `<a class="ext" target="_blank" rel="noopener" href="${href}"`;
    if (href.startsWith('#')) return `<a href="#${docId}--${href.slice(1).toLowerCase()}"`;

    const [rawTarget, rawAnchor] = href.split('#');
    const resolved = path.posix.normalize(path.posix.join(docDir === '.' ? '' : docDir, rawTarget));
    if (knownDocs.has(resolved)) {
      const targetId = knownDocs.get(resolved);
      const anchor = rawAnchor ? `--${rawAnchor.toLowerCase()}` : '';
      return `<a href="#${targetId}${anchor}"`;
    }
    const asIndex = allDocs.find((d) => d.file.replace(/\\/g, '/').startsWith(resolved.replace(/\/$/, '') + '/'));
    if (asIndex && rawTarget.endsWith('/')) return `<a href="#${docIdFor(asIndex.file)}"`;
    return `<a class="file-ref" title="File in the repository, not part of this bundle" href="${href}"`;
  });

  // Put the rendered diagrams back.
  html = html.replace(/<p>@@DIAGRAM(\d+)@@<\/p>/g, (_m, i) => `<figure class="diagram-wrap">${diagrams[+i]}</figure>`);
  html = html.replace(/@@DIAGRAM(\d+)@@/g, (_m, i) => `<figure class="diagram-wrap">${diagrams[+i]}</figure>`);

  // Make tables scrollable.
  html = html.replace(/<table>/g, '<div class="table-wrap"><table>').replace(/<\/table>/g, '</table></div>');

  rendered.push({ ...doc, id: docId, html, headings });
  searchIndex.push({
    id: docId,
    title: doc.title,
    group: doc.group,
    headings: headings.map((h) => ({ id: h.id, text: h.text })),
    body: md.replace(/[#*`|>-]/g, ' ').replace(/\s+/g, ' ').slice(0, 200000),
  });
}

console.log(`Mermaid: ${mermaidRendered} rendered, ${mermaidCached} from cache, ${mermaidFailed} failed.`);

/* ------------------------------------------------------ derived explorer data */

const manifest = existsSync(path.join(OUT_DIR, 'features', 'manifest.json'))
  ? JSON.parse(readFileSync(path.join(OUT_DIR, 'features', 'manifest.json'), 'utf8'))
  : null;

const coverage = buildCoverage(manifest);
const features = coverage.features.map((f) => ({
  id: f.id,
  title: f.title.replace(new RegExp(`^${f.id}\\s*[—–-]\\s*`), ''),
  docId: f.docId,
  stories: f.stories,
  criteria: f.criteria,
  priority: f.priority,
  deferred: f.status === 'deferred',
}));

if (config.questions) questions = config.questions;

const figures = config.figures || [
  { value: features.length, label: 'Features' },
  { value: coverage.stats.stories || 0, label: 'User stories' },
  { value: coverage.stats.criteria || 0, label: 'Acceptance criteria' },
  { value: coverage.stats.implemented || 0, label: 'Implemented' },
  { value: questions.length, label: 'Open questions', warn: true },
  { value: coverage.descoped.length, label: 'Deferred capabilities', warn: true },
];

const title = config.title || 'Rebuild Documentation Pack';
const brand = config.brand || title.replace(/\s*[—–-].*$/, '') || 'LAP';
const meta = {
  title,
  brand,
  subtitle: config.subtitle || 'Rebuild Documentation Pack',
  slug: config.slug || slugify(brand) || 'documentation',
  figures,
};

/* -------------------------------------------------------------------- assemble */

const css = readFileSync(path.join(ASSETS, 'style.css'), 'utf8');
const js = readFileSync(path.join(ASSETS, 'app.js'), 'utf8');

const navHtml = groups
  .map(
    (g) => `<div class="nav-group"><div class="nav-group-title">${escapeHtml(g.group)}</div>${g.docs
      .map((d) => `<a class="nav-link" data-doc="${docIdFor(d.file)}" href="#${docIdFor(d.file)}">${escapeHtml(d.title)}</a>`)
      .join('')}</div>`
  )
  .join('');

const docsHtml = rendered
  .map(
    (d) => `<article class="doc" id="doc-${d.id}" data-doc="${d.id}" hidden>
  <div class="doc-head">
    <span class="badge badge-${d.kind}">${
      d.kind === 'machine' ? 'Machine-extracted' : d.kind === 'provisional' ? 'Provisional' : 'Derived'
    }</span>
    <span class="doc-path">output/${escapeHtml(d.file)}</span>
  </div>
  ${d.html}
</article>`
  )
  .join('\n');

const tocData = rendered.map((d) => ({ id: d.id, title: d.title, headings: d.headings }));

const statusPill = config.statusPill
  ? `<span class="status-pill" title="${escapeHtml(config.statusPill.title || '')}">${escapeHtml(config.statusPill.text)}</span>`
  : '';
const overviewCallout = config.overviewCallout
  ? `<div class="callout callout-warn">${marked.parse(config.overviewCallout)}</div>`
  : '';
const lede = config.lede
  || 'Everything needed to rebuild this service without losing functionality: what it does, what to build, how it behaves, and what is still undecided.';

const template = readFileSync(path.join(ASSETS, 'template.html'), 'utf8');
const built = template
  .replace('/*__CSS__*/', () => css)
  .replace('/*__JS__*/', () => js)
  .replace('<!--__NAV__-->', () => navHtml)
  .replace('<!--__DOCS__-->', () => docsHtml)
  .replace('<!--__STATUS_PILL__-->', () => statusPill)
  .replace('<!--__OVERVIEW_CALLOUT__-->', () => overviewCallout)
  .replace('/*__SEARCH_INDEX__*/null', () => JSON.stringify(searchIndex))
  .replace('/*__TOC__*/null', () => JSON.stringify(tocData))
  .replace('/*__META__*/null', () => JSON.stringify(meta))
  .replace('/*__FEATURES__*/null', () => JSON.stringify(features))
  .replace('/*__COVERAGE__*/null', () => JSON.stringify(coverage))
  .replace('/*__QUESTIONS__*/null', () => JSON.stringify(questions))
  .replace(/__TITLE__/g, () => escapeHtml(title))
  .replace(/__BRAND__/g, () => escapeHtml(brand))
  .replace(/__SUBTITLE__/g, () => escapeHtml(meta.subtitle))
  .replace(/__LEDE__/g, () => escapeHtml(lede))
  .replace(/__BUILD_DATE__/g, new Date().toISOString().slice(0, 10));

/* ------------------------------------------------------------------- output */

const outFile = path.join(OUT_DIR, 'documentation-pack.html');
writeFileSync(outFile, built, 'utf8');

const mb = (statSync(outFile).size / 1024 / 1024).toFixed(2);
console.log(`\nWrote ${path.relative(process.cwd(), outFile)}`);
console.log(`  ${mb} MB · ${rendered.length} documents · ${features.length} features · ${questions.length} open questions · self-contained, opens offline`);
