---
name: html-pack
description: >
  Renders the markdown artefacts of a LAP run (PRD, architecture requirements,
  features, traceability, descope register, analyses) into a single, self-contained,
  offline interactive HTML documentation pack. The pack has an Overview dashboard,
  a filterable Open-questions view, a Functionality-coverage (no-silent-loss) view
  driven by the traceability manifest, a Feature index, full-text search, a dark mode,
  and zoomable diagrams. Use this as the final step of the pipeline so the outputs are
  shareable in the agreed format.
---

# Skill: build the shareable HTML documentation pack

This skill turns the markdown documents in `output/` into **one** self-contained HTML
file — `output/documentation-pack.html` — that opens in any browser with no internet and
no server. It is the single file you send to a reviewer.

The generator lives beside this skill in [pack-site/](pack-site/):

- `pack-site/build.js` — the builder (Node, ES modules).
- `pack-site/assets/style.css`, `assets/app.js`, `assets/template.html` — the viewer.
- `pack-site/package.json` — one dependency, `marked`, for markdown rendering.

## What the pack always includes

Three things are elevated to first-class, always-present views, regardless of the project:

1. **Overview** — headline figures, an open-questions summary, a functionality-coverage
   summary, and the deferred-capability table, so a reviewer sees the state at a glance.
2. **Open questions** — every unresolved decision/ambiguity/gap, filterable and
   downloadable as CSV. Extracted from any document heading that mentions *open questions*
   or *decisions needed* (the PRD's Open Questions section, a `descope-register.md`, or a
   dedicated `open-questions.md`).
3. **Functionality coverage (no silent loss)** — every feature, user story and acceptance
   criterion with its build status, plus the descope register, derived directly from
   `output/features/manifest.json`. This is the evidence that nothing is dropped by accident.

Plus a **Feature index** and full-text search across every document. Mermaid diagrams are
pre-rendered to inline SVG at build time, so they display offline and are click-to-zoom.

## Steps

### 1. Confirm there is something to render

Check that `output/` exists and contains at least `PRD.md` (and ideally
`output/features/manifest.json`). If `output/` is empty, stop and tell the user to run the
pipeline first.

### 2. Install the one dependency (first run only)

From the skill's `pack-site/` folder:

```bash
npm install --no-audit --no-fund
```

`marked` is the only dependency. Diagram rendering uses `@mermaid-js/mermaid-cli` fetched
on demand via `npx` and cached in `pack-site/.mermaid-cache/`; the **output** is fully
offline even though the first build may fetch the CLI. If the CLI cannot be fetched (no
network), diagrams fall back to their source text and the build still succeeds.

### 3. Write the project pack configuration (branding)

So the pack is branded to the project rather than generic, write `output/pack.config.json`
before building — **unless the user has already provided one**, in which case leave it
untouched. Populate it from the PRD's **Section 0 (Provenance, Criticality & Headline
Figures)** and its title heading:

- `title` / `brand` / `subtitle` — the system name from the PRD heading (e.g. title
  `"RaSP / RSR — Rebuild Documentation Pack"`, brand `"RaSP / RSR"`, subtitle
  `"Rebuild Documentation Pack"`).
- `slug` — a short lowercase id for the project (used for CSV filenames and the theme key).
- `lede` — one sentence on what the pack is for.
- `statusPill` — set `{ "text": "Proof of concept", "title": "…" }` when the run is a
  proof of concept or the PRD flags the output as not signed off; omit it for a signed-off
  baseline.
- `overviewCallout` — a short markdown "read this first" note, typically summarising the
  criticality and that a working assumption was taken for every open question.

Leave `figures`, `questions` and `groups` out unless you specifically need to override the
values the build already derives from the manifest and the registers.

### 4. Build the pack

Run the builder, pointing it at the repo's `output/` directory (the default is
`./output` relative to the current directory):

```bash
node .github/skills/html-pack/pack-site/build.js output
```

The builder:

- groups the documents (Start here · What to build · Feature specifications · Supporting
  analysis · Code-derived specifications · Reference data), and adds an *Other documents*
  group for any remaining top-level markdown so **no document is dropped silently**;
- rewrites cross-document `*.md` links into in-page routes;
- derives the Open-questions, Functionality-coverage and Feature-index data;
- writes `output/documentation-pack.html` and reports its size and counts.

### 5. Report

Tell the user the path (`output/documentation-pack.html`), its size, and the headline
counts (documents, features, open questions, deferred capabilities). Remind them it is
self-contained and works offline.

## Per-project configuration reference

The `output/pack.config.json` written in step 3 tailors branding and the overview without
touching the engine. All fields are optional:

```json
{
  "title": "RaSP / RSR — Rebuild Documentation Pack",
  "brand": "RaSP / RSR",
  "subtitle": "Rebuild Documentation Pack",
  "slug": "rasp-rsr",
  "lede": "Everything needed to rebuild the service without losing functionality.",
  "statusPill": { "text": "Proof of concept", "title": "Not signed-off requirements." },
  "overviewCallout": "**Read this first.** This is proof-of-concept output, not signed-off requirements."
}
```

- `figures` — override the Overview stat cards: `[{ "value": "137", "label": "Legacy screens", "warn": false }]`.
- `questions` — supply the open-questions rows directly instead of extracting them:
  `[{ "id": "D-3", "text": "England-only vs England and Wales", "assumption": "...", "warn": true, "source": "Open decisions register", "link": "#..." }]`.
- `groups` — override the document grouping/order.

## Notes

- The pack is regenerable: re-run the builder after any document changes.
- `.mermaid-cache/` and `node_modules/` are git-ignored; the shareable deliverable is the
  single `output/documentation-pack.html`.
- Requires Node.js (18+). Node and the resulting pack contain no telemetry and make no
  network calls at view time.
