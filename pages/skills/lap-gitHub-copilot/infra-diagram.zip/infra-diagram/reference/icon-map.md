<!-- Derived from: Defra CCoE Cloud Guidance — Azure Service Tier Reference Architecture v1.0 (26-02-2026) and the Mermaid architecture-beta icon syntax. Classification: OFFICIAL. -->

# Infrastructure diagram icon map

Mermaid `architecture-beta` renders an icon for every `group` and `service`. Icons
are one of:

- The five **built-in** icons that render everywhere: `cloud`, `database`, `disk`,
  `internet`, `server`.
- An **iconify** icon in the form `pack:icon-name` (for example `logos:aws-s3`).
  Iconify icons render in viewers that fetch the icon pack (mermaid.live, Mermaid
  Chart, and renderers that register the pack). In viewers that do **not** register
  the pack (some GitHub / VS Code Markdown previews), the node still renders with its
  **label**, so the diagram is never broken — only the logo is missing.

## Rules for choosing an icon

1. Prefer a specific brand logo from the `logos:` pack when one exists (best coverage
   is AWS — see below).
2. If no brand logo exists (most Azure services), use the closest **built-in** icon
   and rely on the clear text label. Optionally use `logos:microsoft-azure` for the
   overall Azure boundary/group.
3. Always give every node a descriptive `[Label]` so the diagram reads correctly even
   when logos do not render.
4. Never invent an iconify name. Only use names listed here or ones you have verified
   exist in iconify.

## AWS — verified `logos:` icons

These exist in the iconify `logos` pack (prefix `logos:`).

| AWS service / role | Icon |
|--------------------|------|
| Route 53 (DNS) | `logos:aws-route53` |
| CloudFront (CDN/edge) | `logos:aws-cloudfront` |
| WAF | `logos:aws-waf` |
| Shield (DDoS) | `logos:aws-shield` |
| Elastic Load Balancing (ALB/NLB) | `logos:aws-elb` |
| VPC (network boundary) | `logos:aws-vpc` |
| EC2 (VM compute) | `logos:aws-ec2` |
| ECS (containers) | `logos:aws-ecs` |
| EKS (Kubernetes) | `logos:aws-eks` |
| Fargate (serverless containers) | `logos:aws-fargate` |
| Lambda (functions) | `logos:aws-lambda` |
| Elastic Beanstalk (app platform) | `logos:aws-elastic-beanstalk` |
| RDS (relational DB) | `logos:aws-rds` |
| Aurora (relational DB) | `logos:aws-aurora` |
| DynamoDB (NoSQL) | `logos:aws-dynamodb` |
| ElastiCache (cache) | `logos:aws-elasticache` |
| S3 (object storage) | `logos:aws-s3` |
| Glacier (archive) | `logos:aws-glacier` |
| Backup | `logos:aws-backup` |
| Secrets Manager | `logos:aws-secrets-manager` |
| KMS (key management) | `logos:aws-kms` |
| CloudWatch (monitoring) | `logos:aws-cloudwatch` |
| API Gateway | `logos:aws-api-gateway` |
| SNS / SQS (messaging) | `logos:aws-sns` / `logos:aws-sqs` |
| Cognito (identity) | `logos:aws-cognito` |

## Azure — icon guidance

The iconify `logos` pack has the **overall Azure** logo (`logos:microsoft-azure`) but
**not** reliable per-service Azure logos. Use `logos:microsoft-azure` for the Azure
boundary group, and the built-in icon below for each service. The label carries the
exact service name.

| Azure service / role | Built-in icon | Suggested label |
|----------------------|---------------|-----------------|
| Azure subscription / region boundary | `cloud` (or group `logos:microsoft-azure`) | `Azure — UK South` |
| Azure Front Door + WAF | `internet` | `Front Door (WAF)` |
| Application Gateway (WAF, private) | `internet` | `App Gateway (WAF)` |
| Fortigate NVA / firewall | `internet` | `Fortigate NVA` |
| App Service Plan / Web App | `server` | `App Service` |
| Azure Container Apps | `server` | `Container Apps` |
| Virtual Machine | `server` | `VM` |
| Azure SQL Database / failover group | `database` | `Azure SQL` |
| Storage account (Blob) | `disk` | `Storage (ZRS)` |
| Key Vault | `disk` | `Key Vault` |
| Recovery Services / Backup vault | `disk` | `Backup vault` |
| Azure Monitor / App Insights | `server` | `Monitor / App Insights` |
| Microsoft Sentinel (SOC) | `cloud` | `Sentinel (SOC)` |

> When a viewer supports registering additional iconify packs, teams may substitute a
> dedicated Azure icon pack. Keep the built-in fallback so the diagram renders anywhere.

## Per-tier reference diagrams

Use these as starting points and adapt them to the actual services in the PRD. Keep
the availability-zone / region structure that defines each tier.

### Azure — Tier 1a (Mission-Critical, active-active, cross-region)

```mermaid
architecture-beta
    group azure(logos:microsoft-azure)[Azure]
    group uks(cloud)[UK South] in azure
    group ukw(cloud)[UK West] in azure

    service fd(internet)[Front Door WAF] in azure
    service apps(server)[App Service] in uks
    service sqls(database)[Azure SQL primary] in uks
    service stors(disk)[Storage RA GZRS] in uks
    service appw(server)[App Service] in ukw
    service sqlw(database)[Azure SQL secondary] in ukw

    fd:B --> T:apps
    fd:B --> T:appw
    apps:R --> L:sqls
    appw:R --> L:sqlw
    sqls:B --> T:sqlw
    apps:B --> T:stors
```

### Azure — Tier 1b (Enhanced, single region, zone-redundant)

```mermaid
architecture-beta
    group azure(logos:microsoft-azure)[Azure UK South]

    service fd(internet)[Front Door WAF] in azure
    service app(server)[App Service zone redundant] in azure
    service sql(database)[Azure SQL zone redundant] in azure
    service stor(disk)[Storage ZRS] in azure
    service kv(disk)[Key Vault] in azure

    fd:R --> L:app
    app:R --> L:sql
    app:B --> T:stor
    app:B --> T:kv
```

### Azure — Tier 2 (Standard, two AZs)

```mermaid
architecture-beta
    group azure(logos:microsoft-azure)[Azure UK South]

    service fd(internet)[Front Door WAF] in azure
    service app(server)[App Service instances >= 2] in azure
    service sql(database)[Azure SQL zone redundant] in azure
    service stor(disk)[Storage ZRS] in azure

    fd:R --> L:app
    app:R --> L:sql
    app:B --> T:stor
```

### Azure — Tier 3 (Standard, private ingress, containers)

```mermaid
architecture-beta
    group azure(logos:microsoft-azure)[Azure UK South]

    service agw(internet)[App Gateway WAF private] in azure
    service aca(server)[Container Apps] in azure
    service sql(database)[Azure SQL zone redundant] in azure
    service stor(disk)[Storage ZRS] in azure

    agw:R --> L:aca
    aca:R --> L:sql
    aca:B --> T:stor
```

### Azure — Tier 4 (Standard, single zone, cost-optimised)

```mermaid
architecture-beta
    group azure(logos:microsoft-azure)[Azure UK South single AZ]

    service fd(internet)[Front Door WAF] in azure
    service app(server)[App Service single instance] in azure
    service sql(database)[Azure SQL single db] in azure
    service bak(disk)[Backup GRS] in azure

    fd:R --> L:app
    app:R --> L:sql
    sql:B --> T:bak
```

### AWS — Tier 1a equivalent (multi-Region, active-active, derived mapping)

```mermaid
architecture-beta
    group aws(logos:aws)[AWS]
    group r1(logos:aws-vpc)[eu-west-2] in aws
    group r2(logos:aws-vpc)[eu-west-1] in aws

    service dns(logos:aws-route53)[Route 53] in aws
    service cdn(logos:aws-cloudfront)[CloudFront WAF] in aws
    service alb1(logos:aws-elb)[ALB] in r1
    service ecs1(logos:aws-ecs)[ECS] in r1
    service db1(logos:aws-aurora)[Aurora Global primary] in r1
    service alb2(logos:aws-elb)[ALB] in r2
    service ecs2(logos:aws-ecs)[ECS] in r2
    service db2(logos:aws-aurora)[Aurora Global secondary] in r2

    dns:B --> T:cdn
    cdn:B --> T:alb1
    cdn:B --> T:alb2
    alb1:R --> L:ecs1
    ecs1:R --> L:db1
    alb2:R --> L:ecs2
    ecs2:R --> L:db2
    db1:B --> T:db2
```

### AWS — Tier 1b / 2 equivalent (multi-AZ, single Region, derived mapping)

```mermaid
architecture-beta
    group aws(logos:aws-vpc)[AWS eu-west-2]

    service cdn(logos:aws-cloudfront)[CloudFront WAF] in aws
    service alb(logos:aws-elb)[ALB across AZs] in aws
    service ecs(logos:aws-ecs)[ECS tasks >= 2] in aws
    service db(logos:aws-rds)[RDS Multi AZ] in aws
    service s3(logos:aws-s3)[S3] in aws

    cdn:B --> T:alb
    alb:R --> L:ecs
    ecs:R --> L:db
    ecs:B --> T:s3
```
