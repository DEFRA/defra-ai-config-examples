---
name: infra-diagram
description: Produces an infrastructure architecture diagram as a Mermaid `architecture-beta` block, using cloud-provider brand logos (via the iconify `logos:` pack) where they exist and clearly labelled built-in icons as a fallback. Use this to visualise a cloud reference architecture (Azure or AWS) for a given Defra service tier so infrastructure is easy to review.
user-invocable: true
argument-hint: "[cloud] [tier] and/or the reference-architecture description to draw"
---

You turn a described cloud reference architecture into a clear, correct **Mermaid
`architecture-beta`** diagram, preferring real provider **logos** so the picture is
easy to recognise. Use British English in all labels.

## Inputs

You need enough to draw the target infrastructure:

- **Cloud platform** — `Azure` or `AWS`.
- **Service tier** — `1a`, `1b`, `2`, `3`, or `4` (optional but preferred; it fixes the
  region/availability-zone shape).
- **The architecture to draw** — either a written reference-architecture summary (for
  example the tier summary in `output/architecture-requirements.md` or the
  `cloud-tier-requirements` skill) or a list of the services involved.

If the cloud is not given, ask. If the tier is not given, either ask or infer the shape
from the description — do not invent components that are not in the source.

## Steps

1. **Read the icon map.** Read `reference/icon-map.md` in this skill. It lists the
   verified `logos:` icon names (AWS is well covered), the Azure icon guidance, and a
   ready-made per-tier reference diagram you can adapt.

2. **List the components.** From the source description, list every group (region,
   availability zone, VNet/VPC, or logical tier) and every service (ingress/WAF,
   compute, database, storage, key vault, backup, monitoring, identity). Do not add
   components that are not evidenced in the source.

3. **Assign an icon to each node** using the rules in the icon map:
   - Use a specific `logos:` brand icon when one exists (best for AWS).
   - Otherwise use the closest **built-in** icon (`cloud`, `database`, `disk`,
     `internet`, `server`) and put the exact service name in the `[Label]`.
   - Use `logos:microsoft-azure` for an overall Azure boundary group.
   - Never invent an iconify name.

4. **Draw the diagram.** Write one `architecture-beta` block:
   - Declare groups first (regions/AZs), then services with `in <group>`, then edges.
   - Reflect the tier's resiliency shape — e.g. Tier 1a = two regions active-active;
     Tier 1b/2 = one region, multiple AZs; Tier 4 = single AZ.
   - Show the request path from public ingress (WAF/Front Door/CloudFront) through
     compute to data and storage, plus backup/replication edges where relevant.
   - Keep labels short but unambiguous; avoid characters that break Mermaid (prefer
     plain words and spaces over `()`, `/`, `:` inside labels).

5. **Add a legend line.** Immediately under the diagram add one short italic note:
   *"Logos render in viewers that support the iconify `logos` pack; elsewhere nodes
   show labelled generic icons."* This sets expectations for reviewers.

6. **Add a requirement-satisfaction note.** Under the legend, add a short
   **"How the architecture meets the requirements"** table that maps each tier
   objective to the specific piece(s) of infrastructure that satisfy it, so a reviewer
   can see *why* each requirement is met. Use one row per objective with three columns:

   | Requirement | Target | Satisfied by |
   |---|---|---|
   | Availability | e.g. 99.9% | the component(s) that deliver it, e.g. two active-active regions behind Front Door with health-probe failover |
   | Resiliency model | e.g. multi-AZ | e.g. zone-redundant compute + zone-redundant database |
   | RTO | e.g. 1 hour | e.g. IaC redeploy + geo-restore of the database |
   | RPO | e.g. 15 min | e.g. database point-in-time backup / geo-replication frequency |
   | Security patching | e.g. per policy | e.g. managed platform service / automated patch schedule |
   | SOC connection & log retention | e.g. 12 months | e.g. diagnostic settings forwarding to Sentinel / SOC workspace |
   | Public ingress protection | mandatory WAF | e.g. WAF on Front Door / Application Gateway |
   | Secrets management | managed vault | e.g. Key Vault / Secrets Manager |

   Only include rows for objectives that are actually in scope, and only name components
   that appear in the diagram. Draw the target values from the source
   (`output/architecture-requirements.md` or the `cloud-tier-requirements` skill) — do
   not invent figures. Keep each "Satisfied by" cell to a concise phrase.

7. **Validate.** If a Mermaid validation tool or the `validate-mermaid` skill is
   available, run it against the produced block and fix any errors before returning.
   Otherwise do a quick static check: `architecture-beta` header present, every service
   and group referenced by an edge is declared, `group`/`in` ids match, and brackets/
   parentheses are balanced.

## Output

Return the Mermaid `architecture-beta` block, its legend line, and the
"How the architecture meets the requirements" mapping table. When invoked by another
agent to embed a diagram in a document, insert the block (and the note) at the requested
location rather than returning it standalone.

## Rules

- Prefer correct brand **logos**; fall back to labelled built-in icons rather than a
  wrong or non-existent icon. Missing logos must never break the diagram.
- Draw only what the source describes — never fabricate infrastructure.
- Keep the OFFICIAL classification of any source material intact; add no data beyond
  what you were given.
