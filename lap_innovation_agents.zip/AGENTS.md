# LAP Innovation Agents

A set of GitHub Copilot custom agents and skills for Defra's Legacy Application Programme (LAP). They help engineers reverse engineer legacy applications — turning screenshots, interview transcripts, and source code into a Product Requirements Document (PRD) and a set of individually deliverable, standards-compliant feature specifications ready to build.

## Context

Defra maintains a large estate of legacy applications built across decades using a variety of technologies. The LAP programme aims to understand, document, and modernise these systems. These agents run inside GitHub Copilot in VS Code — there is no separate CLI, container, or build step.

## Data classification

**Only use these agents on source material classified as OFFICIAL.** Do not use them with material at any higher classification. If you are unsure about the classification of your source material, seek guidance before proceeding.

## Conventions

- Use British English in all generated documentation and agent output.
- Refer to the programme as "LAP" or "Legacy Application Programme".
- Treat all legacy code as potentially undocumented — never assume documentation exists, and never fabricate domain knowledge that is not evidenced in the source material.
- Every generated artefact begins with a provenance block listing the input files it was derived from.
- When adding a new agent or skill, update the tables in `README.md`.

## Baked-in delivery standards

Every PRD and feature specification produced by these agents must embed Defra's delivery standards from the outset, not as an afterthought. The authoritative statement of these standards is [.github/instructions/lap-delivery-standards.instructions.md](.github/instructions/lap-delivery-standards.instructions.md), which is always in scope. In summary:

- **Defra software development standards** and the GDS Service Standard / Technology Code of Practice.
- **Test coverage of at least 90%**, with every acceptance criterion mapped to a named automated test.
- **WCAG 2.2 level AA** for all user interfaces.
- **Secure by design** (OWASP Top 10), observability, and cloud well-architected principles.
- **Cloud service-tier requirements** derived from the Defra CCoE Azure Service Tier Reference Architecture, applied by the `cloud-tier-architect` agent for the chosen cloud (AWS or Azure) and service tier (1a, 1b, 2, 3, 4).

A companion standard, [.github/instructions/lap-analysis-depth.instructions.md](.github/instructions/lap-analysis-depth.instructions.md), sets the **rebuild-grade depth** every analysis and the PRD must reach: exhaustive, quantified, evidence-cited enumeration (every screen, field, route, rule, column), grounding labels (`doc-grounded`/`code-grounded`/`inferred`), and the `D`/`S`/`R`/`OQ`/`G` registers consolidated into `output/open-questions.md`.

## No silent loss of functionality

When the feature specifications are handed to an autonomous build loop (Copilot Ralph), functionality must never be dropped silently. Every legacy capability is tracked end to end with a stable identifier and is either implemented and tested, or explicitly deferred with a recorded justification in the descope register. See the `completeness-auditor` agent and the traceability artefacts (`output/features/manifest.json`, `output/traceability.md`, `output/descope-register.md`).

The shareable documentation pack (`output/documentation-pack.html`, produced by the `html-pack` skill) makes this visible by default: it always surfaces an **Open questions** view and a **Functionality coverage (no silent loss)** view derived from the traceability manifest, so open decisions and any deferrals are impossible to miss.

## Pipeline

1. **Curate** — `digital-content-curator` converts screenshots to semantic HTML mockups and curates transcripts.
2. **Analyse** — `application-developer` and `database-analyst` read `src/`; `business-analyst` and `interaction-analyst` read the curated content.
3. **Synthesise** — `product-manager` weaves the four analyses into `output/PRD.md`.
4. **Apply cloud tier** — `cloud-tier-architect` injects the tier's non-functional and architecture requirements into the PRD and writes `output/architecture-requirements.md`.
5. **Decompose** — `prd-to-features` breaks the PRD into `output/features/FT-*.md` (via `feature-writer`) and emits the traceability manifest.
6. **Package** — the `html-pack` skill renders every output document into one self-contained, offline interactive HTML pack (`output/documentation-pack.html`) with always-present **Open questions** and **Functionality coverage (no silent loss)** views. This is the default shareable format for every run.
7. **Build & assure** — the feature specs, manifest, pack, and `completeness-auditor` are seeded into the new build repository so nothing is lost during implementation.
8. **Document as an example** — once a project is modernised, `modernisation-example-writer` turns the PRD and the new code into a publishable LAP blueprint modernisation-example (project playbook) page (`output/modernisation-example.md`), so every project documents itself as a reusable example going forwards.

The `lap-orchestrator` agent can run this whole pipeline for you.
