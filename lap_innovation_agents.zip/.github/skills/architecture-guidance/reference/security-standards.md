<!-- SYNCED FROM AZURE DEVOPS WIKI — DO NOT EDIT BY HAND (overwritten on next sync).
     Source: https://dev.azure.com/defragovuk/CCoE-Architecture-Foundation wiki 'CCoE-Architecture-Foundation.wiki'
     Pages: /Guidance/Cloud Guidance SOC Integration; /Guidance/Cloud Guidance Azure Web Application Firewall; /Guidance/Cloud Guidance Azure Privileged Identity Management; /Guidance/Cloud Guidance Enterprise Scale Identity and Access Management; /Guidance/Cloud Guidance Azure Back End Operator Access; /Guidance/Cloud Guidance Azure DDoS Protection; /Patterns/AZR Cloud Patterns Protective Monitoring Applications; /Patterns/AZR Cloud Patterns Protective Monitoring Infrastructure
     Fetched: 2026-08-19T14:08:34.871Z
     Classification: OFFICIAL -->

<!-- wiki page: /Guidance/Cloud Guidance SOC Integration (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20SOC%20Integration) -->

# Cloud-Guidance-SOC-Integration

> > **VERSION 1.1 - 10-06-2021**
> See [Document Version Control](#document-version-control) for full version history

- [Background and Scope](#background-and-scope)
  - [Introduction](#introduction)
  - [Solution Providers](#solution-providers)
- [Solution Overview](#solution-overview)
- [Azure SOC Components](#azure-soc-components)
  - [Event Hubs](#event-hubs)
    - [Event Hub Namespace configuration](#event-hub-namespace-configuration)
  - [Log Analytics Workspace](#log-analytics-workspace)
  - [Azure Lighthouse and the Sentinel incident view](#azure-lighthouse-and-the-sentinel-incident-view)
  - [Storage Account resources](#storage-account-resources)
  - [Logic/Function Apps](#logicfunction-apps)
- [Operational Protective Monitoring](#operational-protective-monitoring)
  - [Diagnostic policy implementation](#diagnostic-policy-implementation)
  - [IaaS messages and third party log files](#iaas-messages-and-third-party-log-files)
- [Application Protective Monitoring](#application-protective-monitoring)
  - [Application Event Hubs](#application-event-hubs)
  - [Application message filtering](#application-message-filtering)
  - [Sentinel Integration](#sentinel-integration)
  - [Messages originating from the application](#messages-originating-from-the-application)
  - [Messages extracted from application insights](#messages-extracted-from-application-insights)
  - [Event Hub message forwarding (Logic App)](#event-hub-message-forwarding-logic-app)
- [Resource Configuration Settings](#resource-configuration-settings)
  - [Application Event Hub Namespace](#application-event-hub-namespace)
  - [Event Hub configurations (App Namespace)](#event-hub-configurations-app-namespace)
    - [Common Hub configuration settings](#common-hub-configuration-settings)
  - [Log Analytics Workspace Configuration](#log-analytics-workspace-configuration)
  - [Storage Account](#storage-account)
  - [Logic Apps](#logic-apps)
    - [Application Event Logic App](#application-event-logic-app)
    - [6.5.2 Application Log Analytics Logic App](#652-application-log-analytics-logic-app)
- [Azure Configuration Settings](#azure-configuration-settings)
  - [Subscription Security Settings](#subscription-security-settings)
  - [Naming Conventions](#naming-conventions)
    - [Resource Group](#resource-group)
    - [Local Event Hub Namespace (legacy)](#local-event-hub-namespace-legacy)
    - [Local Event Hub Namespace (hub/spoke)](#local-event-hub-namespace-hubspoke)
    - [Logic App (hub/spoke)](#logic-app-hubspoke)
  - [Logic App Configuration](#logic-app-configuration)
  - [Security Considerations](#security-considerations)
    - [Event Hub Security](#event-hub-security)
    - [ASE Firewall changes](#ase-firewall-changes)
  - [Storage Account configuration](#storage-account-configuration)
  - [Event Hub Namespace Configuration](#event-hub-namespace-configuration-1)
  - [Log Analytics Workspace Configuration Detail](#log-analytics-workspace-configuration-detail)
- [Security Configuration](#security-configuration)
  - [Azure Security Roles and Groups](#azure-security-roles-and-groups)
- [Defra Hosting Regions](#defra-hosting-regions)
  - [Region Considerations for Log Analytics](#region-considerations-for-log-analytics)
- [Appendix A: Microsoft SOC Design Decisions](#appendix-a-microsoft-soc-design-decisions)
  - [Microsoft SOC recommendations](#microsoft-soc-recommendations)
    - [Decision 1 & 2: Log Analytics Workspace](#decision-1--2-log-analytics-workspace)
    - [Decision 3: Enable Azure resource diagnostics](#decision-3-enable-azure-resource-diagnostics)
    - [Decision 4: Application Gateway WAF mode](#decision-4-application-gateway-waf-mode)
    - [Decision 5: Azure Event Hub availability](#decision-5-azure-event-hub-availability)
    - [Decision 6: Azure subscription security level](#decision-6-azure-subscription-security-level)
- [Appendix B: Diagnostic Configuration Scripts](#appendix-b-diagnostic-configuration-scripts)
- [Appendix C: Resource Config and Naming](#appendix-c-resource-config-and-naming)
  - [Document Version Control](#document-version-control)

## Background and Scope

### Introduction

Defra have adopted a cloud first policy for future projects and has selected two cloud providers Amazon (AWS) and Microsoft (Azure) as solution providers. This document covers the areas related to Azure.

To provide fully 24*7 operation, a 3rd party supplier (CGI) has been engaged to monitor the SIEM out of normal business hours.

Upon its release in 2019, Defra began to implement Azure Sentinel to supplement the current QRadar monitoring tools. Since then, Azure Sentinel has matured into a tool that can stand on its own and has been running as the primary SIEM supporting Defra Azure environment since October 2020.

The purpose of this document is to provide a concise overview of the Sentinel SIEM configuration within the Defra Azure environment.  

### Solution Providers

Azure Sentinel was developed in conjunction with Microsoft Consultancy services, The original design featured extensive infrastructure to pass diagnostic data into QRadar. Following the decision to make Sentinel the prime SIEM, this has been removed.

| Provider   | Role                                                                   |
|:--------   | -------------                                                          |
| Microsoft  | Define the Azure diagnostic configuration settings for Azure.
|| Provide configuration scripts for those settings.
||Provide manual instructions where an automated solution is unavailable.          |
| Defra      | Implement diagnostic settings into Azure ARM templates.|
|| Execute scripts to apply diagnostic settings to deployed resources.
|| Implement manual security configurations where applicable.
|| Define and deploy an application preventative solution. |

## Solution Overview

There are two aspects to protective monitoring (application and operational).

Application Protective Monitoring (APM) involves the management and processing of alerts generated by the application itself, whereas operational protective monitoring involves alerts arising from diagnostics associated with the Azure resources.

All diagnostic information is held in two locations.

1. Azure Log Analytics Workspace, Short term (90 days) storage.
1. Azure Blob Storage, Long Term (365 days) storage.

Azure Sentinel have been implemented which provides personnel with capability to view, manage, investigate, and respond to the incidents and alerts raised.

Sentinel has the ability to ingest information from almost any source via bespoke connectors, or in common formats (syslog, CEF).

![Figure 1 Sentinel Ingestion capabilities](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig1v2.jpg)

## Azure SOC Components

To deliver messages from the application/Azure resources to the SIEM, the following Azure capabilities are employed.

| Capability | Description |
| --------- | ------------|
|Event hubs | Event hubs are capable of processing thousands of messages per second and provide a storage buffer, should anything go wrong with the streaming process. ``Event Hubs can hold data for 7 days``|
|Log Analytics| Messages are written to Log Analytics for processing by **Sentinel**. ``A log analytics workspace can hold data for 90 days with Sentinel enabled. Holding data for longer than this is possible but will incur additional charges.``|
|Storage Account| Azure diagnostic data is written to a storage account for long-term storage in case of future investigations. ``A storage account can hold data indefinitely, but storage costs will be incurred.``|
|Logic App |Logic apps are used to read messages and forward them to the next processing stage.|

### Event Hubs

Event Hubs are a means for processing thousands of messages from multiple sources sequentially. Event hubs are configured inside an **Event Hub Namespace**.

Messages are fed into the Event Hub where they are held in a queue until processed by an external reader. In the case of Application Protective Monitoring, this is a logic app.

#### Event Hub Namespace configuration

Each application has an Event Hub that can be used to hold audit messages raised by the application itself. These messages relate purely to the application state and are defined by the development team. They have no relationship to the condition of the underlying platform.

**Application Event Hubs**
The Application namespace hosts a single Event Hub to handle application messages.

    insights-application-logs   -   Application specific messages

>Note: Although the names of the Event Hubs begin with ‘insights’, they have nothing to do with application-insights. The naming convention results from a Mandatory naming convention enforced by Microsoft.

### Log Analytics Workspace

Each tenant has a dedicated log analytics workspace `defraoms-<tenant>`. The Log Analytics Workspace holds diagnostic messages, performance metrics and IaaS services management information.

All Log Analytics operational messages are stored in this workspace in accordance with the preferred Microsoft pattern of a single workspace per tenant.

All virtual machines are connected to the defraoms workspace as it is used to manage the patching and maintenance capability.

| Tenant                 | Description                | Log Analytics              |
| -------                | --------                   | ------                     |
| Defra                  | Original Defra Azure tenant| defraoms                   |
| DefraCloud             | Original Defra Azure tenant| defraoms-defracloud        |
| DefraCloudPreprod      | Original Defra Azure tenant| defraoms-defracloudpreprod |
| DefraCloudDev          | Original Defra Azure tenant| defraoms-defraclouddev     |

The defraoms workspace data is consumed by the following services.

- Azure Security Center Used to analyse Azure diagnostic information
- Azure Sentinel                    Cloud-native Microsoft SIEM
- Azure Update management solution  Virtual Machine patch management.

>Microsoft Log Analytics workspace design is a compromise of functionality over cost as it is possible to pay for data twice (ingestion & Sentinel processing). Defra have attempted to stick to the ‘Single Workspace ethos’, but costs may mean that this design is revisited.

### Azure Lighthouse and the Sentinel incident view

As well as being able to map onto each workspace in its own tenant using Sentinel, it is also possible to simultaneously access multiple workspaces across other tenants using Azure lighthouse. Lighthouse does this by delegating RBAC roles to those tenants.

If you select multiple Log Analytics workspaces together, then sentinel will switch to incident mode and display incidents from all selected workgroups in a single panel. It is possible to manage incidents and query related data directly through the incidents panel.

![Figure 2 Selecting Multiple Log Analytics Workspace](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig2v2.jpg)
**Selecting Multiple Log Analytics Workspace**

Below is a diagram that demonstrates the Sentinel Incident view across multiple tenants. Note that the Workspace and Directory represent different tenants.

![Figure 3 The Sentinel Incident View](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig3v2.jpg)
**The Sentinel Incident View**

>Note:  Although the above is a single view, it does represent multiple independent systems. As a result, the Incident ID is unique within a tenant but duplicate IDs may appear in the above view. It is important to include the Incident ID and the Directory when referencing an Incident.

### Storage Account resources

The purpose of the storage account is to provide a long-term repository that will hold diagnostic information longer periods. Currently, this is set to 1 year, but can be extended indefinitely if required.

Most Azure resources have the capability to write diagnostics to a Storage Account. When diagnostics are configured on the resource, a storage container in the Azure Blob storage is automatically created and logs are stored in a JSON format, per subscription & resource.

Resources from multiple subscriptions are configured to utilise the same Storage Account.

For Example: A production SOC storage account will hold data from multiple PRD subscriptions.

### Logic/Function Apps

Where resources do not have the capability to log directly to Azure, the log ingestion feature of Azure Security Center is used to import log files into Log Analytics. The analytics workspace is then queried and recently added data is posted to the Event Hub.

This query/post process is handled using a combination of Logic and Function apps. The Logic App retrieves the data from the workspace using a KQL query and the function app takes the query results, parses them and posts onto the target Event Hub.

There are three main scenarios when Logic/function apps are used.

**3rd Party apps + Dynamics & B2C content**
When a 3rd part app creates its own log files – ASC can ingest these files

**Azure IaaS services**
Specific Windows Event/Syslog messages are ingested into log analytics.

**Application Event Hubs**
Messages that are written to the application event hub are ingested into Sentinel.

## Operational Protective Monitoring

Operational protective monitoring is based on the audit and diagnostic information generated by each Azure resource. Resources are configured to route diagnostic and logging information to three separate locations using a separate diagnostic rule for each.

The information sent can be audit, diagnostic or metric – the specific settings for each Azure resource type are located in the diagnostics configuration of the resource.

| Rule Name                    | Storage Account      | Event Hub                                  | Log Analytics | Log Types     | Retention Period |
| ---------------------------- | -------------------- | ------------------------------------------ | ------------- |-------------- | ---------------- |
| SetByPolicyLogAnalytics      |                      |                                            | defraoms      | Audit         | 30 Days          |
| SetByPolicyStorage           | opssocinfsto001      |                                            |               | Audit,metric  | 365 Days         |

### Diagnostic policy implementation

Diagnostic settings are configured using Azure management policies associated with the subscription. Any Azure resource covered by the policy will be automatically configured.

The policy rules are as follows:

    SetByPolicyLogAnalytics  -  Defines the Log Analytics workspace diagnostics
    SetByPolicyStorage       -  Defines the Storage Account diagnostics

Policies are applied to Azure management groups. This allows a general policy to be applied to a group of similar subscriptions (e.g. Dev), but where a different policy is required, it can be applied lower down the management tree.

### IaaS messages and third party log files

Certain Azure resources cannot pass data directly to an Event Hub. Instead, the log data takes the form of flat data files, custom logs, csv files etc.  Azure Sentinel addresses this by providing dedicated connectors that will ingest these log files into the Log Analytics Workspace.

## Application Protective Monitoring

Application Protective Monitoring defines the approach for routing security messages originating from a Defra application. Messages are written to their own application Event Hub, whereupon they are collected and written to Sentinel using a dedicated logic application.

### Application Event Hubs

To ensure separation at the project level, then each application has a dedicated namespace hosting an Event Hub named ‘Insights-application-logs’.

Each application Event Hub sits in its own Event Hub Namespace.

Associated with the Application Event Hub is a logic app that forwards any events into the Sentinel Log Analytics Workspace.

Messages can originate from various sources, the two primary ones being:

- Messages being written directly from the application
- Messages extracted from application insights and pushed into the hub

![Message data flow](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig4v2.jpg)
**Message data flow**

As can be seen from the above diagram, SOC information identified by the project is written to the application Event Hub. A logic app monitoring that Event Hub will forward messages into Sentinel.

### Application message filtering

There exists a scenario, where the developer has no control over the granularity of messages being passed to the Application Event Hub. To ensure that only the required messages reach their destination, the application writes to a dedicated application Log Analytics workspace and a logic app will select the relevant information from that workspace and forward it to the Application Event Hub.

![Application Protective Monitoring (Filter Events)](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig5v2.jpg)
**Application Protective Monitoring (filter events)**

### Sentinel Integration

For Sentinel to be able to respond to Application Protective Monitoring alerts, several custom logs have been established within the Log Analytics Workspace.

| Custom Log Name |  Comment       |
| --------------- |  ------------- |
| Application_Protective_Monitoring_prd_CL      |  Production    |
| Application_Protective_Monitoring_pre_CL      |  Preprod       |
| Application_Protective_Monitoring_tst_CL      |  Test          |
| Application_Protective_Monitoring_dev_CL      |  Development   |
| Application_Protective_Monitoring_snd_CL      |  Sandpit       |

Application Protective Monitoring messages are fed into Log Analytics using a Logic App that relays messages from the Event Hub.

![Application Protective Monitoring - Sentinel integration](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig6v2.jpg)
**Application Protective monitoring - Sentinel integration**

### Messages originating from the application

Microsoft provides a number of APIs that allow messages to be written to Event Hubs in various languages (.net, Java etc.).   Using these APIs, the developer has full control over what messages are written to the event hub.

The preferred format for these messages is JSON.

### Messages extracted from application insights

By setting up a continuous export to a storage account, messages written by an application to the ‘Application Insights’ repository can be transferred to the event hub using a Logic App.

This functionality is not currently required, but is in place should the requirement arise.

### Event Hub message forwarding (Logic App)

The application Event Hubs are queried using a timed Logic App to query the application Event Hub and forward any messages into the QRadar Event Hub.

No filtering takes place within the app and all messages are forwarded.

## Resource Configuration Settings

The following is a summary of the configuration items required to setup the various components of the SOC Azure resources.

### Application Event Hub Namespace

    Name:                   :   <env><app>SOCENSnnn
    Pricing Tier            :   Standard
    Subscription            :   AZR-<env>
    Resource Group          :   <env>SOCINFRGP001
    Location                :   North Europe
    Throughput Units        :   1
    Enable Auto Inflate     :   checked
    Auto-inflate Max TU     :   2
    Enable Zone Redundancy  :   checked

### Event Hub configurations (App Namespace)

All application Event hubs are configured identically, the only difference being the name itself. Remember, the app namespace contains a single dedicated Event Hub named insights-application-logs.

#### Common Hub configuration settings

    Resource
    Partition Count     :   2
    Message Retention   :   7 days
    Capture             :   Off

    Settings
    Shared Access Policies
    Policy Name         :   QRadar_APP
    Manage              :   unchecked
    Send                :   checked
    Listen              :   checked

> The QRadar_APP policy name will be renamed under change control

### Log Analytics Workspace Configuration

The Microsoft best practise for moving messages into the Event Hub (and on to QRadar) is by using a Log Analytics Workspace as the message source. Messages are moved from the workspace to the Event Hub using a logic/function app.

It is the responsibility of the project to develop the processes for ingesting data into the Log Analytics Workspace, as well as providing the application logic to select the relevant data from the workspace for transfer to the Application Event Hub.

Should an application Workspace be required to hold application based analytics data, then the workspace should follow the `<env><app>SOCLAWnnn` naming standard.

![Application message flow](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig7v2.jpg)
**Application message flow**

### Storage Account

Log and Metrics data is also written to a Storage Account for long-term data storage. This information is held in a blob. Information is held in separate containers, dependent on the log type.

![Storage Account log containers](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig10.jpg)

### Logic Apps

Logic Apps are compute processes that take messages from the Defra application environment and pass them to Sentinel. There is a Logic app (LA) for each role an Event hub performs.

#### Application Event Logic App

The Application Event LA will take data from the application event hub `<env><app>SOCENS001\insights-application-logs` and write it to the Sentinel Event hub.

![Logic App structure](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig11.jpg)

#### 6.5.2 Application Log Analytics Logic App

The Application Log Analytics LA contains a series of queries that select data from the Application Log Analytics workspace `<env><app>SOCENS001\SOCALA001)`  and write it to the Application Event Hub.

![Application Log Logic App structure](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig8v2.jpg)

## Azure Configuration Settings

### Subscription Security Settings

To enable the advanced reporting capabilities required for effect event reporting, the target subscription has to have its security setting raised to **‘Standard’**.

> Note: Raising a subscription to standard is an Azure commercial activity.

### Naming Conventions

 The standard Azure resource naming convention will be utilised.

`<subscription><project><resource category><resource type><instance>`

#### Resource Group

All SOC resources reside in a single resource group which follows the standard naming convention with a resource type of RGP, RG (for legacy, Hub\spoke respectively)

For example,
  The Sandpit SOC resource group name is  : SNDSOCINFRGP001
  The EOB SOC resource group is           : SNDEOBSOCRG1001

#### Local Event Hub Namespace (legacy)

The local Event hub namespace has a single Event hub

For example in the AZR-SND subscription for Imports

  Event Hub Namespace             :   SNDIMPSOCENS001
  Event Hub                       :   Insights-application-logs
  Event Hub shared access policy  :   Sentinel_APP

#### Local Event Hub Namespace (hub/spoke)

The local Event hub namespace has a single Event hub

For example in the AZR-SND subscription for EOB

  Event Hub Namespace             :   SNDEOBSOCEN1001
  Event Hub                       :   Insights-application-logs
  Event Hub shared access policy  :   Sentinel_APP

#### Logic App (hub/spoke)

`<subscription><project><resource category><resource type><instance>`

For example in the AZR-SND subscription for EOB

  SOC Logic App (application)     :   SNDEOBSOCAL1001
  SOC Logic App (operational)     :   SNDEOBSOCAL1002

### Logic App Configuration

The logic app is a timed trigger that will check to see if these are any messages in the connected local Event Hub and forward to Sentinel.

![Application Logic App Configuration](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig12.jpg)

As can be seen from the above example, the logic app will check the ‘insights-application-logs’ Event hub in the SNDBOOSECENS001 namespace and pass the content onto the QRadar hub SNDSOCINFENS001

>Important note: When configuring the ‘Send Event to use a content type other than ‘application/json’, it is important to add the highlighted code to the ‘Definition’ section. Failure to do so will result in a ‘Base 64 conversion error’ when running the app.

![Logic App structure](/Guidance/.Diagrams/CSC-AZR-TDD-SOC-Fig13.jpg)

The test can be added be selecting ‘Logic app code view’ from the portal, adding the above text and then clicking save.

### Security Considerations

Although it is possible to VNET integrate Event Hubs, there are a number of issues at the network level when doing so. For applications embedded in an ASE, then it becomes impossible for a logic app to communicate with the Event Hub via the service endpoint.

Event Hubs and Logic app interactions are documented by Microsoft, but with caveats when using service endpoints.

As a result, it is not possible to use Service Endpoints at this time as a method for securing communications.

#### Event Hub Security

Access to the Event Hubs is accomplished using a combination of ‘Hub Access policies’ and shared access keys.

A shared access policy (**QRadar_APP**) has been created with **Listen** and **Send** roles on each local Event Hub with the resulting connection strings being stored in keyvault / passed to developers.

A shared access policy (**QRadar_EVH**) has been created with a **Listen** and **send** roles on each local Event Hub with the resulting connection strings being stored in keyvault / passed to developers.

#### ASE Firewall changes

For applications that are embedded within an Application Service Environment (ASE), then an additional Outbound rule needs to be added to the ASE NSG.

  Rule        :   315
  Name        :   `allow-<env>-<project>-ase-eventhub-soc-outbound`
  Ports       :   5671, 5672
  Protocol    :   TCP
  Source      :   any
  Destination :   Eventhub.NorthEurope

### Storage Account configuration

Each subscription has a storage account dedicated to the logging of diagnostic, Audit and metrics. SOC storage accounts have the following generic configuration.

| Parameter                 | Setting                                                       |
| ------------------------- | ------------------------------------------------------------  |
| Replication               | Read-access geo-redundant storage (RA-GRS)                    |
| Location                  | North Europe, West Europe                                     |
| Performance/Access tier   | Standard/Hot                                                  |
| Account kind              | StorageV2 (general purpose v2)                                |
| Secure Transfer           | Enabled                                                       |
| Network Access            | Selected Networks, Allow trusted Microsoft Services access    |

### Event Hub Namespace Configuration

| Parameter                    | Setting                                             |
| ---------------------------- | --------------------------------------------------  |
| Pricing Tier                 | Standard                                            |
| Throughput Units             | 1 unit                                              |
| Auto Inflate Throughput      | Disabled                                            |
| Shared Access Policies       | RootManageSharedAccessKey (Manage, Send, Listen)    |
| Firewall configuration       | All networks                                        |
| Operational Event Hub name   | Insights-operational-logs                           |
| Application Event Hub name   | Insights-application-logs                           |
| Dynamics Event Hub Name      | Insights-dynamics-logs                              |
| Event Hub message retention  | 7 Days                                              |
| Event Hub partition count    | 4                                                   |
| Event Hub capture            | Disabled                                            |

### Log Analytics Workspace Configuration Detail

| Parameter       | Setting              |
| --------------- | -------------------  |
| Pricing Tier    | OMS  (per node)      |

> Note: Pricing is changing to a per GB model – older subscriptions can still use OMS pricing.

## Security Configuration

### Azure Security Roles and Groups

User access to ASC resources is mainly Read Only. To accommodate this, a custom role has been configured called ‘DEFRA Custom Role – **SOC Security Admins**.

This role contains two groups:

`AG-Azure-SOC-Defra-SecurityCenterReaders`

This group pertains to the Defra SOC personnel who have the capability to read the ASC info. It will contain defra accounts

`AG-Azure-SOC-IBM-SecurityCenterReaders`

IBM Security personnel group pertains to the IBM personnel that have access to ASC. This will contain the external account IDs of the IBM team from Hursley.

## Defra Hosting Regions

Defra applications are hosted in two geographies. Each consists of a primary and secondary region

| Geography   | Primary        | Secondary     |
| ----------- | -------------  | ------------- |
| Europe      | Europe North   | Europe West   |
| UK          | UK South       | UK West       |

Defra applications are hosted in the primary region, with the secondary region present for Disaster Recovery purposes.

Azure diagnostics point to the Event Hub in-region, so any services running in NE will report to the NE Event Hub and the same for all other regions.

### Region Considerations for Log Analytics

Microsoft levy a data egress charge for passing data between regions. Microsoft have conflicting best practice scenarios where they state that a single Log Analytics Workspace is the preferential configuration, whilst also stating that diagnostic data should not be passed across region boundaries as data egress charges will apply.

## Appendix A: Microsoft SOC Design Decisions

### Microsoft SOC recommendations

Microsoft Consultancy Services made six recommendations in relation to the storing and forwarding of SOC messages.

The following design recommendations were approved at the Defra AGB. Since approval, a number of the ‘in preview’ items are now considered GA as well as the introduction of Azure Sentinel to aid discovery and analysis.

#### Decision 1 & 2: Log Analytics Workspace

*Microsoft recommend a single Log Analytics workspace to cover the production platform including AAD, PaaS and IaaS.*

Defra differs from the Microsoft recommendation as the entire Azure platform is held in a single workspace rather than restricting it to just the production environment. This is to ensure that Sentinel can observe the whole platform.

Defra already has a log analytics workspace for holding information relating to all Azure diagnostic PaaS and IaaS resources as well as AAD information. Information surrounding user activity, O365 etc. is managed through a separate MS Cloud App Security (CAS) process.

All Azure virtual machines are connected to this workspace for management and administration. As a result, all resource Log Analytics will be routed through this workspace.

Any application related logs that need to be hosted in analytics will receive their own application based analytics workspace. This in turn will feed their application Event hub.

#### Decision 3: Enable Azure resource diagnostics

*Microsoft recommend enabling specific diagnostic resources known as management packs.*

Defra have updated the base ARM templates to enable Azure diagnostics & regularly run scripts to tidy up the environment for any resources not built via ARM which may have had the settings missed.

>Note: Recently, it has become possible to enforce diagnostic settings based on Azure management policies. Defra have adopted a policy based approach to applying diagnostic settings to ensure consistency and remove the reliance on the build teams to configure diagnostic settings appropriately.
>
>Azure resource diagnostics can be turned on/off/modified by updating the parent policy.

#### Decision 4: Application Gateway WAF mode

*Microsoft recommend that the application Gateway WAF mode is enabled.*

Defra now have WAF mode enabled on all application gateways.

#### Decision 5: Azure Event Hub availability

*Microsoft recommend making the Event Hubs Geo-redundant.*

This decision has not yet been implemented, pending the decision to move to UK datacentres. Given the recent decision to maintain European regions then Geo-Redundancy will be re-assessed.

>Note: Since the initial recommendation, Microsoft have made Event Hub Namespaces aware of Availability Zones and so the above recommendation has changed. Geo-redundancy is for Disaster Recovery only and so no longer used.

#### Decision 6: Azure subscription security level

*Microsoft recommend that the level of security for each subscription is uplifted to Standard to provide an enhanced security platform.*

Defra have adopted this decision and all Azure subscriptions have been uplifted to ‘Standard’.

## Appendix B: Diagnostic Configuration Scripts

Microsoft have provided a number of scripts that will configure the diagnostic settings on Azure resources already deployed. The scripts have the capability to add/remove the diagnostic configuration dependent on the parameters passed.

The supporting documentation for these scripts is held in the CCoE website.

>Note: These scripts have now been superseded by management policies and are only included in this document for information purposes.

Four Scripts have been provided to configure Azure diagnostics

**NSGFlowLogs.ps1**
This script configures the NSG Flow log settings.

**SendToEventHub.ps1**
This script configures the resource to send diagnostic information to the local SOC event hub namespace containing the operational-insights-log Event Hub.

**SendToStorage.ps1**
This script configures the resource to send diagnostic and metric information to the local SOC storage account.

**SendToLogAnalytics.ps1**
This script configures the resource to send diagnostic and metric information to the local SOC Log Analytics Workspace.

## Appendix C: Resource Config and Naming

Key Configuration Parameters:-

    Event Hub Namespace :         Name                          *See naming convention*
                                  Pricing tier                  Standard
                                  Enable Kafka                  unchecked
                                  Make namespace Zone redundant checked
                                  Subscription                  *See naming convention*
                                  Resource Group                *See naming convention*
                                  Location                      North Europe / West Europe
                                  Throughput units              1
                                  Enable Auto-Inflate           unchecked
    
    Event Hub :                   Name                          *See naming convention*
                                  Partition Count               4
                                  Message Retention             7
                                  Capture                       Off
    Storage Account:               subscription                  *See naming convention*
                                  resource Group                *See naming convention*
                                  Name                          *See naming convention*
                                  Location                      North Europe/West Europe
                                  Performance                   Standard
                                  Account Kind                  StorageV2
                                  Replication                   RA-GRS
                                  Access Tier                   Hot
    Log Analytics Workspace:      Name                          *See naming convention*
                                  subscription                  *See naming convention*
                                  resource Group                *See naming convention*
                                  Location                      North Europe/West Europe
                                  Pricing Tier                  standard

Naming Conventions (Hub/Spoke)

    Common attributes   Subscription    The name of the host subscription   e.g. AZR-EOB-SND1
                                                                            /AZR-SND
                        Resource Group  The name of the SOC resource group  e.g. SNDSOCEOBRG1001 
                                                                            /SNDSOCINFRGP001
                        Location        The host region                     e.g. North Europe
                                                                            /West Europe

    Event Hub Namespace :<Env><App>SOC<Env-No.><instance>
                        AZR-EOB-PRD1                                        PRDEOBSOCEN1001
                        AZR-VMD-SND1                                        SNDVMDSOCEN1001
                        AZR-MMO-DEV1                                        DEVMMOSOCEN1001
    
    Event Hub names:    Name                                                insights-operational-logs
                                                                            insights-application-logs

---

### Document Version Control

| Version | Date      | Status | Change Summary | Reviewers/Approvers |
| ------- | --------  | ------ | -------------- | ------------------- |
| 1.1     | 10-06-2021| Released  | Released       | Shaun Frost, John Burton         |

Document Classification `OFFICIAL`


<!-- wiki page: /Guidance/Cloud Guidance Azure Web Application Firewall (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Azure%20Web%20Application%20Firewall) -->

# Cloud Guidance - Azure Web Application Firewall (WAF)

> **VERSION 1.1 - 04-02-2026**
> See [Document Version Control](#document-version-control) for full version history
---
[[_TOC_]]
  
## Executive Summary

This document provides guidance on the effective design, deployment and operation of Azure Web Application Firewall (WAF) to protect web applications hosted on Microsoft Azure. Azure WAF is a critical security control that helps defend applications against common web-based threats such as SQL injection, cross-site scripting (XSS) and other OWASP Top 10 vulnerabilities, and forms part of industry-recognised security best practice and compliance frameworks (for example [CIS 18.10](https://csf.tools/reference/critical-security-controls/version-7-1/csc-18/csc-18-10/), [PCI DSS](https://listings.pcisecuritystandards.org/documents/information_supplement_6.6.pdf)), while contributing to security, compliance efforts and operational resilience of applications.

The guidance outlines recommended practices for deploying and configuring Azure WAF across [CCoE-defined standard ingress patterns](https://dev.azure.com/defragovuk/CCoE-Architecture-Foundation/_wiki/wikis/CCoE-Architecture-Foundation.wiki?pagePath=/Patterns/AZR%20Cloud%20Patterns%20Ingress&wikiVersion=GBwikiMaster), using [Azure Application Gateway](https://dev.azure.com/defragovuk/CCoE-Architecture-Foundation/_wiki/wikis/CCoE-Architecture-Foundation.wiki?pagePath=/Patterns/AZR%20Cloud%20Patterns%20Azure%20Application%20Gateway&wikiVersion=GBwikiMaster) and [Azure Front Door](https://dev.azure.com/defragovuk/CCoE-Architecture-Foundation/_wiki/wikis/CCoE-Architecture-Foundation.wiki?pagePath=/Patterns/AZR%20Cloud%20Patterns%20Azure%20Front%20Door&wikiVersion=GBwikiMaster). It focuses on enabling consistent security controls, improving threat visibility, and minimising false positives for internet-facing workloads.

## Purpose

This document defines the architecture and operating model for Azure WAF deployed using Azure Front Door and Azure Application Gateway. It establishes a consistent, secure and auditable approach for onboarding applications, tuning WAF rules, managing exclusions and operating WAF policies across all environments in Defra.

## Audience

The intended audience of this document are:

- Enterprise Architects
- Technical Architects
- Solution Architects
- Cloud Centre of Excellence (CCoE)
- Application Owners/ Developers

## Scope

This guidance applies to:

- All internet-facing applications protected by Azure Front Door WAF.
- Defra internal applications protected by Private Application Gateway WAF.
- All environments: Development, Test, Pre‑Production, and Production.
  
## Out of Scope

- Non-Azure WAF platforms.
- Application-layer security controls implemented outside Azure WAF.
- Detailed operational runbooks or SOC procedures.

## Architectural Context

Azure WAF is a core component of Defra’s defence-in-depth and Zero Trust architecture, providing Layer 7 application protection for workloads hosted in Azure. It is used to inspect and control HTTP/S traffic to applications, helping to detect and mitigate common web-based attacks and application-layer abuse.Azure WAF operates alongside and does not replace, other security controls such as Azure DDoS Protection, network firewalls, identity and access management, and secure application design and development practices. Each control addresses a distinct layer of risk, collectively reducing the likelihood and impact of compromise.

Azure WAF policies are centrally governed by the CCoE and Security Architecture teams, with controlled input from application teams to ensure consistent security enforcement while supporting application-specific requirements.The following section describes the key Azure WAF capabilities used within Defra to support consistent and controlled application protection.

- **Managed Rules (Default Rule Set)**: Microsoft-maintained rules that automatically protect against common web application threats.

- **Custom Rules**: Application-specific rules to filter traffic and handle unique threats.

- **WAF Policy**: Centralised policies combining managed and custom rules with additional settings for consistent protection.
  
- **Modes**: Azure WAF supports two modes:
  
  - **Detection Mode** - Detection logs threats without blocking, ideal for baseline monitoring and tuning.
  - **Prevention Mode** - Actively blocks detected intrusions and records malicious requests to support auditing and alerting.

- **WAF Actions**: Define how Azure WAF responds to matched rules by allowing, logging, or blocking requests, enabling controlled enforcement and safe tuning of security policies.
  
- **Anomaly Scoring**: Uses cumulative rule scores to assess request risk and trigger logging or blocking when defined thresholds are exceeded.
  
- **Bot Protection**: Mitigates automated attacks such as scraping, scanning, and malicious bots.

- **Exclusions**: Allows specific request attributes to be ignored during rule evaluation to reduce false positives.
  
- **Request Limits**: Protects applications by limiting the maximum request size and blocking oversized requests to prevent DDoS attacks.
  
- **Observability**: Sends real-time notifications and logs through Azure Monitor and Sentinel for timely response and auditing.

## Deployment Models & Services

This reference architecture describes how Azure WAF is deployed to protect both public and private applications, while enabling centralised monitoring and incident response in alignment with Defra’s security principles.

- **Azure Front Door WAF** : Serves as the global ingress point for internet-facing applications. Each application has a dedicated WAF policy configured with the latest Microsoft-managed Default Rule Set (DRS) and where needed, custom rules for application-specific traffic. Bot Protection is enabled to block automated threats targeting public endpoints.
  
- **Private Application Gateway WAF** : Internal applications are secured via a private Application Gateway. Traffic from Defra corporate devices passes through Defra VPN (Zscaler Connector VMs) before reaching the gateway. Each application has a dedicated WAF policy using the latest DRS and approved custom rules, ensuring consistent Layer 7 protection across internal traffic paths.

All WAF logs and security events are forwarded to a central Log Analytics Workspace, integrated with Microsoft Sentinel for centralised monitoring, alerting and event correlation. The Defra Security Operations Centre (SOC) monitors Sentinel alerts, triages potential threats, and raises incident tickets. Incidents are reviewed for severity and validity before notifications are sent to the relevant application and operational contacts.

![contextdiagram](/Guidance/.Diagrams/AZR-WAF-Architecture.png)
<center>Figure 1 - Azure Web Application Firewall Deployment </center>

## Standard WAF Operating Model

## Detection Mode (Application Onboarding and Change Phase)

All new applications and significant WAF rule changes **MUST** follow a detection-only tuning phase. Azure WAF policies should initially be deployed in Detection mode for a standard duration of one to two weeks. During this period, the Managed DRS and Bot Protection are enabled to inspect incoming requests without actively blocking traffic.

While operating in Detection mode:

- Requests are evaluated against WAF rules but are not blocked.
- WAF diagnostic logs are sent to the Log Analytics Workspace and ingested into Microsoft Sentinel.
- Legitimate traffic patterns are observed and potential false positives are identified for further review.

This approach enables evidence-based tuning of WAF policies before before transitioning to prevention mode, helping to minimise false positives and reduce the risk of unintended service disruption.

## Tuning Managed rules

During the Detection mode phase, WAF policies **MUST** be reviewed and tuned based on observed traffic and logged events by the CCoE engineering team. The following tuning activities are performed:

- Identification of WAF rules triggering on legitimate application traffic.
- Validation of false positives using WAF logs.
- Creation of scoped exclusions where justified and approved.

## Prevention Mode

Once tuning has been completed and validated, WAF policies **MUST** be transitioned to Prevention (Block) mode.

In Prevention mode:

- Managed DRS rules remain enforced.
- Bot Protection is enabled in blocking mode.
- Approved and documented exclusions remain in effect.

## WAF Evaluation Process

This diagram illustrates the sequence in which Azure WAF evaluates client requests across Azure Front Door and private Application Gateway, applying custom rules before managed rule sets to determine whether traffic is permitted or blocked in Prevention mode.

![contextdiagram](/Guidance/.Diagrams/AZR-WAF-Evaluation-Process.png)
<center>Figure 2 - Azure Web Application Firewall Evaluation Process </center>

## Detection Mode Guidance by Environment

The WAF Detection-to-Prevention cycle **must be** followed in every environment, starting in Development and progressing through Test, Pre‑Production, and Production.

- **Development:** Detection mode is used to validate WAF rule behaviour against developer and internal test traffic.  
- **Test:** Detection mode continues with QA, integration, and functional testing traffic to identify potential false positives.  
- **Pre-Production:** Detection mode is used for final tuning and validation. Pre-Production is not exposed to the public internet, so tuning is based on controlled internal traffic and simulated scenarios.  
- **Production:** Final validation is performed with real public traffic. New applications or major rule changes **must** briefly run in Detection mode before transitioning to Prevention.

**Note**: All environments **must** use a consistent set of WAF rules and policies to ensure tuning and exclusions applied in lower environments are effective in Production.

## Environment Strategy

| Environment    | WAF Mode               | Purpose                                                             |Detection Mode Duration|
|----------------|------------------------|---------------------------------------------------------------------|---------     |
| Development    | Detection → Prevention | Early validation and developer testing, initial tuning of WAF rules | 1 Week       |
| Test           | Detection → Prevention | Functional and integration testing, validate rule behaviour         | 1 Week       |
| Pre-Production | Detection → Prevention | Final tuning and validation before Production                       | 1-2 Weeks    |
| Production     | Prevention             | Active protection of live services, all tuned rules enforced        | 24 - 72 Hours|

## WAF Governance, Risk and Operational Principles

## Operational Principles

- Lower environments **SHOULD** be used to validate WAF behaviour early in the delivery lifecycle.  
- Detection mode in Dev, Test, and Pre-Production ensures evidence-based tuning before enabling Prevention mode, minimising service disruption.  
- Prevention in Production **MUST** be enabled once tuning is complete.  
- Exclusions **MUST** be narrowly scoped where possible (for example, at parameter, header, cookie, or URL path level).  
- Rule groups or rules **MUST NOT** be disabled. Instead, the action **MUST** be set to log-only.
- Any exclusion or rule action changes **MUST** be documented with business and security justification.  
- Individual WAF rule IDs **COULD** be temporarily set to log-only mode to address validated false positives, subject to approval by the CCoE and Security Architecture teams.  
- All WAF rule changes **MUST** be implemented via Infrastructure as Code (IaC) to ensure consistent deployment and avoid manual reconfiguration of exclusions when upgrading to new rule set versions.  
- All WAF logs and alerts **MUST** be monitored through the central Log Analytics Workspace and Microsoft Sentinel for timely detection and response.

## Governance and Risk Management

All changes to WAF policies that could impact security controls require explicit governance:

- **Security approval is REQUIRED for:**
  - Changing WAF rule actions
  - Maintaining log-only rules for extended periods
  - Implementing WAF rule exclusions
- **Application teams MUST** formally accept any residual risk when security controls are relaxed.  
- **Risk ownership** remains with the application/service owner and is not transferred to the CCoE or Security teams.

This ensures that all WAF changes are **accountable, approved and traceable** and that risk decisions are made by the appropriate business stakeholders.

---

## Document Version Control

| Version | Date       | Author        | Role                       | Comments                                       |
| ------- | ---------  | ------------- | ---------------------------| ---------------------------------------------- |
| 1.0     | 30/01/2026 | Jyothi Medidi | Technical Cloud Architect  | Initial Draft                                  |
| 1.1     | 04/02/2026 | Jyothi Medidi | Technical Cloud Architect  | Updates applied following peer review feedback.|

Document Classification `OFFICIAL`


<!-- wiki page: /Guidance/Cloud Guidance Azure Privileged Identity Management (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Azure%20Privileged%20Identity%20Management) -->

# Cloud Guidance - Azure Privileged Identity Management (AZURE)

> **VERSION 1.0 - 07-09-2022**
> See [Document Version Control](#document-version-control) for full version history

---

- [Executive Summary](#executive-summary)
- [Audience](#audience)
- [Introduction](#introduction)
- [Service Configuration](#service-configuration)
  - [Role assignment overview](#role-assignment-overview)
    - [Assign](#assign)
    - [Elevation request](#elevation-request)
    - [Approval Process](#approval-process)
- [Guidance](#guidance)
  - [Role Approval](#role-approval)
  - [Access to Roles](#access-to-roles)
- [NCSC Cloud Principles](#ncsc-cloud-principles)
- [Document Version Control](#document-version-control)
  
## Executive Summary

This document provides service information on Azure Privileged Identity Management Services at Defra.

## Audience

The intended audience of this document are:

- Enterprise Architects
- Technical Architects
- Solution Architects
- Cloud Centre of Excellence
- Project Teams
- Users with Admin roles

## Introduction

Privileged Identity Management (PIM) is a service in Azure Active Directory (Azure AD) that enables Defra to manage, control, and monitor access to important resources in your organization. These resources include resources in Azure AD, and other Microsoft Online Services such as Microsoft 365 or Microsoft Endpoint Manager. Azure PIM is a sub-component of Azure Active Directory. This service is maintained and operated via delegated Administrators from the Head of Infrastructure, Service & Security Architecture (currently Joel Smith). PIM is applicable to tenant level "Microsoft 365" products such as Microsoft Endpoint Manager, for broad tenant level permissions, and also applicable at a much smaller scopes to Azure resources such as Subscriptions, or individual Virtual Machines It’s use and configuration is aligned with [NCSC guidelines](https://www.ncsc.gov.uk/collection/secure-system-administration/use-privileged-access-management) , [Defra Security Policy](https://defra.sharepoint.com/teams/Team178/Public/Forms/AllItems.aspx?cid=3ca45bb3%2Dbfa1%2D4c61%2D94af%2D9acfaabe9a2a&RootFolder=%2Fteams%2FTeam178%2FPublic%2FSecurity%20policies&FolderCTID=0x01200042305503D78B87468739B35E76242831) and [MS best practice for UK government](https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWBft1).

## Service Configuration

All Standard MS AAD Administrative Roles will be managed via PIM process. Most common M365 and AAD scoped BAU activities are controlled via AAD Groups, so PIM is not required – Group Ownership of correct AAD Group is needed.

- All Microsoft 365 (tenant level) write roles will require approved elevation.
- All Production Azure Resource (Management Group, Subscription, Resource Group level) write roles will require approved or pre-approved (Just In Time) elevation.
- Some “Reader” Roles can be permanently assigned.

![PIM Quick Start](.Diagrams/AZR-pim1.png)

### Role assignment overview

PIM role assignments give Defra a secure way to grant access to AAD and M365 resources. This section describes the assignment process. It includes assign roles to members, activate assignments, approve, or deny requests, extend, and renew assignments. As per both Defra Group Security policy and NCSC guidance, Admin or privileged roles with edit capability will only be assigned to separate, dedicated accounts. Some limited Reader roles can be assigned to regular accounts, by exception.

#### Assign

The assignment process starts by assigning roles to members. To grant access to a resource, the administrator assigns roles to users, groups, service principals, or managed identities. The assignment includes the following data:

- The members or owners to assign the role.
- The scope of the assignment. The scope limits the assigned role to a particular set of resources.
- The type of the assignment
  - Eligible assignments require the member of the role to perform an action to use the role. Actions might include activation or requesting approval from designated approvers.
  - Active assignments do not require the member to perform any action to use the role. Members assigned as active have the privileges assigned to the role.
- The duration of the assignment, using start and end dates or permanent. For eligible assignments, the members can activate or requesting approval during the start and end dates. For active assignments, the members can use the assign role during this period of time.

![PIM Assignment](.Diagrams/AZR-pim2.png)

PIM keeps you informed by sending you and other participants email notifications. These emails might also include links to relevant tasks, such as activating, approving or denying.

#### Elevation request

If users have been made eligible for a role, then they must activate the role assignment before using the role. To activate the role, users select specific activation duration within the maximum (configured by administrators), and the reason for the activation request. Agreed roles can be requested via the [Azure PIM portal](https://aad.portal.azure.com/#view/Microsoft_Azure_PIMCommon/ActivationMenuBlade/~/aadmigratedroles). As these are to perform specific change activities, these are time limited, and need to have either:

- An approved MyIT Change – for activities that affect the platform.
- A MyIT Task for a change that is scoped to individual users.

#### Approval Process

Some less privileged roles will be preconfigured to automatically approve (providing limited, Just In Time access). Where a role requires manual Approval, Approval, this should be done by a 3rd party. Delegated approvers will receive email notifications when a role request is pending their approval. Approvers can view, approve, or deny these pending requests in PIM. After the request has been approved, the requester can start using the role.  

## Guidance

### Role Approval

The approvers need to ensure that the request (and linked MyIT ticket/request) is relevant, conforms to both the required time and Defra’s minimum permission model. Generally, the [CCoE Subject Matter Expert](https://defra.sharepoint.com/sites/def-ddts-cloud/SitePages/Service-O365Services.aspx) for each role will approve. In the event the SME is not available please escalate to the CCoE Delivery Lead who can arrange approval. For specific highly privileged roles (including Global Administrator, Privileged Authentication Administrator), Defra Security, Head of Infrastructure, Service & Security Architecture, or specific nominated deputies can approve (See AAD foundation service).

### Access to Roles

- Administrators who require access to administrative roles should request these via MyIT to CCoE.
- Approval is multi-tiered and includes Defra Group Security, CCoE, Defra Architecture.
- Access to Admin Roles are provided on a minimum permissions basis only (both time and access).
- Access to Admin roles can be revoked at any time.
- Roles are assigned to users via AAD groups. There are all follow the below naming:
  - AG-PIM-[service-name]

![PIM Roles](.Diagrams/AZR-pim3.png)

## NCSC Cloud Principles

This guidance was designed in the context of the NCSC Cloud Security Principals. The following principals were identified as being particularly relevant when creating this component and all consumers of this service should be familiar with the following:

- Separation between users
- Operational security
- Secure user management
- Identity and authentication

---

## Document Version Control

| Version | Date       | Status | Change Summary | Reviewers/Approvers |
| ------- | ---------  | ------ | -------------- | ------------------- |
| 1.0     | 07-09-2022 | Issued | Initial Issue  | CCoE Architecture Team & WebOps Representatives |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`


<!-- wiki page: /Guidance/Cloud Guidance Enterprise Scale Identity and Access Management (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Enterprise%20Scale%20Identity%20and%20Access%20Management) -->

# Cloud Guidance - Enterprise Scale Identity and Access Management (AZURE)

> **VERSION 1.0 - 10-02-2022**
> See [Document Version Control](#document-version-control) for full version history
>

- [Introduction](#introduction)
  - [Overview](#overview)
  - [Objectives](#objectives)
  - [Purpose](#purpose)
  - [Scope](#scope)
    - [In Scope](#in-scope)
    - [Out of Scope](#out-of-scope)
- [Principles, inputs and Requirements](#principles-inputs-and-requirements)
  - [Use cases](#use-cases)
  - [Assumptions](#assumptions)
  - [Constraints / Technical Limitations](#constraints--technical-limitations)
- [High Level Architecture](#high-level-architecture)
  - [Architecture](#architecture)
  - [Key Components / Concepts](#key-components--concepts)
    - [Azure AD Replication/Sync](#azure-ad-replicationsync)
    - [Synchronised User and Group Objects in Azure Active Directory](#synchronised-user-and-group-objects-in-azure-active-directory)
    - [Group Membership](#group-membership)
    - [Role Entitlements in Azure](#role-entitlements-in-azure)
  - [Scopes](#scopes)
    - [Roles](#roles)
    - [Landing Zone RBAC Groups](#landing-zone-rbac-groups)
    - [Service Principals](#service-principals)
  - [Key Highlights](#key-highlights)
    - [Joiners Movers Leavers Process](#joiners-movers-leavers-process)
    - [CCoE Provisioning Process](#ccoe-provisioning-process)
- [Security Capabilities and Considerations](#security-capabilities-and-considerations)
- [Glossary of Terms](#glossary-of-terms)
- [Document Version Control](#document-version-control)

## Introduction

### Overview

This document explains the Identity and Access model (RBAC) used on the management plane of Azure.

This model is applied specifically to CCoE strategic tenants which is where 95% of Azure Activity should take place.

### Objectives

Azure defines Roles that govern access to many different types of resources. To simplify process and maintain simple RBAC models these have been reduced to 3 primary roles.

This document sets out the Role Based Access model and how it is applied in Azure so that Architects and Project teams can understand the permissions they will get in Azure Cloud, and what they will and will not be able to do with those permissions. this document does not go into granular detail on what Project teams and Architects should and should not do, it is best to discuss this with your project security and CCoE security architecture.
Azure relies on Azure Active Directory for its Authentication and Authorisation services - Whilst Azure Active Directory is a key part of this document, this document is not a reference for Azure Active Directory.

This document is only concerned with the Azure Management plane. Services deployed within Azure may adopt their own RBAC which may or may not be linked with Azure Active Directory, and are NOT covered by this document.

### Purpose

Landing zones are areas of Azure carved out for specific purposes/projects and this pattern covers the Role Based Access Control (RBAC) that is applied to the Landing Zone and how users can gain permissions to their landing zone.

This document covers the general RBAC model for people, applications and services when deploying, maintaining and managing applications in Defra's Azure Cloud Platform.

### Scope

#### In Scope

- RBAC applied to landing zones
- Roles available for projects in relation to Landing Zones
- Role Permissions
- Role differences in Prod/Non Prod
- Service Now Process
- Service Principal RBAC to the Landing Zone
  
#### Out of Scope

- Active Directory
- Azure Active Directory
- Active directory to Azure Active Directory Synchronisation
- CCoE Platform Team access
- RBAC to application or data plane within azure

## Principles, inputs and Requirements

### Use cases

Any project looking to use Azure will require a Landing zone to begin deploying resources onto. The Landing Zone will be created and permissions applied as per onboarding requirements. Subsequent access to specific roles can be requested via CCoE service tools (Jira or ServiceNow/myIT).

In Non-Production Landing Zones

- A Project Manager may opt for the "Reader Role", this allows reading of all Management plane resources but no access to underlying data. The Project Manager may also be interested in the Billing Data which is available under the "Reader Role"
- A Developer would be interested in the "Application User DevOps" Role. This allows access to most things with the exception of networking and granting rights directly on the subscription.

When the application is being deployed for use in a Prod Landing Zone.

- Pipeline deployment may use the "Application User DevOps" role granted to an SPN identity.
- A Developer could request "Reader Role" to ensure what has been delivered by a pipeline is correct.

Each subscription has its own groups, hence new requests for membership are required to get access across several subscriptions.

### Assumptions

This guidance demonstrates the assumed strategic approach to identity and access management, previous iterations may be non-strategic and still in use, this comes with additional cost of developing suitable Identity and RBAC model with appropriate controls, hence, no further development in those patterns are to be expected nor should they be used for new requests unless by exception/CCoE approval.

### Constraints / Technical Limitations

The Synchronisation of Identity from On-Premise to Azure AD can take several hours.

## High Level Architecture

### Architecture

![Figure 1 User Identity Sync](/Guidance/.Diagrams/AZR-ES-identity-sync.png)

>The picture above shows a simplified view on how On-Premise users are replicated to Azure, and also Cloud accounts are created in Azure to be assigned membership to AAD groups for Role Entitlements. In actual fact, there are more steps involved, and also multiple On-Premise Directories, but for the purposes if this document they are not required to be represented.

### Key Components / Concepts

#### Azure AD Replication/Sync

Users from the On-Premise AD Domains are synced into the Azure AD Strategic Office 365 Identity Tenant (defra.onmicrosoft.com), and hence are available as security objects which can be used to permission resources in Azure. The resulting Azure Active Directory object is referred to as a Synchronised Object.

Synchronised objects are all mastered On-Premise and so cannot be directly modified in Azure AD. All changes originate from the On-Premise directories and are written to Azure Active Directory via the synchronisation process.

#### Synchronised User and Group Objects in Azure Active Directory

| Object Type               | Privileged     | Explanation                  |
| :------------------------ | :------------: | :--------------------------- |
| Synchronised User Account | Non Privileged |  Accounts are synced and are Read Only in Azure. Management is via the On-Premise System/Processes.               |
| MSA Accounts        | N/A            |  Not used as On-Premise Functional and Domain levels are inadequate.             |
| Cloud Only Account        | N/A            |  In the Primary Strategic Identity Tenant Cloud Accounts are used where 3rd parties and Agency staff require administrative access to the Azure Management Plane, also some 3rd party User accounts for access to resources in Defra Azure.               |
| Cloud Only Groups     | N/A            |  In all Tenants Cloud groups are created and used for RBAC in the Azure Management plane. |
| Service Principal         | N/A            |  Service Principals are a special type of accounts that are used by systems. Similar to On-Premise Service Accounts                  |
| Managed Identity          | N/A            |  Many objects within Azure have their own identity which can be added to groups or used for assigning permissions to resources in Azure.                  |

Most On-Premise users have a replicated Synchronised object in Azure Active Directory

![Figure 2 Replicated On-Prem User](/Guidance/.Diagrams/AZR-ES-identity-user.png)

This object can be used for authentication and authorisation to resources in Azure.

#### Group Membership

Creation of Cloud Only Groups for Landing Zone RBAC is currently processed by the M365 team within CCoE and is managed via ServiceNow/myIT Requests.

#### Role Entitlements in Azure

On-Premise Groups (and their memberships) are synced into Azure and hence are available to be assigned to Roles in Azure:-

Currently most assignments for Azure resources are from Cloud Only Groups made specifically for each Landing Zone Subscription, as you can see below:-

![Figure 2 Replicated On-Prem User](/Guidance/.Diagrams/AZR-ES-identity-group.png)

### Scopes

Role Assignments can be applied to Management Groups, Subscriptions, Resource Groups and Resources. Scopes used in Enterprise Scale are covered in further detail in [Enterprise Scale Management Group and Subscription Organisation](/Guidance/Cloud-Guidance-Enterprise-Scale-Management-Group-and-Subscription-Organisation.md).

A Landing Zone is constructed from a Subscription and hence Roles granted are at the Subscription Scope.

Roles MUST only be assigned to Groups and Service Principles. Users Should not be assigned directly to Roles. (Privilege Access Management and Just In Time Access can LOOK like it is applying permissions to users, but this is still managed via Groups).

#### Roles

There are 3 standard Roles that apply to Enterprise Scale Landing Zone Subscriptions and they are:

| Role                      | Production Assignment Rules    | Non-Production Assignment Rules                  | Use                 |
| :------------------------ | :---------------------------- | :--------------------------- | :--------------------------- |
| Application User DevOps | Automation Service Principal <BR/><BR/> Any other assignment would require an exception |  Automation Service Principal <BR/><BR/> Any User account via CCoE Request process               | This is a Custom Role and is for Developer/Administrator/Devops user access to a subscription. This provides access to all resources except:<BR/><BR/> - IAM settings/Role assignments <BR/><BR/> - Blueprints <BR/><BR/> - Virtual Networks <BR/><BR/> - Virtual Network Peering <BR/><BR/> - Route Tables |
| Reader | Any User Account via CCoE Request Process |  Any User Account via CCoE Request Process | Has reader access to the Subscription |
| Support Request Contributor | Any User Account via CCoE Request Process |  Any User Account via CCoE Request Process | Can create Support incidents for the Subscription, after discussion and approval by CCoE that the request is valid, as CCoE managed the support relationship with Microsoft |

There are many more Roles applied at the Management Group Level. These are defined in the [Enterprise Scale Management Group and Subscription Organisation](/Guidance/Cloud-Guidance-Enterprise-Scale-Management-Group-and-Subscription-Organisation.md)

#### Landing Zone RBAC Groups

Each Landing Zone will result in the creation of 3 AAD groups.

AG-Azure-XXXXX-YYYYY-RRRRR

- XXXXX = Name of Tenant (DefraCloudDev/DefraCloudPreProd,DefraCloud,Defra,DefraDev)
- YYYYY = Landing Zone Subscription (eg. AZR-AVD-PRD1)
- RRRRR = Role (Devops-Contributor/User-Reader/SR-Contributor)

#### Service Principals

Service Principals are used for application/system access to Subscriptions. All Landing Zones are provided with a Service Principal. Upon creation the service principals, secrets are stored in a key vault. The key vault permissions are set to allow the subscription requester access to the keys for that service principal.

The Service Principal has the form:-

ADO-XXXXX-YYYYY-automation

Where

- XXXXX = Name of Tenant (DefraCloudDev/DefraCloudPreProd,DefraCloud,Defra,DefraDev)
- YYYYY = Landing Zone Subscription (eg. AZR-AVD-PRD1)

Service Principals do not allow "interactive" logon - and hence cannot be used in the portal.

In Production environments, users are not granted the Application User DevOps Role, unless exception has been explicitly approved, hence the service principal is the expected access method.

This approach restricts access via the portal for production and enforces configuration management via code.

### Key Highlights

Users/Groups and their assignments have no security or availability concerns directly. Azure AD is the underlying service used in order to achieve RBAC for the Azure Management Plane.

#### Joiners Movers Leavers Process

Any synced On-Premise User objects with Read Access would leverage existing Joiners Movers Leavers processes so that permissions are not carried through unnecessarily, and Azure is treated as an Entitlement - just like any other system entitlement.

Cloud Only accounts will need to follow documented Joiners Movers Leavers processes for demising accounts that are no longer required. Service Now should be used to make requests for this type of activity, actionable by CCoE.

#### CCoE Provisioning Process

When a subscription is requested through CCoE onboarding processes, the fulfilment process includes:-

- Groups are created in Azure AD
- Creation of the Subscription in Azure (Including compliance and guardrails)
- Creation of the Service Principal and Storage of the Service Principal key in a key vault for later retrieval.
- Assigning groups to the appropriate roles at the subscription/management group scope.

## Security Capabilities and Considerations

Each of the Service Controls for various services within Azure can be found here. [CCoE Wiki](../Foundation-Services.md)

## Glossary of Terms

| Term                     | Definition      |
| :----------------------- | :-------------- |
| Enrollment               | The ultimate billing entity/contract for services within Azure |
| Tenant                   | The security entity that allows access to a given Subscription |
|

## Document Version Control

| Version | Date      | Status | Change Summary | Reviewers/Approvers |
| ------- | --------- | ------ | -------------- | ------------------- |
| 1.0     | 10-02-2022 | Issued | Initial Issue  | CCoE Architecture Team & WebOps Representatives |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`


<!-- wiki page: /Guidance/Cloud Guidance Azure Back End Operator Access (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Azure%20Back%20End%20Operator%20Access) -->

# Cloud Guidance - Back-end operator access

> **VERSION 1.0 - 30-05-2024**
> See [Document Version Control](#document-version-control) for full version history

---

- [Cloud Guidance - Back-end operator access](#cloud-guidance---back-end-operator-access)
  - [Executive Summary](#executive-summary)
  - [Audience](#audience)
  - [Concepts](#concepts)
    - [Data plane operations](#data-plane-operations)
    - [Back-end operators](#back-end-operators)
    - [Direct access](#direct-access)
    - [Protocol Break (indirect access)](#protocol-break-indirect-access)
  - [Considerations](#considerations)
  - [Dependencies](#dependencies)
  - [Document Version Control](#document-version-control)
  
## Executive Summary

Some Applications require operators to have direct access to back-end resources, sometimes for troubleshooting or scheduled maintenance activities, in most cases these access requirements can be met without network access to the Data plane ([see this article for information on data plane definition](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/control-plane-and-data-plane)), however it is sometimes necessary to provide network access.

By default, all Azure resources are deployed with public access disabled, limiting access to only "private" ([RFC1918](https://www.rfc-editor.org/rfc/rfc1918)) routable networks, if data plane access is necessary on a "private" network connected resource, a back-end network connectivity pattern must be selected.

Defra maintain a hub spoke network topology within Azure, this is connected the to the Defra WAN via an Azure connectivity service called Expressroute.  This  connectivity to Defra WAN can be leveraged by users of Defra devices to reach the back-end network of Applications deployed within the Defra Azure network,  reaching these back end networks from non Defra devices requires more planning.

This guidance is intended to aid decision making during Application planning and deployment, to ensure that any present and future back-end network connectivity is catered for.

## Audience

The intended audience of this document are:

- Enterprise Architects
- Technical Architects
- Solution Architects
- Cloud Centre of Excellence
- Project Teams

## Concepts

### Data plane operations

Data plane operations are any operations that take place against capabilities of deployed Azure resources, eg access to read/write tables on a SQL database, SMB access to a file share on Azure Files, or Desktop access in a Virtual Machine.

These operations are distinct from Control Plane operations, which are characterised as being able to control the Azure resource configuration, but not access or modify the data stored "within" the resource. More information is available here: [Azure control plane and data plane](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/control-plane-and-data-plane)

### Back-end operators

A back-end operator is any user that requires access to the data plane of a deployed Azure resource.  In most use cases this user would be an Application Developer who needs to be able to view realtime operational logs, or manually insert data into a SQL table or Service Bus queue for testing purposes. Common backend operator profiles are:

| Operator type | Description |
| :- | :- |
| Developers | Software development team responsible for initial delivery, and sometimes ongoing support or patching. |
| Application Operational support | Software support team, responsible for maintaining the application, may need back end access for issue resolution or BAU maintenance |
| Application Operators | Application users, may need to perform operations directly on data plane as part of BAU application activity. In modern applications, direct data plane access should not be required, BAU operational activity should be performed within the application |

### Direct access

Direct Network (layer 3 routable) access to the data plane may be necessary if the back-end operator needs to run tests from an environment hosted on their workstation against the target resource.

### Protocol Break (indirect access)

When Cross Domain Solution planning, NCSC recommends that protocol breaks are introduced;
[NCSC Protocol break guidance](https://www.ncsc.gov.uk/collection/cross-domain-solutions/using-the-principles/network-protocol-attack-protection). In practice, this can implemented by ensuring back-end operators use the RDP protocol to connect to an Azure Virtual Desktop, then using SQL protocol from AVD, or HTTPS protocol to execute data plane operations in the target environment.

## Considerations

Firstly, every effort should be made to avoid the need for back-end data plane access, in most cases data plane operations can be accomplished using Azure Automation services such as Logic Apps, Function Apps, or by using Azure DevOps agent pipelines. If it is absolutely network for back-end network access to be granted, the following questions must be considered when selecting the appropriate pattern:

- Back-end operator source machine:
  - Is back-end operator connecting from a Defra Workstation, if so, they can likely connect directly over Defra WAN.
  - Does back-end operator's workstation have restrictions on software installation, this may rule out CCoE VPN.
- Back-end operator connectivity requirements
  - Is (layer 3) network connectivity required, eg, does the back-end operator have an application running on their local workstation that requires access to the target back-end network.
- Back-end operator security clearance
  - if back-end operator is given data plane access to a production Application, they may require Security Clearance depending on what privileges they have, consult with Security team.
- Back-end operator technical capability
  - Some back-end access methods to not provide end user support, if back-end operators are non-technical, AVD RAS should be selected.
- Back-end operations service criticality
  - None of the back-end connectivity methods are Tier1, meaning 24x7 functionality cannot be guaranteed. If a back-end activity is critical to application functionality this should be considered.
- Target environment (Production/PreProduction)
  - lower environment data plane access is broadly endorsed as there is no risk to production application operation, or data exfiltration.
  - upper environment data plane access should be avoided whenever possible as access introduces an increased risk to application stability and security.

## Dependencies

| Baseline | Primary Usage |
| - | - |
| [Azure Network Foundation Service](../Foundation-Services/Foundation/AZR-Foundation-Azure-Network.md) | Reference for Defra Hub Spoke network |
| [Azure Windows Virtual Desktop](../Foundation-Services/Foundation/AZR-Foundation-Azure-Virtual-Desktop.md) | Azure Windows Virtual Desktop |
| [CCoE VPN Foundation](../Foundation-Services/Foundation/AZR-Foundation-CCoE-VPN.md) | Foundation Service for CCoE VPN  |
| [Azure back-end operator access Pattern](../Patterns/AZR-Cloud-Patterns-back-end-operator-access.md) | Patterns for back-end operator access |

---

## Document Version Control

| Version | Date       | Status | Change Summary | Reviewers/Approvers |
| ------- | ---------  | ------ | -------------- | ------------------- |
| 1.0     | 30-04-2024 | Issued | Initial Issue  | CCoE Architecture Team & WebOps Representatives |

Document Classification `OFFICIAL`


<!-- wiki page: /Guidance/Cloud Guidance Azure DDoS Protection (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Azure%20DDoS%20Protection) -->

# Cloud Guidance - Azure DDoS Protection (AZURE)

> **VERSION 1.1 - 02-12-2025**
> See [Document Version Control](#document-version-control) for full version history
>

- [Introduction](#introduction)
  - [Overview](#overview)
  - [Service Description](#service-description)
  - [Scope](#scope)
    - [In Scope](#in-scope)
    - [Out of Scope](#out-of-scope)
- [Principles, inputs and Constraints](#principles-inputs-and-constraints)
  - [Functional Capabilities and Use cases](#functional-capabilities-and-use-cases)
  - [Non Functional Capabilities](#non-functional-capabilities)
  - [Risks, Constraints and Limitations](#risks-constraints-and-limitations)
  - [Key Decisions](#key-decisions)
  - [Key Considerations and best practices](#key-considerations-and-best-practices)
- [High Level Architecture](#high-level-architecture)
  - [Architecture Introduction](#architecture-introduction)
  - [Service Enablement](#service-enablement)
  - [Resource Protection](#resource-protection)
  - [Protection Governance](#protection-governance)
  - [Resource Diagnostic Settings](#resource-diagnostic-settings)
  - [Logging and Streaming](#logging-and-streaming)
  - [Monitoring and Alerting](#monitoring-and-alerting)
    - [Dashboards and Workbook Solutions](#dashboards-and-workbook-solutions)
  - [Key Components / Concepts](#key-components--concepts)
  - [Configuration](#configuration)
  - [Cost Management](#cost-management)
- [Document Version Control](#document-version-control)

## Introduction

### Overview

This document describes the various capabilities/use cases and respective deployment guidance for the proposed use of Azure DDoS Protection Standard where this provides DDoS mitigation of distributed denial of service attacks against internet facing endpoints.

This document will describe Azure DDoS Protection's:

- `Basic` SKU protection
- `Standard` SKU additional features
- Relationship with other Azure resources that operate Public IP addresses
- Integration with Azure Monitor / Sentinel
- Integration with Approved SIEM/SOC

This document is intended for use by the Azure Platform Architect and/or Engineer, as well as Cyber Security Operations and Incident Response professionals, and provides them with the necessary guidance to understand, consume and make most of this service.

All cloud components of this service are currently managed by the CCoE Operational teams, DevOps application teams will not be required to apply their own instance of this service or configure their resources to benefit from the service.

### Service Description

Distributed denial of service (DDoS) attacks are some of the largest availability and security concerns facing customers that are moving their applications to the cloud. A DDoS attack attempts to overwhelm a network and exhaust an application's resources, making the application unavailable to legitimate users. DDoS attacks can be targeted at any endpoint that is publicly reachable through the internet.

Azure DDoS Protection automatically mitigates distributed denial of service attacks against our internet facing endpoints. it is a cloud service provider managed service that requires very little configuration. It is actively monitoring traffic patterns and is detecting anomalies and indicators of DDoS attacks, Layer 3 and 4 of the OSI model. Upon detection it automatically mitigates DDoS attacks. There are two SKUs available, Basic and Standard. **Basic** is free and protects IPv4 and IPv6 Azure public IP addresses from Distributed Denial of Service attacks. On top of that **Standard** expands the scope of the detection and mitigation from the infrastructure to the application resources we have deployed, and adds metrics, logging and alerting, availability guarantees, cost protection, additional threat intelligence, access to Microsoft's Rapid Response team, inspect normal traffic versus anomalies, customise mitigation policy. While Basic protection is always-on and provided at no additional cost, Standard is enabled per protected resource and is a chargeable service.

More information may be found here [Azure DDoS Protection Standard documentation](https://docs.microsoft.com/en-us/azure/ddos-protection/) and this article best describes the underlying workings [Designing resilient solutions with Azure DDoS Protection](https://docs.microsoft.com/en-us/azure/ddos-protection/fundamental-best-practices)

### Scope

#### In Scope

- Azure DDoS Protection Basic
- Azure DDoS Protection Standard

#### Out of Scope

- Layer 7 DDoS attack protection
- Azure Firewall
- Azure Web Application Firewall (offering Layer 7 protection)
- Azure Front Door with WAF
- Application Gateway with WAF
- Azure Load Balancer
- Azure VNet Gateway (ExpressRoute)
- Azure Virtual Network and Public IP Address

## Principles, inputs and Constraints

### Functional Capabilities and Use cases

The table below provides a side by side comparison of the two DDoS Protection services and highlights their high-level capabilities;

| Capability|DDoS Protection Basic|DDoS Protection Standard|
| :-------- | :------------------ | :--------------------- |
| Active traffic monitoring and always-on detection| Yes|Yes|
|Automatic attack mitigation|Yes|Yes|
|Availability guarantee|Per Azure Region|Per Application|
|Mitigation Policies| Tuned per Azure region volume| Tuned per application traffic volume|
|Metric and alerts|Not available|Yes|
|Mitigation flow logs|Not available|Yes|
|Mitigation policy customisation| Not available|Yes|
|Support|Yes, best endeavours, no guarantees| Yes, access to DDoS experts during an attack|
|SLA|Azure region|Application availability guarantee and cost protection|
|Pricing|Free|Monthly usage|

The **Basic** service provides the following functional capabilities, detailed at a lower-level:

|Functional Capability|Use Cases|
| :---- | :----- |
|**Active traffic monitoring and always-on detection protecting** - for all IP addresses <BR></BR> Active traffic monitoring and always-on detection. DDoS Protection Basic monitors traffic patterns all day, every day, searching for indicators of DDoS attacks upon the global Azure infrastructure. Layer 3 and 4 protection for Volumetric (UDP Flood) and Protocol (TCP SYN) attacks.<BR></BR> - Volumetric attacks - flood the network layer with attacks<BR></BR> - Protocol attacks - exploit a weakness in layer 3 and 4| Both Non-Production and Production subscriptions  and their landing zones.<BR></BR> These capabilities (features) are complemented by the features offered by the Standard service detailed below.|
**Automatic attack mitigation** - for all public IP addresses - once the attack is detected, it's mitigated.| |
| **Availability guarantee** - per Azure region<BR></BR>Every property in each Azure region is protected by Azure's infrastructure DDoS Protection (Basic SKU) at no additional cost. The scale and end capacity of the globally deployed Azure network provides defence against common network-layer attacks through always-on traffic monitoring and real-time mitigation. Basic requires no configuration and no application changes. Basic is not tuned or optimised to consider a customers application and traffic patterns. Basic is a protection layer scoped to Azure infrastructure itself, it is enabled on all Azure components in all Azure regions by default.||
|**Mitigation policies** - tuned per Azure region volume<BR></BR>Similarly, Basic protection is applied by default on all Azure components in all regions but is not configurable or tunable by customers and they don't have visibility to the configured mitigation policies. The Azure DDoS Protection Basic service is targeted at protection of the infrastructure and protection of the Azure platform. It mitigates traffic when it exceeds a rate that is so significant that it might affect multiple customers in a multi-tenant environment.||
| **Support** - best endeavours support, no guarantees||
| **SLA** - based on the Azure region with the best-effort support||
|**Pricing** - Free||

The **Standard** service provides the following capabilities **on top of** the Basic service;

|Functional Capability|Use Cases|
| :---- | :----- |
|**Resource (application layer) attacks** - according to Microsoft these attacks target web application packets, to disrupt the transmission of data between hosts.<BR></BR> `Whilst Microsoft indicate their Resource layer attack protection includes HTTP protocol violations. SQL injection, cross-site scripting, and other layer 7 attacks, DDoS protection alone (Basic or Standard) WILL NOT protect resources for layer 7 attacks, only a WAS can achieve that level of protection.`| Both Non-Production and Production subscriptions  and their landing zones.<BR></BR> These capabilities (features) enhance the features offered by the Basic service detailed above.|
| **Availability guarantee** - per application<BR></BR>For each resource or application protected by the DDoS Protection Standard plan, Microsoft offers a Cost guarantee, allowing the customer to receive data-transfer and application scale-out service credit for resource costs incurrent as a result of documented DDoS attacks, an SLA guarantee covering 99.99% SLA guarantee for Azure DDoS Protection service and a 99.99% SLA guarantee that during attack the target resource will not be impacted. If it is the customer will receive 100% service credits for resource costs incurrent as a result of a documented DDoS attack.||
|**Mitigation policies** - tuned per application traffic volume<BR></BR>Standard mitigation policies are tuned per application traffic volume. The service is automatically tuned per public IP address (that is the front end to the application). It uses propriety machine learning algorithms that learn the application traffic patterns (layer 3 and 4) on days of the week, and at times of the day, months and even seasons. It builds a traffic profiles, monitors changes in the traffic pattern and compares this with the learnt traffic profile. The mitigation policy thresholds are set based upon the application's traffic profile. The machine learning algorithms also set mitigation thresholds and perform dynamic profiling of the normal traffic patterns of the VIPs every minute, tis profile is then used to predict the expected traffic of the VIP oer the next 15-minute time interval. If there is an attack upon the application then the traffic volume would surge, a traffic anomaly would be detected and that detection would trigger the inspection of the traffic in real-time, both good and bad traffic will be inspected and teh bad traffic will be scrubbed.||
| **Metrics** -  Several metrics are available during the duration of a DDoS attack reflecting different packet types, varying by protocol, bytes and packets, relating to flows and actions taken by Microsoft.||
| **Mitigation flow logs** - logs allow you to review the dropped traffic, forwarded traffic and other interesting data points during an active DDoS attack in near-real time.||
| **Protection Notifications** - Logs will notify you anytime a public IP  resource is under attack, and when attack mitigation is over.||
| **Mitigation Reports** - Report data that provides detailed information about the attack when a public IP resource is under attack, the report generation will start as soon as the mitigation starts. There will be an incremental report generated every 5 minutes and a post-mitigation report for the whole mitigation period. This  is to ensure that in an event the DDoS attack continues for a longer duration of time, you will be able to view the most current snapshot of mitigation report every 5 minutes and a complete summary once the attack mitigation is over.||
| **Alerts** - alert rules and action groups may be defined using Azure Monitor, Azure Portal and Azure Security Centre, for any public IP address, various templates are available, further integration is possible with Logic Apps and with Sentinel.||
| **Mitigation policy customisation**<BR></BR> The mitigation policy is auto configured without the need for user intervention and it is continuously enhanced based on and adaptive tuning feature. The mitigation policy will kick in when the threshold is reached. Mitigation policy customisation is not directly available for customers, however, if the customer thinks that the policy needs more tuning, like changing the TCP and UDP thresholds, or if you want to allow (exclude) a specific list of IPs for example, then customer can open a support case to the DDoS Protection product team who can change the mitigation policy manually, per application (resource), based on the requesters requirements.||
| **Support** - access to DDoS experts during an attack or after an attack, you can engage the DDoS Protection Rapid Response team for help with attack investigation and specialised support.||
| **SLA** - Application availability guarantee and cost protection. DDoS attacks often can trigger the automatic scale-out of the service running in Azure. This could lead to a significant increased in network bandwidth, the scaling-up of the virtual machine cound, or both. In the event of an attack, you can receive Azure credits for any scale-out of resources, allowing for possible auto-scale and egress data transfer costs.||
|**Pricing** - Monthly usage<BR></BR> When Application Gateway with WAF is deployed in a DDoS protected VNet, there are no extra charges for WAF - you pay for the Application Gateway at the lower non-WAF rate. This policy applies to both Application Gateway v1 and v2 SKUs||

### Non Functional Capabilities

| Requirement | Service Capabilities to meet this|
| :--------- | :-------------------------------|
| Data Classification | Up to Official Sensitive |
| Scalability and Resilience | This is a platform service operated by Microsoft within their global network offering mitigation capacity to every Azure region. <BR></BR> The service is built on distributed DDoS detection and mitigation pipelines which can scale massively and absorb tens of terabits of volumetric attacks. <BR></BR>|The service is available in all Defra strategic regions, it is zone-resilient by default and managed entirely by Microsoft.|
|  Encryption | Not applicable to this service, the service has no data storage facility and no sensitive data to encrypt. |
| Monitoring, Logging and Alerting | This service leverages existing Defra SOC SIEM processes and ecosystem.|
| Disaster Recovery | Not applicable to this service, the customer (Defra) have no means to recover the service in the event of a disaster, Microsoft are entirely responsible.|
| Backup and Recovery | Not applicable to this service, the customer (Defra) has no means to backup and recover the service in the event of a disaster, Microsoft are entirely responsible. Furthermore, only metadata such as thresholds or whitelists is stored per application.|
| Availability and other SLAs| Microsoft Guarantee DDoS Protection Service will be available at least 99.99% of the time, and cost protection provides resource credits for scale out during a documented attack.|

### Risks, Constraints and Limitations

| Summary | Description | Impact | Mitigation |
| :------ | :---------- | :----- | :--------  |
| Constraint - Configuration | When DDoS Standard is enabled for the virtual network, the virtual network cannot be moved to another resource group or subscription. | Low - Customer disruption, inconvenience | Disable, Move, and then re-enable DDoS Standard. |
| Limitation - Near real-time | Flow logs are streamed near real-time for SIEM integration. | Low - Events and subsequent alerts are not received by the SIEM in real-time | Encourage further development of SIEM/SOC operations within Azure using Sentinel. Accept near real-time. |
| Limitation - Layer 7 Protection | DDoS Protection alone (Basic or Standard) will only protect resources from Layer 3 and 4 attacks. Neither services protect resources from Layer 7 attacks, only a WAF can achieve that level of protection. | High | Current Azure Front Door pattern introduces L7 DDoS Protection. |
| Risk - False positive | A genuine traffic anomaly occurs, a false positive detection results, customer traffic is dropped or mitigated. | High | |
| Limitation - Supported and Unsupported resources | DDoS Protection Standard is designed for services that are deployed in a virtual network. For other services, the default DDoS Protection Basic services applies <BR></BR> **Protected under DDoS Standard**: public IP addresses attached to Application Gateways, Bastions, Azure Firewalls, VPN Gateways, VMs, Virtual appliances.<BR></BR> **Unsupported by DDoS Standard**: PaaS services e.g. API Management, Logic Apps, Event Hub, ASE. | Medium | Integrating these services (where supported) with the virtual network, using Private Link and operating a private endpoint mitigates the risk. |
| Risk - Security Operations | 'Denial of Service Protection Operating Instructions for Azure' does not yet exist. | Medium - Use cases, response strategy and security playbooks are not yet defined or documented, telemetry data and reports are not yet acted upon. | Definition of use cases, playbooks, deploying the systems configuration and delivering the operating instructions for Azure. |

### Key Decisions

| Decision | Rationale | Consequences |
| :------  | :-------- | :----------  |
| A single DDoS Protection plan will be created and used in each tenant and that plan will be shared by multiple subscriptions within the tenant.| We will achieve consistency across all subscriptions within the tenant. Simplicity in deployment, management and governance. | None - There is no cost benefit operating multiple plans. |
| All Non-Production and Production environments will benefit from the features offered by the Standard service. | The functional capabilities as described above and further within this document.<BR></BR> The additional features offered by the Standard service provides visibility of an attack upon both Non-Production and Production subscriptions and landing zones. | For each protected resource that exceeds the plan quota there is an additional service cost of $29.44 per resource (that operate a public IP address) per month. |
| The IaC used to deploy any 'cloud external DMZ' virtual network will configure it's properties to enable this common DDoS Protection Standard plan. | We will achieve consistency across all resources consuming a virtual network that is classified as a 'cloud external DMZ' and hosts resources configured with a public IP address. | IaC will be redeveloped and our DevOps engineers will require clear guidance. |
| Azure Policy built-in definitions will be used to govern the enablement of the DDoS Protection Standard plan and to govern the presence of the diagnostics settings for resource logs and metrics for all public IP addresses.<BR></BR> `Built in Definitions are used to define the basis for a custom definition which has additional metadata included within, and in some scenarios new custom definitions are created.` | Built-in Policy is native, off the shelf and supported by Microsoft. | The built-in Policy may have it's limitations. |
| Azure Policy custom definitions will be used to bridge any gaps, constraints or limitations. | Custom Policy may be developed to support specific scenarios or as a fail back mechanism. | Increased complexity and management overheads. |

### Key Considerations and best practices

- Design applications with security in mind and follow secure coding standards.
- Deploy application architectures with resilience and scalability
- Leverage Azure platform services to achieve layered security and defence in depth.

## High Level Architecture

### Architecture Introduction

To recap, Azure DDoS mitigates distributed denial of service attacks against our internet facing endpoints. It is a cloud service provider managed service that requires very little configuration. It is actively monitoring traffic patterns and is detecting anomalies and indicators of DDoS attacks. Layers 3 and 4. Upon detection it automatically mitigates DDoS attacks. There are two SKUs available, Basic and Standard. Basic is free and protects IPv4 and IPv6 Azure public IP addresses from DDoS attacks. On top of that Standard expands the scope of detection and mitigation from the infrastructure to the application resources we have deployed, and adds metrics, alerting and logs, availability guarantees, cost protection, additional thread intelligence, access to Microsoft's Rapid Response team, inspect normal traffic versus anomalies, customise mitigation policy.

The following diagram reflects Microsoft's Azure DDoS Protection Standard service.

![Figure 1](.Diagrams/AZR-DDoS-Ref-Arch.png)

### Service Enablement

A single DDoS Protection Standard plan will be created and used in each tenant, and that plan will be shared by multiple subscriptions within the tenant.

### Resource Protection

The IaC used to deploy any 'cloud external DMZ' virtual network will configure its properties to enable this common DDoS Protection Standard plan.

### Protection Governance

Azure policy built-in definitions are used to govern the enablement of the DDoS Protection Standard plan and to govern the presence of diagnostic settings for resource logs and metrics of all public IP addresses. The three current policy definitions include.

- `Azure DDoS Protection Standard should be enabled` (Built-in policy)
- `Virtual networks should be protected by Azure DDoS Protection Standard` (Built-in policy)
- `Public IP addresses should have resource logs enabled for Azure DDoS Protection Standard` (Built-in policy)

Azure policy built-in definitions are used to define the basis for a custom definition which can then have additional metadata included within, and in some scenarios new custom definitions are created.

Azure Policy custom definitions will be used to bridge any gaps, constraints or limitations, or where customisations are necessary.

### Resource Diagnostic Settings

The diagnostic settings applied by Azure policy are `Protection Notification's`, `Mitigation Flow Logs`, `Mitigation Reports`, and `All Metrics` categories.

### Logging and Streaming

Enabling the diagnostic settings results in all metrics and telemetry data being forwarded to the Azure Monitor Log Analytics Workspace for events related to the categories mentioned above. This workspace is integrated with the Azure Sentinel service, previously adopted for platform security monitoring functions and developed so far to include Analytical rules relating to alternative Azure services.

### Monitoring and Alerting

The SOC team will use the Azure Sentinel to log, monitor and alert when DDoS attack mitigation is triggered. Either may be considered a secure repository.

#### Dashboards and Workbook Solutions

Azure Sentinel provides a Connector allowing you to connect to Azure DDoS Protection Standard logs located within your log analytics workspace AzureDiagnostics table. This Connector introduces use of the Azure DDoS Protection Workbook, alternatively the same workbook can be used with Azure Monitor. The workbook visualises security-relevant Azure DDoS events across several filterable panels. It enables you to view and analyse this data in your workbooks, query it to create custom alerts, and incorporate it to improve your investigation process, giving you more insight into your platform security. It offers a summary tab and an investigate tab across multiple workspaces.

### Key Components / Concepts

Azure DDoS Protection Standard consists of the following direct and related components.

- DDoS Protection Plans - This is the primary component of the service. It's configuration defines a resource name, the subscription that is responsible for the plan, the resource group and location that contains the plan. In time the plan will reflect the protected Virtual Networks (VNets) and the public IP address resources.
- Tenants - One DDoS Protection plan can (And does) provide protection for an entire Tenant.
- Subscriptions - Within the same tenant, any number of Subscriptions can share the same plan.
- Virtual Networks (VNets) - VNets are the object to which plans are attached. Once VNets are attached to a plan, resources within those VNets are protected.
- Public IP Addresses - These are the resources being protected by the DDoS Protection Plan.
- Resources - These are the resources that consume public IP addresses, these resource types are defined within our inbound/outbound security patterns, each resource type has it's own security control document, cloud deployment pattern, and is considered an approved service.
- Azure Monitor Log Analytics Workspace and Azure Diagnostics table - the destination for diagnostic logs and origin of data export to a designated Event Hub.

### Configuration

| Configuration Setting | Description| CLI flag | Recommendations |
| :-------------------  | :-------- | :---------| :--------------|
| Plan Creation | Create a DDoS Protection Plan | `az network ddos-protection create` <BR></BR> `--resource-group MyResourceGroup` <BR></BR> `--name MyDdosProtectionPlan` | Single SKU and a one time activity. |
| Resource Association | Enable DDoS Protection (existing vnet) | `az network vnet update` <BR></BR> `--resource-group MyResourceGroup` <BR></BR> `--name MyVnet`<BR></BR> `--ddos-protection true`<BR></BR> `--ddos-protection-plan MyDdosProtectionPlan` | Deploy to landing zones that include cloud external DMZ VNets. Configure at scale using Azure Policy. |
| Resource Diagnostic Settings Configuration | Configure DDoS Protection diagnostics| `az monitor diagnostic-settings create`<BR></BR> `--name PublicIP-Diagnostics`<BR></BR> `--resource /subscriptions/xxxxxxx-xxxx-xxxx-xxxx-/resourceGroups/myresourcegroup/providers/Microsoft.Network/xxxxx` <BR></BR> `--logs '[{"Category": "DDoSProtectionNotifications","enabled": true},`<BR></BR> `{"category": "DDosMitigationFlowLogs","enabled": true},`<BR></BR> `{"category": "DDosMitigationReports","enabled": true}, ]'`<BR></BR> `--metrics '[{"category": "AllMetrics","enabled": true}]'`<BR></BR> `--storage-account /subscriptions/xxxxxx-xxxx-xxxx-xxxx-xxxxxxxx/resourceGroups/myresourcegroup/providers/Microsoft.Storage/storageAccounts/mystorageaccount`<BR></BR> `--workspace /subscriptions/xxxxxx-xxxx-xxxx-xxxx-xxxxxxxx/resourcegroups/myresourcegroup/providers/microsoft.operationalinsights/workspaces/myworkspace` | Deploy to landing zones that include cloud external DMZ virtual networks. Configure at scale using Azure Policy. |

### Cost Management

For each plan there is a monthly price of $2943.55 which includes protection for 100 resources (that operate a public IP address). This foundational cost shared back to projects via blended costs mechanism.

## Document Version Control

| Version | Date      | Status | Change Summary | Reviewers/Approvers |
| ------- | --------- | ------ | -------------- | ------------------- |
| 1.0     | 25-05-2022 | Issued | Initial Issue  | CCoE Architecture Team & WebOps Representatives |
| 1.1     | 02-12-2025 | Issued | Removal of F5 Silverline references | CCoE Architecture, Security & WebOps |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`


<!-- wiki page: /Patterns/AZR Cloud Patterns Protective Monitoring Applications (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FPatterns%2FAZR%20Cloud%20Patterns%20Protective%20Monitoring%20Applications) -->

# CCoE Patterns - Protective Monitoring - Applications (AZURE)

> **VERSION 2.0 - 01-04-2022**
> See [Document Version Control](#document-version-control) for full version history
>

---

- [Executive Summary](#executive-summary)
- [Audience](#audience)
- [Dependencies](#dependencies)
- [Pattern](#pattern)
  - [JSON Message Format Version 1.1](#json-message-format-version-11)
    - [JSON Message Format 1.1](#json-message-format-11)
  - [Rationale](#rationale)
  - [Constraints and Trade-Offs](#constraints-and-trade-offs)
- [Document Version Control](#document-version-control)

## Executive Summary

This pattern is an elaboration on the protective monitoring requirements and event format so business solutions can generate the appropriate events that can be consumed by the Defra Security Incident and Event Management System (SIEM).

Protective Monitoring is a set of business processes, with essential support technology, that need to be put into place in order to oversee that the Line of Business (LOB) Services is not being abused and to assure user accountability for their use of LOB Services. Within the scope of this guide Protective Monitoring activities are limited to those associated with information provided by information security controls of LOB Service(e.g. Login, Logouts, Authorisation logs, key business transactions security alerts). Protective Monitoring includes putting into place mechanisms for collecting LOB Services log information and configuring LOB Service logs in order to provide an audit trail of security relevant events of interest.

## Audience

The intended audience of these patterns are:
Enterprise, Technical and Solution Architects and Cloud Service Centre.

## Dependencies

These patterns consume the following Foundations,Services and Guidance:-

| Baseline                                      | Primary Usage                     |
| --------------------------------------------- | --------------------------------- |
| [Azure SOC Integration](/Guidance/Cloud-Guidance-SOC-Integration.md) | Defra SOC Integration |
| [Azure Sentinel](/Foundation-Services/Services/AZR-Cloud-Service-Azure-Sentinel.md) | Service Controls for Azure Sentinel |

## Pattern

> The following diagram details various components of the Protective Monitoring (Infrastructure) pattern.

![Figure 1 Protective Monitoring](.Diagrams/azr-protective-monitor-apps.png)

The  Protective Monitoring solution has following components.

- **Protective Monitoring Collector/Queue(s)** - These components will be deployed close to the monitored solution and will have capability to receive or collect events (and optionally logs) from the monitored solutions. There will be many collectors deployed within the Defra estate as well as a funnel point for events between the source systems and target SIEM, collectors can also perform

  - aggregation (e.g. a flood of 100 of one event is sent as one event and a “times 100” indicator)
  - suppression (e.g. “noise” events with no value to the SIEM are suppressed) and  
  - filtering (e.g. some payload data is removed / masked if the SIEM does not need all of the payload or if it is sensitive data that should not be sent to the SIEM)

- **Channel SIEM (optional)** - Some channels (for example Desktop, Azure, AWS, Networks, On-site hosting, business partners or service delivery partner) may have their own local SIEM which monitors for events within that channel before cascading collated and processed events to the Defra core SIEM

- **Core SIEM** - This is the Defra core SIEM that collects, normalises, collates and escalates events from across the Defra estate.

- **SOC** - This is the Defra SOC that provides the operational functions to monitor the SIEM. All events are normalised and correlation rules on other related events occurring at same time are applied. Any unexpected behaviour will either raise a service now incident or a task is set up in a SOC analyst queue for further actions.

Additional components that integrate with the monitored solution, SIEM and SOC are –

- **System monitoring**- This is the operational monitoring solution.

- **ServiceNow**- This is the service management tool that creates, triages, monitors and resolves service affecting events.

- **Events** - The protective monitoring event feed from the monitored solution components (LOB Systems, Services, etc).The event (and optionally log) feed is generated by the monitored solution and sent to the local protective monitoring collector via an approved log and event collection route. The approved routes will vary depending on the collector technology being used and the component being monitored and may require the monitored component to send events to the collector or may require the collector to pull events from the monitored component.

- **Protective Monitoring Event Format** - Protective monitoring events must be created in a format that is agreed between the monitored solution component(s) and the SIEM solution so that events may be normalised and parsed by the SIEM for storage, processing and correlating with other related events

### JSON Message Format Version 1.1

- An ‘environment’ property to capture the information on which environment (including the subscription) the event occurred in, this is particularly useful for Blue/Green deployments where the information would otherwise be unavailable.
- A ‘version’ property to quickly identify which message standard is being used.  This is useful for programmatically determining what form other fields should take.
- All property names are now written in lowercase even when combining names.
- Properties are now given maximum string lengths.
- More detailed information is provided on where properties should come from and what values are allowed.
- Null values are not to be used, N/A or equivalent is to be used for empty fields  

#### JSON Message Format 1.1

```json
{ 

    "user" : "IDM/8b7c6b0a-4ea2-e911-a971-000d3a28d1a0", 
    "sessionid" : "e66d78f5-a58d-46f6-a9b4-f8c90e99b6dc", 
    "datetime" : "2019-10-09T12:51:41.381Z", 
    “environment” : ”PRD-Blue”, 
    “version” : ”1.1”, 
    "application" : "FI001", 
    "component" : "<internal app name>", 
    "ip" : "127.0.0.1", 
    "pmccode" : "0703", 
    "priority" : "0", 
    "details": 
    { 
        "transactioncode" : "2306", 
        "message" : "User successfully downloaded a stored document", 
        "additionalinfo" : "<details or obfuscated location of document, etc.>" 
    } 
}
```

### Rationale

- Good logging practices provides the ability to understand, trace and react to system and security events

- Security monitoring provides insight into systems, and allows for the active detection of threats and potential security incidents

- Security monitoring introduces an additional layer of defence to systems

- Actively monitoring systems affords the opportunity to react to early signs of compromise, meaning organisations can respond effectively

- Azure Security Centre & Azure Sentinel are the products used within the organisation for SIEM.

### Constraints and Trade-Offs

- Azure application protective monitoring events will be collected from Azure Event Hubs.
- Following the environment hub and spoke configuration principles the Azure Event Hubs will also be configured as hub and spoke with a spoke Event Hub being deployed alongside each application environment which will forward events to the hub Event Hub for that subscription and then onwards to the Azure SIEM (Azure Security Centre / Sentinel) and to the core SIEM (QRADAR)
- Protective monitoring events in line with the MITRE must be considered as part of the solution design. A RAG status must be produced by the monitored solution component(s) to define the event stream that will be generated by the component and this must be agreed with the SOC prior to integrating the event stream.
- Compliance is to be record using a RAG status indicator with annotations / comments to describe the required detail supporting the status ( Full compliant, partial compliant, Non-Compliant, Not Applicable).
- This specification covers business solutions that are developed as a bespoke solution and coded by Defra (and/or Defra business partners) so solution designers  have full control over the business logic and can instrument and codify the protective monitoring event generation during solution development.
- For solutions that are delivered as Software as a Service (SaaS) or that use SaaS platforms to deliver core business functionality (for example Microsoft Dynamics and Power Platform) the ability to influence and codify the monitoring events may be limited.
- The principles outlined in this document remain valid and the control categories and event types remain in scope however the ability to generate the events and event format specified here may be constrained by the capabilities of the SaaS solution

## Document Version Control

| Version | Date      | Status | Change Summary | Reviewers/Approvers |
| ------- | --------- | ------ | -------------- | ------------------- |
| 1.0     | 24-05-2022 | Issued | Initial Issue  | CCoE Architecture Team |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`


<!-- wiki page: /Patterns/AZR Cloud Patterns Protective Monitoring Infrastructure (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FPatterns%2FAZR%20Cloud%20Patterns%20Protective%20Monitoring%20Infrastructure) -->

# CCoE Patterns - Protective Monitoring - Infrastructure (AZURE)

> **VERSION 2.0 - 01-04-2022**
> See [Document Version Control](#document-version-control) for full version history
>

---

- [Executive Summary](#executive-summary)
- [Audience](#audience)
- [Dependencies](#dependencies)
- [Pattern](#pattern)
  - [Rationale](#rationale)
  - [Constraints and Trade-Offs](#constraints-and-trade-offs)
- [Document Version Control](#document-version-control)

## Executive Summary

This pattern is an elaboration on the protective monitoring requirements and event format so business solutions can generate the appropriate events that can be consumed by the Defra Security Incident and Event Management System (SIEM).

Protective Monitoring is a set of business processes, with essential support technology, that need to be put into place in order to oversee that the Line of Business (LOB) Services is not being abused and to assure user accountability for their use of LOB Services. Within the scope of this guide Protective Monitoring activities are limited to those associated with information provided by information security controls of LOB Service (e.g. inspecting firewall logs, investigating operating system security alerts and monitoring an Identity Service). Protective Monitoring includes putting into place mechanisms for collecting LOB Services log information and configuring LOB Service logs in order to provide an audit trail of security relevant events of interest.

## Audience

The intended audience of these patterns are:
Enterprise, Technical and Solution Architects and Cloud Service Centre.

## Dependencies

These patterns consume the following Foundations,Services and Guidance:-

| Baseline                                      | Primary Usage                     |
| --------------------------------------------- | --------------------------------- |
| [Azure SOC Integration](/Guidance/Cloud-Guidance-SOC-Integration.md) | Defra SOC Integration |
| [Azure Sentinel](/Foundation-Services/Services/AZR-Cloud-Service-Azure-Sentinel.md) | Service Controls for Microsoft Sentinel |

## Pattern

> The following diagram details various components of the Protective Monitoring (Infrastructure) pattern.

![Figure 1 Protective Monitoring](.Diagrams/AZR-Protective-Monitoring-inf.png)

The  Protective Monitoring solution has following components.

- **Protective Monitoring Collector/Queue(s)** - These components will be deployed close to the monitored solution and will have capability to receive or collect events (and optionally logs) from the monitored solutions. There will be many collectors deployed within the Defra estate as well as a funnel point for events between the source systems and target SIEM, collectors can also perform

  - aggregation (e.g. a flood of 100 of one event is sent as one event and a “times 100” indicator)
  - suppression (e.g. “noise” events with no value to the SIEM are suppressed) and  
  - filtering (e.g. some payload data is removed / masked if the SIEM does not need all of the payload or if it is sensitive data that should not be sent to the SIEM)

- **Channel SIEM (optional)** - Some channels (for example Desktop, Azure, AWS, Networks, On-site hosting, business partners or service delivery partner) may have their own local SIEM which monitors for events within that channel before cascading collated and processed events to the Defra core SIEM

- **Core SIEM** - This is the Defra core SIEM that collects, normalises, collates and escalates events from across the Defra estate.

- **SOC** - This is the Defra SOC that provides the operational functions to monitor the SIEM. All events are normalised and correlation rules on other related events occurring at same time are applied. Any unexpected behaviour will either raise a service now incident or a task is set up in a SOC analyst queue for further actions.

Additional components that integrate with the monitored solution, SIEM and SOC are –

- **System monitoring**- This is the operational monitoring solution.

- **ServiceNow**- This is the service management tool that creates, triages, monitors and resolves service affecting events.

- **Events** - The protective monitoring event feed from the monitored solution components (LOB Systems, Services, etc).The event (and optionally log) feed is generated by the monitored solution and sent to the local protective monitoring collector via an approved log and event collection route. The approved routes will vary depending on the collector technology being used and the component being monitored and may require the monitored component to send events to the collector or may require the collector to pull events from the monitored component.

The protective Monitoring Solution leverages the native event format of the IaaS, PaaS or COTS component will be used. As a minimum this event should contain the following detail -

- The IP address / resource name of the component generating the event

- Identity of the user, for example device username or application user account

- The time that the request was generated

- The event code / indicator text as agreed with the SIEM and SOC for event tagging

- The full event text

Depending on the component generating the event this may be structured as a JSON payload or may fall back to some underlying common denominator format, for example syslog common event format.

### Rationale

- Good logging practices provides the ability to understand, trace and react to system and security events

- Security monitoring provides insight into systems, and allows for the active detection of threats and potential security incidents

- Security monitoring introduces an additional layer of defence to systems

- Actively monitoring systems affords the opportunity to react to early signs of compromise, meaning organisations can respond effectively

- Microsoft Defender for Cloud & Microsoft Sentinel are the products used within the organisation for SIEM.

### Constraints and Trade-Offs

- Protective monitoring events must be created in a format that is agreed between the monitored solution component(s) and the SIEM solution so that events may be normalised and parsed by the SIEM for storage, processing and correlating with other related events

- Protective monitoring events may be collected by the SIEM in a number of ways –

  - integration between the monitored component and the SIEM collector<BR></BR>The SIEM collectors have a number of intrinsic capabilities to collect events, for example by direct integration with database auditing solutions, which may be used by the SIEM to collect events from the monitored component<BR></BR>

  - Intermediate event / log store<BR></BR>Monitored components may send their events to an underlying system or service event store from where they can be relayed to the SIEM collector. Examples of this are Microsoft WMI event stores and Azure LogAnalytics event stores<BR></BR>

  - Directly from the monitored component to the SIEM collector<BR></BR>A number of “lowest common denominator” capabilities exist to allow bespoke event streams to be collected, for example the SIEM collectors will support syslog (and syslog-ng) event streams in common event format<BR></BR>

- Protective monitoring events in line with MITRE must be considered as part of the solution design. A RAG status must be produced by the monitored solution component(s) to define the event stream that will be generated by the component and this must be agreed with the SOC prior to integrating the event stream.

- Compliance is to be record using a RAG status indicator with annotations / comments to describe the required detail supporting the status (Full Compliance, Partial Compliance, Non-Compliant, Not Applicable)

## Document Version Control

| Version | Date      | Status | Change Summary | Reviewers/Approvers |
| ------- | --------- | ------ | -------------- | ------------------- |
| 1.0     | 24-05-2022 | Issued | Initial Issue  | CCoE Architecture Team |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`

