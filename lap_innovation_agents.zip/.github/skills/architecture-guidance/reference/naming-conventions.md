<!-- SYNCED FROM AZURE DEVOPS WIKI — DO NOT EDIT BY HAND (overwritten on next sync).
     Source: https://dev.azure.com/defragovuk/CCoE-Architecture-Foundation wiki 'CCoE-Architecture-Foundation.wiki'
     Pages: /Guidance/Cloud Guidance Azure Naming Convention; /Guidance/Cloud Guidance Azure Entra Id Naming Convention
     Fetched: 2026-08-19T14:08:35.698Z
     Classification: OFFICIAL -->

<!-- wiki page: /Guidance/Cloud Guidance Azure Naming Convention (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Azure%20Naming%20Convention) -->

# Cloud Guidance - Azure Naming Convention (Azure)

> **VERSION 1.2 - 20-02-2024**
> See [Document Version Control](#document-version-control) for full version history

---

- [Cloud Guidance - Azure Naming Convention (Azure)](#cloud-guidance---azure-naming-convention-azure)
  - [Executive Summary](#executive-summary)
  - [Audience](#audience)
  - [Resource Name Structure](#resource-name-structure)
    - [Azure Subscriptions](#azure-subscriptions)
      - [Subscription Type Codes](#subscription-type-codes)
      - [Tenant Codes](#tenant-codes)
      - [Azure Legacy Subscriptions](#azure-legacy-subscriptions)
      - [Azure Hub/Spoke Subscription](#azure-hubspoke-subscription)
    - [Azure Component Resources](#azure-component-resources)
    - [Service Codes](#service-codes)
    - [Azure Function/Role Codes](#azure-functionrole-codes)
    - [Azure Resource Type Codes](#azure-resource-type-codes)
    - [Azure Region Identification](#azure-region-identification)
    - [Out of Scope Names](#out-of-scope-names)
    - [Azure Subcomponents](#azure-subcomponents)
  - [Appendix](#appendix)
  - [Document Version Control](#document-version-control)
  
## Executive Summary

Information relating to Azure resources can be derived from the name of that resource. By following a series of documented standards and a few rules, it is possible to identify a significant amount of information without having to look deeper into the configuration, or refer to a design document.

This document refers to the Azure resources only. Where a component within a resource is configured, this will adhere to the Application naming standards.

Examples of this include:

- Database names
- Service Bus queue names
- Application health probe names

This document covers the naming conventions defined for Azure for both the legacy environment (defined by Defra Project Sandcastles) and the Hub/Spoke environment (defined by CSC/CCoE).

## Audience

The intended audience of this document are:

- Enterprise Architects
- Technical Architects
- Solution Architects
- Cloud Service Centre
- Project Teams

## Resource Name Structure

The rules and format applied to a particular resource are dependent on the resource's classification.  For instance, the name of a subscription differs in format to the resources within that subscription.

The following sections will describe the various resource classifications and their naming structure.

### Azure Subscriptions

Azure subscriptions are represented in two naming formats known internally as legacy & Hub/Spoke. The legacy subscription model was defined by Cap Gemini project Sandcastles and was created to reflect the existing AWS cloud environment. The legacy model has been superseded by the hub/spoke model which provides greater security and protection to other applications within the Azure tenant.

From a naming perspective, the legacy subscription names contain an abbreviation for the environment name, whereas Hub/Spoke names comprise of the environment name and the application Service Code.

#### Subscription Type Codes

The type codes represent the different types of functionally grouped resources supported. Each Azure Subscription Type has a specific purpose and security/operational constraints.

|Type Code|Description|
|-|-|
| AIP | Automated Intelligence AI.DATALIFT |
| APS | Apps Shared Services |
| CAT | Catalogue |
| DEV | Development |
| LOG | Log |
| MST | Master Shared Transit |
| OPS | Ops Shared Services |
| POC | Proof Of Concept |
| PRD | Prod |
| PRE | Pre-prod |
| SEC | Security |
| SND | Sandpit |
| SSV1* | Shared Services Sandbox only |
| SSV2* | Shared Services Development and lower |
| SSV3* | Shared Services Test and lower |
| SSV4* | Shared Services Pre Production and lower only |
| SSV5* | Shared Services Production and lower |
| TST | Test |

*The Shared Service subscription is to allow for single resources to be used for multiple environments, this saves unnecessary proliferation of resources, and the cost and complexity that involves.  An example of a Shared Service would be a Firewall.

#### Tenant Codes

The Tenant code (used in Hub/Spoke convention) must be used to show which tenant the Subscription is in, in some cases there will be a disparity between the tenant intended Deployment Environment and the Subscription Deployment Environment, eg AZR-EOB-DEV1 is clearly a "Development" subscription deployed in a "Production" tenant, this is usually due to platform constraints.

|Tenant Code | Description | Deployment Environment |
|-|-|-|
| AZR | Defra or DefraCloud | All |
| AZP | DefraCloudPreProd | Pre-Production |
| AZD | O365_DefraDev or DefraCloudDev | Development |

#### Azure Legacy Subscriptions

The Legacy naming convention was based on an AWS convention, using  two sections, the first denoting cloud (AZR = Azure), and the second section denoting subscription "Type" (see above).

`<Cloud><Type>`

Examples:

| Name | Cloud | Type |
|-|-|-|
| AZR-APS | Azure | Apps Shared Services |
| AZR-LOG | Azure | Logs |

#### Azure Hub/Spoke Subscription

The Hub/Spoke subscription naming convention is more granular, with three sections, the first denoting Cloud and Tenant, the second denoting Service Code, and the third denoting deployment environment and an incrementing instance number. Note; the Deployment Environment instance number tagged onto the end of the name allows for the provision of multiple test/dev or blue/green Environments per application.

`<Tenant><Service Code><Deployment Environment+instance number>`

Examples:

| Name | Tenant | Service Code| Deployment Environment+number |
|-|-|-|-|
|AZR-EOB-POC1 | Azure Prod Tenant* | Service Code EOB | Proof of Concept 1 |
|AZR-EOB-SND1 | Azure Prod Tenant* | Service Code EOB | Sandpit 1  |
|AZR-EOB-DEV1 | Azure Prod Tenant* | Service Code EOB | Development 1 |
|AZR-EOB-DEV2 | Azure Prod Tenant* | Service Code EOB | Development 2 |
|AZR-EOB-PRE1 | Azure Prod Tenant* | Service Code EOB | PreProduction 1 |
|AZR-EOB-PRD1 | Azure Prod Tenant* | Service Code EOB | Production 1 |

*Non prod subscriptions may be deployed in "production" tenant, see [Tenant Codes](#tenant-codes)

### Azure Component Resources

Azure component resource names are constructed from information that allows the reader to identify key components related to the resource.

Azure resource names are built from the following:-

- `Subscription Type code` Parent subscription type (note; this can be Deployment Environment such as DEV, but can also be others, see [Subscription Type Codes](#subscription-type-codes))
- `Svc code`  Service Code associated with the resource
- `Function/Role`  The role the component plays
- `Resource Type`  The type of Azure resource
- `Deployment Environment Instance Number`  The number of the Deployment Enviroment instance, eg DEV1 = 1, DEV2 = 2.
- `Region/Instance Number`  The region and instance count for the component.

Each of the above is represented by a 3 character code (all of which are described in this document). The exception to this is the ‘Resource Type’, which is trimmed to two characters in the Hub/Spoke naming convention – this keeps the name length under 15 characters, whilst allowing for a single digit environment instance number to be represented.

Thus, a legacy resource name is constructed from:-

`<Sub Type><Svc><Role><Res Type><Region+Instance Number>`

And a "new" hub/spoke resource name is constructed from:-

`<Sub Type><Svc><Role><Res Type><Deployment Environment instance number><Region+Instance Number>`

**Legacy examples:**

| Name |  Deployment Environment | Service Code| Role | Type | Instance |
|-|-|-|-|-|-|
| PRDCHMDBSSQA001 | Production | Service Code CHM | Database | Azure SQL Server | Instance 1 |
| PRDCHMDBSSQA002 | Production | Service Code CHM | Database | Azure SQL Server | Instance 2 |

**Hub/Spoke examples:**

| Name |  Deployment Environment | Service Code| Role | Type |  Deployment Environment instance | Region+Instance |
|-|-|-|-|-|-|-|
| DEVCHMDBSSQ1401 | Development | Service Code CHM | Database | Azure SQL Server | 1 | Instance 1 in UK South |
| DEVCHMDBSSQ2401 | Development | Service Code CHM | Database | Azure SQL Server | 2 | Instance 1 in UK South |
| PRDCHMDBSSQ1401 | Production | Service Code CHM | Database | Azure SQL Server | 1 | Instance 1 in UK South |
| PRDCHMDBSSQ1001 | Production | Service Code CHM | Database | Azure SQL Server | 1 | Instance 1 in Europe North |
| PRDCHMDBSSQ1402 | Production | Service Code CHM | Database | Azure SQL Server | 1 | Instance 2 in UK South |
| MSTINFDNSRG1401 | Master Shared Transit | Service Code INF | DNS | Resource Group | 1 | Instance 1 in UK South |
| MSTINFDNSRG1402 | Master Shared Transit | Service Code INF | DNS | Resource Group | 1 | Instance 2 in UK South |
| MSTINFDNSRG2402 | Master Shared Transit | Service Code INF | DNS | Resource Group | 2 | Instance 2 in UK South |

### Service Codes

When a project is initiated within Defra, a code is setup to uniquely identify that project. This code referred to as the ‘Service Code’. Only CCoE can allocate Service Codes.

Examples of the current Service Codes can be found below.

| Service Code | Description |
|-|-|
| AAD | Azure Active Directory |
| AIM | Defra AIMS AMX |
| BOO | Dell Boomi |
| CHM | EUX Chemicals |
| CSC | CCoe Support Activities |
| CUS | Customer identity |
| EMZ | Easimap on Azure |
| EOB | Earth Observation |
| EXP | EUX Exports |
| FFF | Future Flood Forecasting System |
| IDM | Identity Management |
| IMD | Improving Data Management |
| IMF | Incident Management Forecasting System |
| IMP | EUX IPAFFS (Imports) |

### Azure Function/Role Codes

Azure Function (or Role) codes provide an insight into what the resource actually does. There may be a number of Azure components that make up a function/role and the function code is an ideal way of grouping them together.

The function code is also useful in quickly assessing the severity of a security issue as it can be used to identify the boundaries that the resource operates within.

| Function Code | Description |
|-|-|
| AAC | Automation Account |
| AAS | Azure Analysis Services |
| ADF | Azure Data Factory |
| ADL | Azure Data Lake |
| ADG | Azure Data Gateway |
| AFW | Azure Firewall |
| ASE | Application Service Environment |
| ASP | Application Service Plan |
| AXW | Axway Server |
| BAS | Bastion |
| BES | Back-End |
| BLB | Back-End Load Balancer |
| CER | Certificate |
| DBS | Database Server |
| DNS | DNS Zones |
| DGW | Data Gateway |
| DHC | DHCP Server |
| ETL | Extract Transform Load Server |
| FES | Front-End |
| FLB | Front-End Load Balancer |
| FTP | File Transfer Server |
| GIT | GitLab |
| INF | Infrastructure |
| JEN | Jenkins |
| NET | Network |
| PLB | Proxy Load Balancer |

### Azure Resource Type Codes

Azure resource type codes identify the specific resource that has been deployed. Each Azure component has its own unique code to identify what it is.

In the hub/Spoke environments, the resource codes are abbreviated to two characters. This is to accommodate the environment number in the resource name. See examples in [Azure Component Resources](#azure-component-resources)

| Resource Code | Hub/Spoke Code |  Description |
|-|-|-|
| API | PI | API Connection |
| AIS | IS | Application Insights |
| ALB | LB | Application Load Balancer |
| ASP | SP | Application Service Plan |
| ASE | SE | Application Service Environment |
| AVS | VS | Availability Set |
| ASG | SG | Auto Scaling Group |
| AAA | AA | Automation Account |
| AAS | AS | Azure Analysis Services |
| AGW | AG | Azure Application Gateway |
| ACA | CA | Azure Container Apps |
| ACE | CE | Azure Container Environments |
| ACI | CI | Azure Container Instances |
|  | CR | Azure Container Registry |
| ADF | DF | Azure Data Factory |
| AFD | FD | Azure Front Door |
| AKS | AK | Azure Kubernetes Service |
| SUB | SU | Azure Subnet |
| WAF | WF | Azure WAF Policy |
| BEP | EP | Back End Pool |
| AFA | FA | Function App |
| KVT | KV | Key Vault |
| FLB | LB | Load Balancer |
|  | LW | Log Analytics Workspace |
| ALA | LA | Logic App |
| NSG | NS | Network Security Group |
| RGP | RG | Resource Group* |
| STO | ST | Storage Account |
| AWA | WA | Web App |

*Resource Group naming requires some judgment, it's selected function code should be roughly conformant to what resources are stored within it, eg a Resource Group containing DNS Zones would likely have a function code of "DNS".  For any Resource Group likely to contain heterogenous resource types, "INF" should be used.
### Azure Region Identification

It is possible to identify the region in which a resource is implemented by associating the instance with a range of values.

Each Azure region has been allocated 199 instance values

| Region| Start| End|
|-|-|-|
| North Europe | 001 | 199 |
| West Europe | 201 | 399 |
| UK South | 401 | 599 |
| UK West | 601 | 799 |

### Out of Scope Names

Although the Azure resources follow a strict naming convention, certain internal configuration elements are the responsibility of the application developer. These resources are usually tailored to the application design & as a result can be free-form text.

Resources that fit this category include:-

- Azure Workbook names
- API Connection Names
- Application Service Plans
- Availability tests
- Azure Runbooks
- Azure Scheduled job names
- Azure Shared Dashboards
- Azure Solutions
- DNS Zones (named for the domain name)
- SQL Database Names
- Storage Account Names
- Event Hub names

The names above are determined at the discretion of the standards being applied to the software development.

### Azure Subcomponents

When defining a subcomponent in Azure, it is best to associate that subcomponent with its parent. Thus the name of the component will comprise of the name of its parent, plus the resource type of the subcomponent.

Examples of this are:

A NIC that has been defined and attached to a VM server

**PRDSOCINFSRV001** would be the server name.

**PRDSOCINFSRV001-nic1**    would be the name of the associated NIC.

**PRDSOCINFSRV001-nsg1**   would be the name of the NSG applied to the VM NIC.

## Appendix

The naming Convention document itself is a living document operated and updated by CCoE Webops.

---

## Document Version Control

| Version | Date       | Status | Change Summary | Reviewers/Approvers |
| ------- | ---------  | ------ | -------------- | ------------------- |
| 1.0     | 28-04-2022 | Issued | Initial Issue  | CCoE Architecture Team & WebOps Representatives |
| 1.1     | 06-09-2022 | Issued | modified some short codes, and reformatted examples  | CCoE Architecture Team & WebOps Representatives |
| 1.2     | 20-02-2024 | Issued | additional short codes  | CCoE Architecture Team & WebOps Representatives |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`


<!-- wiki page: /Guidance/Cloud Guidance Azure Entra Id Naming Convention (https://dev.azure.com/defragovuk/6c43f9ab-da42-4238-afc3-4f973becd8ed/_wiki/wikis/eeb0a3cb-3e54-4582-a01d-f79839429f6d?pagePath=%2FGuidance%2FCloud%20Guidance%20Azure%20Entra%20Id%20Naming%20Convention) -->

# Cloud Guidance - Entra ID (Formerly Azure Active Directory - AAD) Naming Convention

> **VERSION 1.4 - 20-07-2025**
> See [Document Version Control](#document-version-control) for full version history

---

- [Cloud Guidance - Entra ID (Formerly Azure Active Directory - AAD) Naming Convention](#cloud-guidance---entra-id-formerly-azure-active-directory---aad-naming-convention)
  - [Executive Summary](#executive-summary)
  - [Audience](#audience)
  - [Dependencies](#dependencies)
  - [Entra ID Security Group usage principles](#entra-id-security-group-usage-principles)
  - [Entra ID Security Group Name Structure](#entra-id-security-group-name-structure)
    - [Group name structure](#group-name-structure)
    - [Home directory and membership type](#home-directory-and-membership-type)
    - [Group classification](#group-classification)
    - [Supplier designation](#supplier-designation)
    - [Scope](#scope)
    - [Service scope](#service-scope)
    - [Team designation](#team-designation)
    - [Permission or criteria](#permission-or-criteria)
  - [Access Group permission abbreviations](#access-group-permission-abbreviations)
  - [Group naming examples](#group-naming-examples)
  - [Entra ID Security Group usage examples](#entra-id-security-group-usage-examples)
      - [Optimal example](#optimal-example)
      - [Sub optimal examples](#sub-optimal-examples)
  - [Document Version Control](#document-version-control)
  
## Executive Summary

Entra ID (formerly Azure Active Directory - AAD) holds a database of groups synchronised from a "classic" Microsoft Active Directory Domain Service (ADDS), this includes a "writeback" capability to synchronise some object data back to ADDS.  It also provides Entra ID only groups (sometimes referred to as "Cloud" groups) which can be used for assigning permissions within Azure, Entra ID, in some cases, to a synchronised Entra ID Directory Domain Services instance, and **critically, can be passed to external platforms using Entra ID as their identity source, eg Github**.

This document refers to the Entra ID groups only. Where a group is created in Entra ID (not created in AD, then synchronised to Entra ID), it should comply with this naming convention.  This guidance is intended to enhance Defra's auditing capability, and ensure the Principle of Least Privilege (PoLP) is observed.

Within Entra ID there are 3 Group types, Distribution Group, Security Group and Microsoft 365 Group.  **This naming convention only covers the Security Group type**.

## Audience

The intended audience of this document are:

- Enterprise Architects
- Technical Architects
- Solution Architects
- Cloud Centre of Excellence
- Project Teams

## Dependencies

This guidance should be read in conjunction with the following Foundations,Services and Guidance:-

| Baseline                                      | Primary Usage                     |
| --------------------------------------------- | --------------------------------- |
| [Azure Cloud Service Entra ID](/Foundation-Services/Services/AZR-Cloud-Service-Azure-Entra-ID.md) | Azure Entra ID Platform Configuration Controls |

## Entra ID Security Group usage principles

This guidance follows Microsoft best practice, and allows for simple  automation and auditing of user permissions.  See this article for more information [Active Directory Design Considerations and Best Practices](https://social.technet.microsoft.com/wiki/contents/articles/52587.active-directory-design-considerations-and-best-practices.aspx#AD_Group_Management)

- You **should** be able to know all resources a user has access to by listing their Group membership.
- All groups **should** have "Owners" correctly populated with either the IAO (Information Asset Owner) or their delegated approver(s). This allows "self management" of group membership in the Groups management console.
- Access and User Group membership changes **must** be executed or approved by one of the Group Owners.
- Groups **should** be managed and manageable by their Owners using the [Microsoft Groups Management console]( https://myaccount.microsoft.com/groups)
- Use judgement when designing security group structure for any application, there is a "soft" limit of 2048 groups (including nesting) for each Entra ID user. [Entra ID service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions)
- Try to use nested groups*, rather than adding same user / computer account into multiple groups. This will simplify the group management tasks.
- Addition of users to sensitive groups **should** always be approved by the Information Asset Owner or delegated group owner for the resource the group gives - access to.  Audit logs of group membership changes are stored in Entra ID Audit logs, and SOC long term log retention.
- Groups **should** follow a stringent naming convention, which should clearly reflect their purpose. By looking at the group name, you should understand what the group is "for".  This principle usually rules out the nesting of Access groups within other Access groups.
- Groups **should** align with the principle of least privilege, granting only the minimum necessary access. Avoid using broad groups with excessive permissions.
- Implement periodic access reviews for critical or high-privilege groups using Entra ID Governance features — I’ve observed cases where users retained access even after leaving Defra.
- Enable monitoring of Entra ID audit logs for changes to sensitive group.
- Projects **should** add a description to Entra ID groups to explain their purpose/context.



The above principles have been distilled from the below Microsoft best practice "rules of thumb", take note that as with many things, there are nearly as many "right" approaches as "wrong" ones, this document is intended to guide Entra ID group naming, **not** assist with Application security design. See [Entra ID Security Group usage examples](#entra-id-security-group-usage-examples).

*You should only nest "User" groups [Group classification and scope](#group-classification-and-scope)

## Entra ID Security Group Name Structure

This naming convention document cannot account for all possible permutations of group types and permissions, however the first four parts should be separated by a hyphen, and should conform to the standards listed below.

- Principle of Least Privilege **should** be observed when planning Groups.
- Each of the first four sections **should not** contain hyphens, sections should be delimited with underscores if necessary.
- Entra ID Group name **must not** contain a non alphanumeric character or white space.
- Group description **should** contain a human readable description of group purpose.
- "Automated" groups **must** contain description, explaining automation method.

### Group name structure

**User Group**: \<home directory and membership type\>-\<Classification\>-\<Scope\>-\<grouping criteria\>

**Access Group**: \<home directory and membership type\>-\<Classification\>-\<Scope\>-\<permission\>

**RBAC Access Group**: \<home directory and membership type\>-\<Supplier\>-<classification>-<scope(SERVICE)>>-\<team>  

### Home directory and membership type

The first section refers to the Group home directory and membership "type". If the group has been created in Entra ID, this would be AG. If the group has been created in a "classic" Active Directory, and synchronised to Entra ID, this should be SG.  Further examples below.

Group membership type refers to whether the group membership is automated, dynamic, or manual. "Automated" would normally only be used for "User" groups (see Group Classification and Scope), Groups with the "Automated" designation **must not** have membership changed manually, they **must** give details in the description of where the group membership automation takes place.

| Code | Description |
|-|-|
| AG | Entra ID Group |
| SG | AD Synchronised Group |
| AAG | Automated Entra ID Group |
| DAG | Dynamic Entra ID Group (using Entra ID "Dynamic Groups" feature)|
| ASG | Automated AD Synchronised Group |
| DSG | Dynamic AD Synchronised Group |

### Group classification

Groups primarily fall into two Classification types, "Users" and "Access" , the criteria for this classification is whether the group is used to group Users together, or used to provide Access to a securable*.  Secondarily they will fall into sub classifications relating to their function, both primary and secondary classifications are indicated by a single word (primary classification is inferred from secondary).

 When planning group names for any securable or user groups, it will quickly become clear that a balance must be struck between too granular an approach producing too many groups, and too broad an approach meaning some users have access they do not require; some judgment is required, please bear the following principles in mind whilst planning:

- A "Users" group should never be assigned direct Access to a securable, it should contain only users or other "Users" groups.
- An "Access" group, should be used to provide minimum access to minimum resources, they should never have another "Access" group as a member.

| Code | Class |Description |
|-|-|-|
| Azure | Access | Azure resource scope, eg Subscription |
| AAD | Access | Entra ID permission |
| ADO | Access | Azure DevOps permission |
| APP | Access | Azure App Registration permission |
| CAC | Access |Conditional Access Policy assignment |
| EOL | Access | Exchange Online |
| GitHub | Access | GitHub permission |
| Intune | Access | Intune assignment group |
| LIC | Access | License assignment |
| PowerBI | Access | PowerBI role/perm assignment |
| Purview | Access | Purview role/perm assignment |
| SPO | Access | Sharepoint Online role/perm assignment |
| Users | Users | logical grouping of users (geographic, function, group) |
| EA | Users | Legacy User groups, use "Users" instead |
| RPA | Users | Legacy User groups, use "Users" instead |
| Defra | Users | Legacy User group, use "Users" instead |
| RBAC | Access | RBAC role assignment group, used to manage role-based permissions across Microsoft 365 or Entra ID services |

*This follows Microsoft best practice, see section [Entra ID Security Group usage principles](#entra-id-security-group-usage-principles)

### Supplier designation

Use a short code for the supplier name (e.g., ATOS, CAPGEM, DXC) to segregate external access. This is mandatory for RBAC groups involving suppliers to enable quick auditing/revocation.

Examples: ATOS, CAPGEM


### Scope

The scope section should provide a human readable method of identifying the group scope. User groups this should reference the Department (eg; "Defra", "APHA"). Access groups have a large amount of possible scopes, just ensure it is readily identifiable, examples below:

| Code | Class |Description |
|-|-|-|
| AG-Azure-AZR_SEC | Access | Azure Subscription "AZR-SEC" |
| AG-ADO-Org | Access | Azure DevOps Organisation permission |
| AG-ADO-Proj | Access | Azure DevOps Project level permission |
| AG-Users-Defra | Users | Entra ID Users group, containing users from within Defra Organisation |
| AG-Users-EA | Users | Entra ID Users group, containing users from within Environment Agency Organisation |
| AG-Users-Kainos | Users | Entra ID Users group, containing users from within Kainos Organisation |

### Service scope

For RBAC Access groups, include a <service> code to indicate where permissions are assigned (e.g., AAD for Entra ID, EOL for Exchange Online)


|Code | Service |
|-|-|
|AAD |Entra ID (Azure AD) |
|INTUNE | Intune | 
|PURVIEW |Purview |
| SPO | Sharepoint Online |
| LogMein | Remote Access support sofware |
| EOL | Exchange online |


### Team designation

For supplier RBAC groups, append <team> (e.g., ServiceDesk) to specify the internal team. This aids in role assignment without over-granularity.

Examples: ServiceDesk, M365



### Permission or criteria

The final convention specified field depends on whether it is an Access or Users group.  An Access group should refer the Access granted to the group (read/write etc), Built-in Roles should be used wherever possible, with full role names abbreviated as per [Access Group permission abbreviations](#access-group-permission-abbreviations), if the access requires Entra ID PIM (Privileged IDentity Management) elevation, the permission should be prefixed with "PIM_" . A Users group should refer to the criteria for group membership ("London Office","chess club" etc).

| Code | Class |Description |
|-|-|-|
| AG-Azure-AZR_SEC-Cont | Access | Contributor permission |
| AG-Azure-AZR_SEC-ContUAA | Access | Contributor and User Access Administrator permission |
| AG-Azure-AZR_SEC-PIM_Own | Access | PIM controlled Owner permission |
| AG-Users-Defra-BirminghamBookclub | Users | Defra Organisation Birmingham office Book club members |
| AG-Users-RPA-Dorset | Users | RPA Organisation Dorset Area staff|

## Access Group permission abbreviations

This is a non exhaustive list of abbreviations for Built-In roles.

|Platform|Built in Role|Abbreviation|Description|
|:----|:----|:----|:----|
|Azure|Contributor|Cont|Grants full access to manage all resources, but does not allow you to assign roles in Azure RBAC, manage assignments in Azure Blueprints, or share image galleries.|
|Azure|Owner|Own|Grants full access to manage all resources, including the ability to assign roles in Azure RBAC.|
|Azure|Reader|Read|View all resources, but does not allow you to make any changes.|
|Azure|User Access Administrator|UAA|Lets you manage user access to Azure resources.|
|Azure|Virtual Machine Administrator Login|VMAdm|View Virtual Machines in the portal and login as administrator|
|Azure|Virtual Machine Contributor|VMCont|Create and manage virtual machines, manage disks, install and run software, reset password of the root user of the virtual machine using VM extensions, and manage local user accounts using VM extensions. This role does not grant you management access to the virtual network or storage account the virtual machines are connected to. This role does not allow you to assign roles in Azure RBAC.|
|Azure|CDN Endpoint Contributor|CDNEndCont|Can manage CDN endpoints, but can't grant access to other users.|
|Azure|CDN Profile Contributor|CDNProfCont|Can manage CDN profiles and their endpoints, but can't grant access to other users.|
|Azure|DNS Zone Contributor|DNSCont|Lets you manage DNS zones and record sets in Azure DNS, but does not let you control who has access to them.|
|Azure|Private DNS Zone Contributor|PDNSCont|Lets you manage private DNS zone resources, but not the virtual networks they are linked to.|
|Azure|SQL DB Contributor|SQLCont|Lets you manage SQL databases, but not access to them. Also, you can't manage their security-related policies or their parent SQL servers.|
|Azure|Managed Identity Contributor|MICont|Create, Read, Update, and Delete User Assigned Identity|
|Azure|Key Vault Administrator|KVAdmin|Perform all data plane operations on a key vault and all objects in it, including certificates, keys, and secrets. Cannot manage key vault resources or manage role assignments. Only works for key vaults that use the 'Azure role-based access control' permission model.|
|Azure|Key Vault Certificates Officer|KVCO|Perform any action on the certificates of a key vault, except manage permissions. Only works for key vaults that use the 'Azure role-based access control' permission model.|
|Azure|Key Vault Contributor|KVCont|Manage key vaults, but does not allow you to assign roles in Azure RBAC, and does not allow you to access secrets, keys, or certificates.|
|Azure|Key Vault Crypto User|KVCrypUser|Perform cryptographic operations using keys. Only works for key vaults that use the 'Azure role-based access control' permission model.|
|Azure|Key Vault Reader|KVSecRead|Read metadata of key vaults and its certificates, keys, and secrets. Cannot read sensitive values such as secret contents or key material. Only works for key vaults that use the 'Azure role-based access control' permission model.|
|Azure|Key Vault Secrets User|KVSecUser|Read secret contents. Only works for key vaults that use the 'Azure role-based access control' permission model.|
|Entra ID|Application Administrator|AppAdm|Can create and manage all aspects of app registrations and enterprise apps.|
|Entra ID|Application Developer|AppDev|Can create application registrations independent of the 'Users can register applications' setting.|
|Entra ID|Azure DevOps Administrator|ADOAdm|Can manage Azure DevOps policies and settings.|
|Entra ID|Billing Administrator|BillAdm|Can perform common billing related tasks like updating payment information.|
|Entra ID|Cloud App Security Administrator|CloudAppSecAdm|Can manage all aspects of the Defender for Cloud Apps product.|
|Entra ID|Cloud Application Administrator|CloudAppAdm|Can create and manage all aspects of app registrations and enterprise apps except App Proxy.|
|Entra ID|Cloud Device Administrator|CloudDevAdm|Limited access to manage devices in Entra ID.|
|Entra ID|Compliance Administrator|CompAdm|Can read and manage compliance configuration and reports in Entra ID and Microsoft 365.|
|Entra ID|Conditional Access Administrator|CondAccAdm|Can manage Conditional Access capabilities.|
|Entra ID|Directory Readers|DirRead|Can read basic directory information. Commonly used to grant directory read access to applications and guests.|
|Entra ID|Exchange Administrator|EOLAdm|Can manage all aspects of the Exchange product.|
|Entra ID|Global Administrator|GlobalAdm|Can manage all aspects of Entra ID and Microsoft services that use Entra ID identities.|
|Entra ID|Global Reader|GlobalRead|Can read everything that a Global Administrator can, but not update anything.|
|Entra ID|License Administrator|LicAdm|Can manage product licenses on users and groups.|
|Entra ID|Network Administrator|NetAdm|Can manage network locations and review enterprise network design insights for Microsoft 365 Software as a Service applications.|
|Entra ID|Power BI Administrator|PBIAdm|Can manage all aspects of the Power BI product.|
|Entra ID|Privileged Role Administrator|PIMRoleAdm|Can manage role assignments in Entra ID, and all aspects of Privileged Identity Management.|
|Entra ID|Security Administrator|SecAdm|Can read security information and reports, and manage configuration in Entra ID and Office 365.|
|Entra ID|Security Operator|SecOp|Creates and manages security events.|
|Entra ID|Security Reader|SecRead|Can read security information and reports in Entra ID and Office 365.|
|Entra ID|SharePoint Administrator|SPOAdm|Can manage all aspects of the SharePoint service.|
|Entra ID|User Administrator|UserAdm|Can manage all aspects of users and groups, including resetting passwords for limited admins.|
|Entra ID|Windows 365 Administrator|W365Adm|Can provision and manage all aspects of Cloud PCs.|
|ADO|Project Collection Administrators |PCAdm| administrative rights to all projects within the collection. |
|ADO|Project Collection Build Administrators |PCABuildAdm|permit users to administer build resources and permissions, including to manage test environments, create test runs, and manage builds at the collection level.|
|ADO|Project Administrators |ProjAdm|have administrative permissions to the project.|
|ADO|Project Build Administrators |ProjBuildAdm|permit users to administer build resources and permissions, including to manage test environments, create test runs, and manage builds at the project level.|
|ADO|Release Administrators |RelAdm|permit users to manage release operations at the collection or project level.|
|ADO|Contributors |Cont|include developers that permit modification of code repositories and work item tracking.|
|ADO|Readers |Read|have read access to projects.|

## Group naming examples

| Name | Home and management type | Classification | Scope | Permission or Criteria |
|-|-|-|-|-|
| AG-Azure-AZR_SEC-Contributor | Manual or hybrid managed Entra ID | Access (Azure Resource) | Azure Subscription "AZR-SEC" | Builtin Contributor role |
| AG-Azure-AZR_SEC-Reader | Manual or hybrid managed Entra ID | Access (Azure Resource) | Azure Subscription "AZR-SEC" | Builtin Reader role |
| AG-AAD-Defra-GlobalRead | Manual or hybrid managed Entra ID | Entra ID Permission | Azure Tenant Defra | Builtin Global Reader role |
| AG-ADO-Proj_FFC-PAdmin | Manual or hybrid managed Entra ID | Access (Azure DevOps) | Azure DevOps Project "FFC" (note; strategic defragovuk is assumed) | Project Administrator |
| AG-ADO-defragovuk-PCAdmin | Manual or hybrid managed Entra ID | Access (Azure DevOps) | Azure DevOps Organisation defragovuk | Project Collection Administrator |
| AG-Users-Defra-BirminghamBookclub | Manual or hybrid managed Entra ID | Users | Defra Organisation (multi ALB groups should use "Defra") | Birmingham office Book club members |
| AAG-Users-RPA-Dorset | Automation managed Entra ID | Users | RPA Organisation | Dorset Area staff |
| AG-ATOS-RBAC-AAD-ServiceDesk             | Manual, Entra ID         | (RBAC) Access         | ATOS      | Assigned Entra ID roles for Service Desk team |
| AG-Capgemini-RBAC-Purview-ComplianceTeam | Manual, Entra ID         | (RBAC) Access         | Capgemini | Assigned Purview roles for compliance         |
|  AG-ATOS-RBAC-LogMeIn Service Desk Managers | Manual, Entra ID      | (RBAC) Access         | ATOS | Assigned LogmeIn roles for access         |


## Entra ID Security Group usage examples

Requirement: CCoE Architect should have Global read access to Azure DevOps and Entra ID.  Each example meets these requirements in different ways, but only the first is deployed as per best practice.

#### Optimal example

| Object name | Type | Description | Access assigned | Member of | Compliance with guidance |
|-|-|-|-|-|-|
| Mike Blake | User | User Object | None |  AG-Users-Defra-CCoE_Architects | High |
| AG-Users-Defra-CCoE_Architects | **User** Group | Members of the CCoE Architecture team | None | AG-AAD-Defra-GlobalRead <br></br> AG-ADO-defragovuk-All_Proj_reader | High |
| AG-AAD-Defra-GlobalRead | **Access** Group | Global Reader access to Defra Entra ID | AG-AAD-Defra-GlobalRead | None | High |
| AG-ADO-defragovuk-All_Proj_reader | **Access** Group | All project Read Access (Azure DevOps) | Read access to all ADO projects | None | High |

#### Sub optimal examples

**This example shows direct assignment of Entra ID role to user**

| Object name | Type | Description | Access assigned | Member of | Compliance with guidance |
|-|-|-|-|-|-|
| Mike Blake | User | User Object | Global Reader role |  AG-Users-Defra-CCoE_Architects | **Low** |
| AG-Users-Defra-CCoE_Architects | **User** Group | Members of the CCoE Architecture team | None | AG-AAD-Defra-GlobalRead <br></br> AG-ADO-defragovuk-All_Proj_reader | High |
| AG-ADO-defragovuk-All_Proj_reader | **Access** Group | All project Read Access (Azure DevOps) | Read access to all ADO projects | None | High |

**This example shows nesting of "Access" group**

| Object name | Type | Description | Access assigned | Member of | Compliance with guidance |
|-|-|-|-|-|-|
| Mike Blake | User | User Object | None |  AG-Users-Defra-CCoE_Architects | High |
| AG-Users-Defra-CCoE_Architects | **User** Group | Members of the CCoE Architecture team | None | AG-AAD-Defra-GlobalRead | High |
| AG-AAD-Defra-GlobalRead | **Access** Group | Global Reader access to Defra Entra ID | AG-AAD-Defra-GlobalRead | AG-ADO-defragovuk-All_Proj_reader | **Low** |
| AG-ADO-defragovuk-All_Proj_reader | **Access** Group | All project Read Access (Azure DevOps) | Read access to all ADO projects | None | High |



The naming Convention document  is a living document operated and updated by CCoE.

---

## Document Version Control

| Version | Date       | Status | Change Summary | Reviewers/Approvers |
| ------- | ---------  | ------ | -------------- | ------------------- |
| 1.0     | 22-11-2022 | Issued | Initial Issue  | CCoE Architecture Team & WebOps Representatives |WebOps Representatives |
| 1.1     | 25-01-2023 | Issued | Post CDRB changes  | CCoE Architecture Team & WebOps Representatives |WebOps Representatives |
| 1.2     | 06-11-2023 | Issued | Entra ID rename, clarifications | CCoE Architecture Team & WebOps Representatives |WebOps Representatives |
| 1.3     | 16-05-2024 | Issued | clarifications, examples, reorder | CCoE Architecture Team & WebOps Representatives |WebOps Representatives |
| 1.4     | 20-07-02025 | Issued | Addiiton of RBAC Groups |

> Please note that before the date 20/10/20 CCoE were known as CSC Cloud Service Centre.

Document Classification `OFFICIAL`
