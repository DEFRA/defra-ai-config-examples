---
name: architecture-guidance
description: Provides Defra organisational architecture guidance sourced from Azure DevOps wikis — the approved/allowed tools & technology list, cloud architecture patterns, security standards, and naming & tagging conventions. Use this to constrain technology choices and architecture decisions to what the organisation actually permits. The guidance is kept in local reference files that are refreshed from the wiki by the sync script; if the wiki is unreachable the last-synced local copy is used.
user-invocable: true
argument-hint: "[topic] — e.g. approved tools, cloud patterns, security, naming (optional)"
---

You provide Defra's organisational architecture guidance for the service being re-engineered. This skill bundles guidance that originates in **Azure DevOps wikis** and is materialised into local reference files so the whole pack stays offline-first and portable.

## Where the guidance comes from

The four reference files below are **synced from Azure DevOps wikis** by `sync/refresh.mjs` and committed to git. That committed copy is the **offline fallback**: the agents always read the local files, whether or not the wiki is reachable.

| Topic | Reference file |
|-------|----------------|
| Approved / allowed tools & technology | [reference/approved-tools.md](reference/approved-tools.md) |
| Cloud architecture patterns | [reference/cloud-patterns.md](reference/cloud-patterns.md) |
| Security standards | [reference/security-standards.md](reference/security-standards.md) |
| Naming & tagging conventions | [reference/naming-conventions.md](reference/naming-conventions.md) |

Each file begins with a provenance header recording the wiki page, its version, and when it was fetched. [reference/_sync-manifest.json](reference/_sync-manifest.json) records the sync status of every file.

## Steps

1. **Read the relevant reference file(s)** for the topic you were asked about (or all four if unspecified).
2. **Check freshness.** Read the provenance header (or `_sync-manifest.json`). If a file is marked `never-synced`, is empty of real guidance, or was fetched a long time ago, say so — treat it as an **open question / caveat**, do not invent content to fill the gap.
3. **Return the guidance** as a structured summary, quoting the source wiki page and the fetched date so a reviewer can verify it. Preserve the **OFFICIAL** classification note.

## Refreshing the guidance

To pull the latest wiki content into the reference files:

```
node .github/skills/architecture-guidance/sync/refresh.mjs
```

- Requires an Azure DevOps Personal Access Token with **Wiki (Read)** scope in the `AZURE_DEVOPS_PAT` environment variable (or `SYSTEM_ACCESSTOKEN` in a pipeline).
- Wiki locations are configured in [sync/wiki-sources.json](sync/wiki-sources.json) — **no secrets** live in that file.
- To discover the real page paths to put in the config, list the wiki tree: `node .github/skills/architecture-guidance/sync/refresh.mjs --list`.
- If no token is set or the wiki is unreachable, the script warns and leaves the committed reference files untouched, so the pipeline continues on the last-synced copy.

## Rules

- Do not invent or relax any guidance. If the local copy has no content for a topic, raise it as an open question rather than guessing.
- Never treat a `never-synced` placeholder as authoritative.
- Always quote the source wiki page and fetched date; preserve the OFFICIAL classification note in any derived artefact.
- Anything a design proposes that is **not** on the approved tools list must be flagged, not silently accepted.
