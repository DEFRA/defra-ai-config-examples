#!/usr/bin/env node
// Syncs Azure DevOps wiki pages into local reference/*.md files for the
// architecture-guidance skill. Best-effort: on any auth/network/config problem it
// warns and leaves the committed reference files untouched (the offline fallback),
// exiting 0 so the LAP pipeline never breaks.

import { readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const skillDir = resolve(__dirname, "..");
const configPath = resolve(__dirname, "wiki-sources.json");
const manifestPath = resolve(skillDir, "reference", "_sync-manifest.json");

const RECURSION = { none: "None", onelevel: "OneLevel", full: "Full" };

function warn(msg) {
  console.warn(`[architecture-guidance sync] WARNING: ${msg}`);
}
function info(msg) {
  console.log(`[architecture-guidance sync] ${msg}`);
}

function authHeader(pat) {
  const token = Buffer.from(`:${pat}`).toString("base64");
  return { Authorization: `Basic ${token}`, Accept: "application/json" };
}

// Fetch one wiki page (with its immediate children listed) and return
// { path, content, remoteUrl, version, subPaths }.
async function fetchPage(cfg, pat, path, discoverChildren) {
  const level = discoverChildren ? "OneLevel" : "None";
  const base = `${cfg.organization}/${encodeURIComponent(cfg.project)}/_apis/wiki/wikis/${encodeURIComponent(cfg.wikiIdentifier)}/pages`;
  const url = `${base}?path=${encodeURIComponent(path)}&includeContent=true&recursionLevel=${level}&api-version=${cfg.apiVersion}`;
  const res = await fetch(url, { headers: authHeader(pat) });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} ${res.statusText} for page '${path}'`);
  }
  const body = await res.json();
  return {
    path: body.path ?? path,
    content: body.content ?? "",
    remoteUrl: body.remoteUrl ?? "",
    version: res.headers.get("etag") ?? "",
    subPaths: Array.isArray(body.subPages) ? body.subPages.map((p) => p.path) : [],
  };
}

// Print the full wiki page tree so a user can pick real page paths for the config.
async function listPages(cfg, pat) {
  const base = `${cfg.organization}/${encodeURIComponent(cfg.project)}/_apis/wiki/wikis/${encodeURIComponent(cfg.wikiIdentifier)}/pages`;
  const url = `${base}?path=/&recursionLevel=Full&api-version=${cfg.apiVersion}`;
  const res = await fetch(url, { headers: authHeader(pat) });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} ${res.statusText} listing wiki '${cfg.wikiIdentifier}'`);
  }
  const root = await res.json();
  const lines = [];
  const walk = (node, depth) => {
    if (node.path && node.path !== "/") lines.push(`${"  ".repeat(depth)}${node.path}`);
    for (const child of node.subPages || []) walk(child, depth + 1);
  };
  walk(root, 0);
  info(`wiki page tree for '${cfg.wikiIdentifier}':`);
  console.log(lines.join("\n"));
}

// Collect a page and, per `mode`, its descendants. Returns an array of page parts.
async function collect(cfg, pat, path, mode) {
  const discover = mode !== "none";
  const page = await fetchPage(cfg, pat, path, discover);
  const parts = [page];
  if (mode === "onelevel") {
    for (const child of page.subPaths) {
      parts.push(await fetchPage(cfg, pat, child, false));
    }
  } else if (mode === "full") {
    for (const child of page.subPaths) {
      parts.push(...(await collect(cfg, pat, child, "full")));
    }
  }
  return parts;
}

function normalizeMode(recursion) {
  const key = String(recursion || "none").toLowerCase();
  return RECURSION[key] ? key : "none";
}

// An output file may aggregate several wiki pages: prefer entry.sources[], fall
// back to a single entry.path for backward compatibility.
function entrySources(entry) {
  if (Array.isArray(entry.sources) && entry.sources.length) {
    return entry.sources.map((s) => ({ path: s.path, mode: normalizeMode(s.recursion) }));
  }
  return [{ path: entry.path, mode: normalizeMode(entry.recursion) }];
}

function renderFile(cfg, sources, parts, fetchedAt) {
  const header = [
    "<!-- SYNCED FROM AZURE DEVOPS WIKI — DO NOT EDIT BY HAND (overwritten on next sync).",
    `     Source: ${cfg.organization}/${cfg.project} wiki '${cfg.wikiIdentifier}'`,
    `     Pages: ${sources.map((s) => s.path).join("; ")}`,
    `     Fetched: ${fetchedAt}`,
    "     Classification: OFFICIAL -->",
    "",
  ].join("\n");
  const bodies = parts
    .filter((p) => p.content && p.content.trim().length > 0)
    .map((p) => `<!-- wiki page: ${p.path}${p.remoteUrl ? ` (${p.remoteUrl})` : ""} -->\n\n${p.content}`);
  return `${header}\n${bodies.join("\n\n")}\n`;
}

async function loadManifest() {
  if (!existsSync(manifestPath)) return { entries: {} };
  try {
    return JSON.parse(await readFile(manifestPath, "utf8"));
  } catch {
    return { entries: {} };
  }
}

async function main() {
  if (!existsSync(configPath)) {
    warn(`config not found at ${configPath}; nothing to sync.`);
    return 0;
  }

  let cfg;
  try {
    cfg = JSON.parse(await readFile(configPath, "utf8"));
  } catch (err) {
    warn(`could not parse wiki-sources.json (${err.message}); keeping local copies.`);
    return 0;
  }

  if (typeof cfg.organization !== "string" || !cfg.organization.startsWith("https://")) {
    warn("organization must be an https:// Azure DevOps URL; refusing plaintext/misconfigured endpoint. Keeping local copies.");
    return 0;
  }
  if (cfg.organization.includes("YOUR-ORG") || cfg.project === "YOUR-PROJECT" || cfg.wikiIdentifier === "YOUR-WIKI") {
    warn("wiki-sources.json still contains placeholder values (YOUR-ORG/YOUR-PROJECT/YOUR-WIKI). Edit it before syncing. Keeping local copies.");
    return 0;
  }

  const pat = process.env.AZURE_DEVOPS_PAT || process.env.SYSTEM_ACCESSTOKEN;
  if (!pat) {
    warn("no AZURE_DEVOPS_PAT (or SYSTEM_ACCESSTOKEN) set; cannot reach the wiki. Using last-synced local copies.");
    return 0;
  }

  if (process.argv.includes("--list")) {
    try {
      await listPages(cfg, pat);
    } catch (err) {
      warn(`could not list wiki pages (${err.message}).`);
    }
    return 0;
  }

  const manifest = await loadManifest();
  manifest.organization = cfg.organization;
  manifest.project = cfg.project;
  manifest.wikiIdentifier = cfg.wikiIdentifier;
  manifest.lastRun = new Date().toISOString();
  manifest.entries = manifest.entries || {};

  let ok = 0;
  let failed = 0;
  for (const entry of cfg.pages || []) {
    const sources = entrySources(entry);
    const outPath = resolve(skillDir, entry.out);
    const fetchedAt = new Date().toISOString();
    try {
      const parts = [];
      for (const s of sources) parts.push(...(await collect(cfg, pat, s.path, s.mode)));
      await writeFile(outPath, renderFile(cfg, sources, parts, fetchedAt), "utf8");
      manifest.entries[entry.out] = {
        sources: sources.map((s) => ({ path: s.path, recursion: s.mode })),
        pageCount: parts.filter((p) => p.content && p.content.trim()).length,
        fetchedAt,
        status: "synced",
      };
      ok += 1;
      info(`synced ${sources.length} source(s) -> ${entry.out}`);
    } catch (err) {
      failed += 1;
      const prev = manifest.entries[entry.out] || {};
      manifest.entries[entry.out] = {
        ...prev,
        sources: sources.map((s) => ({ path: s.path, recursion: s.mode })),
        status: "failed (kept previous)",
        lastError: err.message,
        lastAttemptedAt: fetchedAt,
      };
      warn(`could not sync '${entry.out}' (${err.message}); kept existing file.`);
    }
  }

  try {
    await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  } catch (err) {
    warn(`could not write sync manifest (${err.message}).`);
  }

  info(`done: ${ok} synced, ${failed} failed. Failures fall back to the committed local copy.`);
  return 0;
}

main()
  .then((code) => process.exit(code ?? 0))
  .catch((err) => {
    // Never break the pipeline: log and exit 0 so the committed fallback is used.
    warn(`unexpected error (${err.message}); using last-synced local copies.`);
    process.exit(0);
  });
