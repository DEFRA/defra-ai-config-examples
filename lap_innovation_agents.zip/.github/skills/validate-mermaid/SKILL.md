---
name: validate-mermaid
description: Validates all Mermaid diagram blocks in a markdown file and fixes broken diagrams in place. Uses a Mermaid validation MCP tool if one is available, otherwise performs a best-effort syntax review.
user-invocable: true
argument-hint: "[markdown-file-path]"
---

You validate every Mermaid diagram block in a markdown file. For each broken diagram you attempt to fix it in place, retrying up to 2 times.

## Input

The markdown file path is provided as the argument to this skill.

## Steps

1. **Read the file** using the `read` tool.

2. **Extract all fenced Mermaid blocks.** Identify every occurrence of a ` ```mermaid ` code fence and its closing ` ``` `. Note the line numbers and content of each block. If no Mermaid blocks are found, report "No Mermaid diagrams found in [file path]" and stop.

3. **Validate each block.**
   - If a Mermaid validation MCP tool is available in the current tool set (for example a Mermaid Chart server exposing a validate/render tool), call it for each block, passing the content between the fences and the diagram type inferred from the first line (e.g. `flowchart`, `sequenceDiagram`, `gantt`, `classDiagram`).
   - If no such MCP tool is available, perform a best-effort static syntax review: check for a valid diagram-type header, balanced brackets and quotes, valid node/edge syntax, matched `subgraph`/`end` pairs, and label characters that need escaping.
   - If validation cannot be performed at all, report "Mermaid validation skipped — no validator available" and stop. Do not fail the caller's workflow.

4. **Fix broken diagrams.** For each block that fails validation:
   - Determine the fix based on the error or the syntax issue found.
   - Use the `edit` tool to replace the broken mermaid content with the corrected version (use the full block content as the text to replace and the fixed content as the replacement).
   - Re-validate. If it still fails, attempt one more fix (maximum 2 retries per block).
   - If a block remains broken after 2 retries, mark it as unfixable and continue to the next block.

5. **Report results.** Return a summary containing:
   - Total number of Mermaid blocks found
   - Number that passed validation on first attempt
   - Number that were fixed (with a brief note of what was wrong)
   - Number that remain broken after retries (with the error details)
