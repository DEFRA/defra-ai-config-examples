# LAP Innovation Agents

GitHub Copilot custom agents and skills for Defra's Legacy Application Programme (LAP). They reverse engineer legacy applications — turning screenshots, interview transcripts, and source code into a Product Requirements Document (PRD) and a set of individually deliverable, **standards-compliant** feature specifications, with end-to-end traceability so that **no functionality is lost** when the features are built.

These run entirely inside GitHub Copilot in VS Code. There is no CLI, container, or build step — the agents live in `.github/agents/` and the skills in `.github/skills/`, and appear in the Copilot agent and slash-command pickers.

## Data classification

**Only use these agents on source material classified as OFFICIAL.** Do not use them with material at any higher classification.

## What's baked in

Every PRD and feature specification embeds Defra's delivery standards from the outset (see [.github/instructions/lap-delivery-standards.instructions.md](.github/instructions/lap-delivery-standards.instructions.md)):

- **Defra software development standards** and the GDS Service Standard / Technology Code of Practice.
- **≥ 90% test coverage**, with every acceptance criterion mapped to a named automated test.
- **WCAG 2.2 level AA** for all user interfaces.
- **Secure by design** (OWASP Top 10), observability, and IaC.
- **Cloud service-tier requirements** (AWS or Azure; tiers 1a/1b/2/3/4) from the Defra CCoE Azure Service Tier Reference Architecture, applied by the `cloud-tier-architect` agent.
- **No silent loss of functionality:** a stable-ID traceability chain plus a completeness auditor mean a capability is either implemented-and-tested or explicitly deferred with a justification — never dropped by accident.
- **Rebuild-grade analysis depth:** every analysis and the PRD must be detailed enough to rebuild the application from — exhaustive, quantified, evidence-cited enumeration with grounding labels, plus the document-vs-code (`D`), findings (`S`), functionality-loss-risk (`R`), open-question (`OQ`) and deferred-source (`G`) registers (see [.github/instructions/lap-analysis-depth.instructions.md](.github/instructions/lap-analysis-depth.instructions.md)).
- **A single shareable documentation pack:** every run ends by rendering all the outputs into one self-contained, offline HTML file (`output/documentation-pack.html`) with an Overview dashboard, a filterable **Open questions** view, a **Functionality coverage (no silent loss)** view, a feature index, full-text search and zoomable diagrams — the only file you need to send a reviewer.

## Inputs and outputs

Place raw material in the workspace using this layout:

| Directory | Contents |
|-----------|----------|
| `screenshots/` | UI screenshots of the legacy application |
| `transcripts/` | Stakeholder interview transcripts (`.txt`) |
| `src/` | Legacy application source code (.NET/VB, SQL, etc.) |

The agents generate:

| Path | Produced by | Description |
|------|-------------|-------------|
| `output/html/*.html` | `image-to-html` | Semantic HTML mockup of each screenshot |
| `output/transcripts/*_curated.txt` | `curate-transcript` | Curated interview transcripts |
| `output/domain-analysis.md` | `business-analyst` | Strategic DDD analysis |
| `output/interaction-analysis.md` | `interaction-analyst` | Screen inventory, workflows, navigation map |
| `output/application-analysis.md` | `application-developer` | Application code analysis |
| `output/database-analysis.md` | `database-analyst` | Database schema and logic analysis |
| `output/PRD.md` | `product-manager` | Product Requirements Document |
| `output/open-questions.md` | `product-manager` | Consolidated Open Items Register (`D`/`S`/`R`/`OQ`/`G`) surfaced as the pack's Open-questions view |
| `output/architecture-requirements.md` | `cloud-tier-architect` | Cloud/service-tier NFRs, architecture requirements, and an infrastructure diagram |
| `output/features/FT-*.md` | `prd-to-features` / `feature-writer` | Individual feature specifications |
| `output/features/manifest.json` | `prd-to-features` | Machine-readable traceability manifest |
| `output/traceability.md` | `prd-to-features` | Human-readable requirements traceability matrix |
| `output/descope-register.md` | `prd-to-features` | The register of explicitly deferred functionality |
| `output/documentation-pack.html` | `html-pack` | Single self-contained, offline interactive pack of every document, with Open-questions and Functionality-coverage views |
| `output/completeness-report.md` | `completeness-auditor` | Build reconciliation report |
| `output/modernisation-example.md` | `modernisation-example-writer` | Publishable LAP blueprint modernisation-example (project playbook) page |

## Agents

| Agent | Description |
|-------|-------------|
| `lap-orchestrator` | Runs the whole pipeline via subagents and seeds the build repository |
| `digital-content-curator` | Converts screenshots to HTML mockups and curates transcripts (via `digital-content-processor`) |
| `digital-content-processor` *(internal)* | Worker that runs a single skill against a single file |
| `business-analyst` | Extracts strategic DDD patterns from curated transcripts and mockups |
| `interaction-analyst` | Produces screen inventory, workflows, and navigation map |
| `application-developer` | Analyses legacy .NET/VB source code |
| `database-analyst` | Analyses legacy SQL Server database code |
| `product-manager` | Synthesises the four analyses into the PRD (with stable requirement IDs) |
| `cloud-tier-architect` | Applies AWS/Azure service-tier requirements to the PRD and writes the architecture requirements |
| `prd-to-features` | Decomposes the PRD into features, verifies full coverage, and emits the traceability manifest |
| `feature-writer` *(internal)* | Writes a single standards-compliant feature spec with per-criterion test IDs |
| `completeness-auditor` | Reconciles the build against the manifest so functionality is never lost |
| `modernisation-example-writer` | Writes a publishable LAP blueprint modernisation-example page (Project summary, As-is/To-be/Steps taken, Tech stack, Benefits) from the PRD and new code |

## Skills

| Skill | Description |
|-------|-------------|
| `image-to-html` | Converts a legacy UI screenshot into semantic, unstyled mockup HTML |
| `curate-transcript` | Removes off-topic content from an interview transcript |
| `infra-diagram` | Draws a cloud infrastructure diagram (Mermaid `architecture-beta`) using provider logos where available |
| `validate-mermaid` | Validates and fixes Mermaid diagram blocks in a markdown file |
| `cloud-tier-requirements` | Provides the Defra CCoE service-tier standards and reference architectures |
| `architecture-guidance` | Provides organisational architecture guidance (approved tools, cloud patterns, security standards, naming conventions) synced from Azure DevOps wikis, with an offline local fallback |
| `html-pack` | Renders the `output/` markdown into one self-contained, offline interactive HTML documentation pack |

## Pipeline

```mermaid
flowchart TB
    screenshots(["screenshots/"]) --> curator[digital-content-curator]
    transcripts(["transcripts/"]) --> curator
    src(["src/"]) --> appdev[application-developer] & dbanalyst[database-analyst]

    curator --> html(["output/html/*.html"]) & curated(["output/transcripts/*_curated.txt"])
    html & curated --> ba[business-analyst] & ia[interaction-analyst]

    appdev --> aa(["application-analysis.md"])
    dbanalyst --> da(["database-analysis.md"])
    ba --> dom(["domain-analysis.md"])
    ia --> inter(["interaction-analysis.md"])

    aa & da & dom & inter --> pm[product-manager]
    pm --> prd(["output/PRD.md"])
    prd --> cta[cloud-tier-architect]
    cta --> arch(["architecture-requirements.md"])
    prd & arch --> p2f[prd-to-features]
    p2f --> fw[feature-writer]
    fw --> features(["output/features/FT-*.md"])
    p2f --> manifest(["manifest.json + traceability.md"])

    features & manifest --> pack[html-pack]
    pack --> packhtml(["output/documentation-pack.html"])
    features & manifest & packhtml --> build[["New build repo (Copilot Ralph)"]]
    build --> auditor[completeness-auditor]
```

## How to run it

1. Add your `screenshots/`, `transcripts/`, and `src/` to the workspace.
2. In Copilot chat, select the **`lap-orchestrator`** agent and start it. It will confirm the target cloud and service tier, run the pipeline, build the shareable `output/documentation-pack.html`, and (when you're ready) seed a new build repository with the feature specs, manifest, pack, `completeness-auditor`, and standards.
3. Or run the agents individually in order: `digital-content-curator` → `product-manager` → `cloud-tier-architect` → `prd-to-features` (which builds the pack as its final step).
4. During the build, run **`completeness-auditor`** each iteration to keep functionality from being lost. Rebuild the pack any time with `node .github/skills/html-pack/pack-site/build.js output` to refresh the coverage view.

## Organisational guidance from Azure DevOps wikis

The `architecture-guidance` skill lets the `cloud-tier-architect` constrain technology and architecture decisions to what the organisation actually permits (approved tools, cloud patterns, security standards, naming conventions), sourced from Azure DevOps wikis.

It is **hybrid, offline-first**: a small Node sync script pulls the wiki pages into local reference files that are committed to git, and the agents only ever read those local files.

- **Refresh from the wiki:** `node .github/skills/architecture-guidance/sync/refresh.mjs`
- **Configure the sources:** edit [.github/skills/architecture-guidance/sync/wiki-sources.json](.github/skills/architecture-guidance/sync/wiki-sources.json) with your org/project/wiki and page paths. **No secrets go in this file.**
- **Authentication:** set an Azure DevOps PAT with **Wiki (Read)** scope in the `AZURE_DEVOPS_PAT` environment variable (or `SYSTEM_ACCESSTOKEN` in a pipeline). The PAT is never stored in the repo.
- **Offline fallback:** if the PAT is missing, the wiki is unreachable, or a user has no access to the wiki, the script warns and the pipeline continues on the **last-synced committed copy**. Only someone with wiki access can refresh it. Files that have never been synced are treated as an open question, not authoritative guidance.
- **`lap-orchestrator`** runs this refresh best-effort at the start of the cloud-tier stage, so the guidance is as fresh as the environment allows without ever breaking the run.

Everything stays self-contained under `.github/`, so copying `.github` carries the last-synced guidance offline; only the PAT is supplied per environment.

## Conventions

- British English in all generated documentation.
- Every artefact begins with a provenance block listing its input files.
- Never fabricate domain knowledge that is not evidenced in the source material.
- When adding a new agent or skill, update the tables above.
